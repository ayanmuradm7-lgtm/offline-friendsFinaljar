package com.offlinefriends;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.mock.MockSocialServer;
import com.offlinefriends.network.TrackPlayerC2SPayload;
import com.offlinefriends.network.TrackedPlayerPosS2CPayload;
import com.offlinefriends.social.ChatHistoryManager;
import com.offlinefriends.social.GroupManager;
import com.offlinefriends.social.SocialWebSocketClient;
import com.offlinefriends.util.OfflineUuidHelper;
import net.minecraft.util.Identifier;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import static org.junit.jupiter.api.Assertions.*;

public class OfflineFriendsModTest {

    @Test
    public void testOfflineUuidGeneration() {
        UUID uuid1 = OfflineUuidHelper.getOfflineUuid("TestPlayer");
        UUID expected = UUID.nameUUIDFromBytes("OfflinePlayer:TestPlayer".getBytes(StandardCharsets.UTF_8));
        assertEquals(expected, uuid1, "Offline UUID must match standard OfflinePlayer:username formula");

        UUID uuidNull = OfflineUuidHelper.getOfflineUuid(null);
        assertNotNull(uuidNull);

        UUID uuidEmpty = OfflineUuidHelper.getOfflineUuid("   ");
        assertNotNull(uuidEmpty);
    }

    @Test
    public void testUsernameMatchingAndSanitization() {
        assertTrue(OfflineUuidHelper.matchUsernames("CrackedSteve", "crackedsteve"));
        assertTrue(OfflineUuidHelper.matchUsernames("Player123 ", " player123"));
        assertFalse(OfflineUuidHelper.matchUsernames("Alex", "Steve"));

        assertEquals("Player123", OfflineUuidHelper.sanitizeUsername("Player@#123!"));
    }

    @Test
    public void testCustomPayloadIdentifiers() {
        assertEquals(Identifier.of("offlinefriends", "track_player_c2s"), TrackPlayerC2SPayload.ID.id());
        assertEquals(Identifier.of("offlinefriends", "tracked_player_pos_s2c"), TrackedPlayerPosS2CPayload.ID.id());
    }

    @Test
    public void testModConfigDefaultsAndSecretToken() {
        ModConfig config = ModConfig.getInstance();
        assertNotNull(config);
        assertNotNull(config.getToken());
        assertFalse(config.getToken().isEmpty(), "Secret token must be generated on first run");

        // Verify default live relay address
        assertEquals("wss://my-offline-friends.onrender.com/ws", config.getRelayUrl());
        assertEquals(true, config.isSoundEnabled());
        assertEquals(true, config.isShareMyServer());
        assertEquals(false, config.isInvisible());
    }

    @Test
    public void testChatHistoryManagerBoundsAndStatus() {
        ChatHistoryManager chm = ChatHistoryManager.getInstance();
        String testUser = "Friend_" + UUID.randomUUID().toString().substring(0, 6);
        String msgId = "msg-" + UUID.randomUUID();

        ChatHistoryManager.DirectMessage msg = new ChatHistoryManager.DirectMessage(
                msgId, "Me", testUser, "Testing message delivery", System.currentTimeMillis(), "sending"
        );
        chm.addMessage(msg, false);

        List<ChatHistoryManager.DirectMessage> history = chm.getConversation(testUser);
        assertFalse(history.isEmpty());
        assertEquals("sending", history.get(0).getStatus());

        chm.updateMessageStatus(msgId, "delivered");
        assertEquals("delivered", history.get(0).getStatus());
    }

    @Test
    public void testAutoAcceptAndLocalBlockingConfig() {
        ModConfig config = ModConfig.getInstance();

        // Auto-accept default
        assertTrue(config.isAutoAcceptFriends(), "Auto-accept should default to true");
        config.setAutoAcceptFriends(false);
        assertFalse(config.isAutoAcceptFriends());
        config.setAutoAcceptFriends(true);

        // Online notifications default
        assertTrue(config.isOnlineNotificationsEnabled(), "Online notifications should default to true");

        // Group invites default
        assertTrue(config.isAllowGroupInvitesFromFriends(), "Group invites should default to true");

        // Blocking functionality
        String blockedUser = "TrollPlayer_" + UUID.randomUUID().toString().substring(0, 4);
        assertFalse(config.isUserBlocked(blockedUser));

        config.blockUser(blockedUser);
        assertTrue(config.isUserBlocked(blockedUser), "User should be blocked");
        assertTrue(config.isUserBlocked(blockedUser.toLowerCase()), "Blocking should be case-insensitive");
        assertTrue(config.isUserBlocked(blockedUser.toUpperCase()), "Blocking should be case-insensitive");

        config.unblockUser(blockedUser);
        assertFalse(config.isUserBlocked(blockedUser), "User should be unblocked");

        // Muting functionality
        String mutedFriend = "SpammyFriend_" + UUID.randomUUID().toString().substring(0, 4);
        assertFalse(config.isFriendMuted(mutedFriend));

        config.muteFriend(mutedFriend);
        assertTrue(config.isFriendMuted(mutedFriend), "Friend should be muted");

        config.unmuteFriend(mutedFriend);
        assertFalse(config.isFriendMuted(mutedFriend), "Friend should be unmuted");
    }

    @Test
    public void testGroupManagerProtocolAndLimits() {
        // Group name sanitization
        assertEquals("Epic Squad", GroupManager.sanitizeGroupName("Epic|Squad,!"));
        assertEquals("Squad", GroupManager.sanitizeGroupName(null));
        assertEquals("VeryLongName123456789012", GroupManager.sanitizeGroupName("VeryLongName12345678901234567890"));

        // Max visible length calculation (256 minus header length)
        int maxLen = GroupManager.getMaxVisibleTextLength("12345678");
        assertTrue(maxLen > 200, "Max visible length should allow >200 chars");
        assertTrue(maxLen <= 228, "Max visible length must respect 256 char budget including header");

        // Group creation & member limits
        GroupManager gm = GroupManager.getInstance();
        List<String> invitees = List.of("FriendA", "FriendB", "FriendC");
        GroupManager.GroupInfo g = gm.createGroup("TestGroup", invitees);
        assertNotNull(g);
        assertEquals("TestGroup", g.getName());
        assertTrue(g.hasMember("FriendA"));
        assertTrue(g.hasMember("FriendB"));

        // Member limit max 8
        for (int i = 0; i < 10; i++) {
            g.addMember("ExtraMember_" + i);
        }
        assertTrue(g.getMembers().size() <= 8, "Group members must be capped at 8");

        // Dedup key handling
        String incomingFrame = "\u2063OFG1|" + g.getId() + "|M|msg999|Hello everyone in group!";
        assertTrue(incomingFrame.startsWith(GroupManager.PROTOCOL_HEADER));
    }

    @Test
    public void testMockSocialServerProtocolContract() throws Exception {
        try (MockSocialServer mockServer = new MockSocialServer()) {
            ModConfig config = ModConfig.getInstance();
            config.setServerAddress(mockServer.getWsUrl());

            SocialWebSocketClient client = SocialWebSocketClient.getInstance();
            client.connect();

            // Wait up to 3 seconds for connection and welcome packet
            for (int i = 0; i < 30; i++) {
                if (client.isConnected() && client.friends.containsKey("testbuddy")) {
                    break;
                }
                Thread.sleep(100);
            }

            assertTrue(client.isConnected(), "Client must connect to mock WebSocket server");
            assertTrue(client.friends.containsKey("testbuddy"), "Client must receive friends list from welcome packet");
            SocialWebSocketClient.FriendInfo friend = client.friends.get("testbuddy");
            assertTrue(friend.online());
            assertEquals("play.example.net", friend.server());

            // Send a test DM
            client.sendDirectMessage("TestBuddy", "Hello from test!");

            // Wait for DM ACK
            Thread.sleep(300);
            assertFalse(mockServer.receivedPackets.isEmpty());

            client.disconnect();
        } finally {
            // Restore default live relay url
            ModConfig.getInstance().setRelayUrl(ModConfig.DEFAULT_RELAY_URL);
        }
    }

    @Test
    public void testLiveRelayServerHealthEndpoint() {
        try {
            java.net.http.HttpClient client = java.net.http.HttpClient.newHttpClient();
            java.net.http.HttpRequest req = java.net.http.HttpRequest.newBuilder()
                    .uri(java.net.URI.create("https://my-offline-friends.onrender.com/health"))
                    .timeout(java.time.Duration.ofSeconds(5))
                    .GET()
                    .build();
            java.net.http.HttpResponse<String> resp = client.send(req, java.net.http.HttpResponse.BodyHandlers.ofString());
            assertEquals(200, resp.statusCode());
            assertTrue(resp.body().contains("ok"));
        } catch (Exception e) {
            // Non-fatal if internet is flaky during build
            System.out.println("Live health endpoint check note: " + e.getMessage());
        }
    }

    @Test
    public void testTwoClientLiveRelayFriendFlow() throws Exception {
        String baseId = String.valueOf(System.currentTimeMillis() % 100000);
        String userA = "TestA_" + baseId;
        String userB = "TestB_" + baseId;
        String tokenA = "tokenA_" + UUID.randomUUID().toString().substring(0, 8);
        String tokenB = "tokenB_" + UUID.randomUUID().toString().substring(0, 8);

        List<JsonObject> packetsA = new CopyOnWriteArrayList<>();
        List<JsonObject> packetsB = new CopyOnWriteArrayList<>();

        Gson gson = new Gson();
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();

        WebSocket.Listener listenerA = new WebSocket.Listener() {
            @Override
            public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
                try {
                    packetsA.add(gson.fromJson(data.toString(), JsonObject.class));
                } catch (Exception ignored) {}
                return WebSocket.Listener.super.onText(ws, data, last);
            }
        };

        WebSocket.Listener listenerB = new WebSocket.Listener() {
            @Override
            public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
                try {
                    packetsB.add(gson.fromJson(data.toString(), JsonObject.class));
                } catch (Exception ignored) {}
                return WebSocket.Listener.super.onText(ws, data, last);
            }
        };

        try {
            WebSocket wsA = client.newWebSocketBuilder()
                    .buildAsync(URI.create(ModConfig.DEFAULT_RELAY_URL), listenerA)
                    .get(8, TimeUnit.SECONDS);

            WebSocket wsB = client.newWebSocketBuilder()
                    .buildAsync(URI.create(ModConfig.DEFAULT_RELAY_URL), listenerB)
                    .get(8, TimeUnit.SECONDS);

            // Handshake User A
            JsonObject helloA = new JsonObject();
            helloA.addProperty("type", "hello");
            helloA.addProperty("protocol", 1);
            helloA.addProperty("username", userA);
            helloA.addProperty("token", tokenA);
            helloA.addProperty("invisible", false);
            wsA.sendText(gson.toJson(helloA), true);

            // Handshake User B
            JsonObject helloB = new JsonObject();
            helloB.addProperty("type", "hello");
            helloB.addProperty("protocol", 1);
            helloB.addProperty("username", userB);
            helloB.addProperty("token", tokenB);
            helloB.addProperty("invisible", false);
            wsB.sendText(gson.toJson(helloB), true);

            // Wait for welcomes
            boolean welcomedA = waitForPacket(packetsA, "welcome", 5000);
            boolean welcomedB = waitForPacket(packetsB, "welcome", 5000);
            assertTrue(welcomedA, "User A must receive welcome packet from live server");
            assertTrue(welcomedB, "User B must receive welcome packet from live server");

            // User A sends friend request to User B
            JsonObject req = new JsonObject();
            req.addProperty("type", "friend_request");
            req.addProperty("to", userB);
            wsA.sendText(gson.toJson(req), true);

            // User B receives friend_request_in
            boolean requestIn = waitForPacket(packetsB, "friend_request_in", 5000);
            assertTrue(requestIn, "User B must receive friend_request_in from User A");

            // User B accepts friend request
            JsonObject accept = new JsonObject();
            accept.addProperty("type", "friend_accept");
            accept.addProperty("from", userA);
            wsB.sendText(gson.toJson(accept), true);

            // Both must receive friend_added
            boolean userAGotAdded = waitForPacket(packetsA, "friend_added", 5000);
            boolean userBGotAdded = waitForPacket(packetsB, "friend_added", 5000);
            assertTrue(userAGotAdded, "User A must receive friend_added");
            assertTrue(userBGotAdded, "User B must receive friend_added");

            // Test server error response on invalid request (e.g. friend yourself)
            JsonObject invalidSelf = new JsonObject();
            invalidSelf.addProperty("type", "friend_request");
            invalidSelf.addProperty("to", userA);
            wsA.sendText(gson.toJson(invalidSelf), true);

            boolean gotError = waitForPacket(packetsA, "error", 5000);
            assertTrue(gotError, "User A must receive error packet when friending themselves");

            // Clean up: User A removes User B
            JsonObject remove = new JsonObject();
            remove.addProperty("type", "friend_remove");
            remove.addProperty("username", userB);
            wsA.sendText(gson.toJson(remove), true);

            Thread.sleep(300);
            wsA.sendClose(WebSocket.NORMAL_CLOSURE, "Test done");
            wsB.sendClose(WebSocket.NORMAL_CLOSURE, "Test done");
        } catch (Exception e) {
            System.out.println("Live two-client test note: " + e.getMessage());
        }
    }

    private boolean waitForPacket(List<JsonObject> list, String type, long timeoutMs) throws InterruptedException {
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeoutMs) {
            for (JsonObject p : list) {
                if (p.has("type") && p.get("type").getAsString().equalsIgnoreCase(type)) {
                    return true;
                }
            }
            Thread.sleep(100);
        }
        return false;
    }

    @Test
    public void testJarConstantPoolAndBytecodeIntegrity() throws Exception {
        File jarFile = new File("build/libs/offlinefriends-1.21.11-1.3.5.jar");
        if (!jarFile.exists()) {
            jarFile = new File("build/devlibs/offlinefriends-1.21.11-1.3.5-dev.jar");
        }
        if (!jarFile.exists()) {
            jarFile = new File("../public/downloads/offlinefriends-1.21.11-1.3.5.jar");
        }
        if (!jarFile.exists()) {
            jarFile = new File("build/libs/offlinefriends-1.21.11-1.3.4.jar");
        }
        if (!jarFile.exists()) {
            jarFile = new File("../public/downloads/offlinefriends-1.21.11-1.3.4.jar");
        }
        assertTrue(jarFile.exists(), "Compiled jar file must exist in build/libs or build/devlibs");

        try (JarFile jar = new JarFile(jarFile)) {
            // Check MANIFEST.MF
            JarEntry manifestEntry = jar.getJarEntry("META-INF/MANIFEST.MF");
            assertNotNull(manifestEntry, "Jar must have META-INF/MANIFEST.MF");
            try (InputStream is = jar.getInputStream(manifestEntry)) {
                String manifestContent = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                assertTrue(manifestContent.contains("Fabric-Minecraft-Version: 1.21.11"), "Manifest must specify Minecraft 1.21.11");
                assertTrue(manifestContent.contains("Fabric-Mapping-Namespace: intermediary"), "Jar must be remapped to intermediary");
            }

            // Check fabric.mod.json
            JarEntry modJsonEntry = jar.getJarEntry("fabric.mod.json");
            assertNotNull(modJsonEntry, "Jar must contain fabric.mod.json");
            try (InputStream is = jar.getInputStream(modJsonEntry)) {
                String modJson = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                assertTrue(modJson.contains("\"minecraft\": \"1.21.11\""), "fabric.mod.json must require 1.21.11");
                assertTrue(modJson.contains("\"fabricloader\": \">=0.18.0\""), "fabric.mod.json must require loader >=0.18.0");
                assertFalse(modJson.contains("offlinefriends.mixins.json"), "Must be mixin-free");
            }

            // Ensure MockSocialServer is NOT included in the jar
            JarEntry mockEntry = jar.getJarEntry("com/offlinefriends/mock/MockSocialServer.class");
            assertNull(mockEntry, "Mock test classes must never be packaged into production mod jar");

            // Verify absence of any fake stub classes in any class entries
            jar.stream().filter(e -> e.getName().endsWith(".class")).forEach(entry -> {
                String name = entry.getName();
                assertFalse(name.contains("MinecraftServer$PlayerManager"), "Fake stub class found: " + name);
                assertFalse(name.contains("ServerPlayerEntity$RegistryKey"), "Fake stub class found: " + name);
                assertFalse(name.contains("ServerPlayerEntity$ServerWorld"), "Fake stub class found: " + name);
                assertFalse(name.contains("MinecraftClient$Window"), "Fake stub class found: " + name);
            });
        }
    }
}
