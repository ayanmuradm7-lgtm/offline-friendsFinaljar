package com.offlinefriends.mock;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * MockSocialServer
 * 
 * Lightweight throwaway test mock for Protocol Version 1.
 * Placed exclusively in src/test/ so it is NEVER packaged into the production mod JAR.
 */
public class MockSocialServer implements AutoCloseable {

    private static final Gson GSON = new Gson();
    private static final String WS_MAGIC_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    private final ServerSocket serverSocket;
    private final int port;
    private volatile boolean running = true;
    private Socket clientSocket;
    private OutputStream clientOut;
    private InputStream clientIn;

    public final List<JsonObject> receivedPackets = new CopyOnWriteArrayList<>();

    public MockSocialServer() throws Exception {
        this.serverSocket = new ServerSocket(0); // auto assign available ephemeral port
        this.port = this.serverSocket.getLocalPort();
        Thread thread = new Thread(this::listenLoop, "MockSocialServer-Accept");
        thread.setDaemon(true);
        thread.start();
    }

    public int getPort() {
        return port;
    }

    public String getWsUrl() {
        return "ws://127.0.0.1:" + port;
    }

    private void listenLoop() {
        try {
            this.clientSocket = serverSocket.accept();
            this.clientIn = clientSocket.getInputStream();
            this.clientOut = clientSocket.getOutputStream();

            // 1. Perform HTTP WebSocket Handshake
            handleHandshake(clientIn, clientOut);

            // 2. Read frames loop
            while (running && !clientSocket.isClosed()) {
                String text = readWebSocketFrame(clientIn);
                if (text == null) break;

                JsonObject obj = GSON.fromJson(text, JsonObject.class);
                if (obj != null) {
                    receivedPackets.add(obj);
                    processPacket(obj);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void handleHandshake(InputStream in, OutputStream out) throws Exception {
        Scanner scanner = new Scanner(in, StandardCharsets.UTF_8);
        String secKey = null;

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.isEmpty()) break;
            if (line.toLowerCase().startsWith("sec-websocket-key:")) {
                secKey = line.substring(line.indexOf(':') + 1).trim();
            }
        }

        if (secKey != null) {
            byte[] responseKey = MessageDigest.getInstance("SHA-1")
                    .digest((secKey + WS_MAGIC_GUID).getBytes(StandardCharsets.UTF_8));
            String accept = Base64.getEncoder().encodeToString(responseKey);

            byte[] response = ("HTTP/1.1 101 Switching Protocols\r\n" +
                    "Connection: Upgrade\r\n" +
                    "Upgrade: websocket\r\n" +
                    "Sec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.UTF_8);
            out.write(response);
            out.flush();
        }
    }

    private void processPacket(JsonObject packet) {
        String type = packet.has("type") ? packet.get("type").getAsString() : "";

        switch (type) {
            case "hello" -> {
                // Respond with welcome
                JsonObject welcome = new JsonObject();
                welcome.addProperty("type", "welcome");

                JsonArray friends = new JsonArray();
                JsonObject f1 = new JsonObject();
                f1.addProperty("username", "TestBuddy");
                f1.addProperty("online", true);
                f1.addProperty("server", "play.example.net");
                friends.add(f1);

                welcome.add("friends", friends);
                welcome.add("pending_in", new JsonArray());
                welcome.add("queued_dms", new JsonArray());

                sendFrame(welcome);
            }
            case "ping" -> {
                JsonObject pong = new JsonObject();
                pong.addProperty("type", "pong");
                sendFrame(pong);
            }
            case "dm" -> {
                // ACK the DM
                String id = packet.get("id").getAsString();
                JsonObject ack = new JsonObject();
                ack.addProperty("type", "dm_ack");
                ack.addProperty("id", id);
                ack.addProperty("status", "delivered");
                sendFrame(ack);
            }
            case "track_request" -> {
                // Echo track_accepted
                String to = packet.get("to").getAsString();
                JsonObject accepted = new JsonObject();
                accepted.addProperty("type", "track_accepted");
                accepted.addProperty("by", to);
                sendFrame(accepted);
            }
        }
    }

    public synchronized void sendFrame(JsonObject json) {
        try {
            if (clientOut == null) return;
            byte[] payload = GSON.toJson(json).getBytes(StandardCharsets.UTF_8);

            // Opcode text (0x81)
            clientOut.write(0x81);
            if (payload.length <= 125) {
                clientOut.write(payload.length);
            } else if (payload.length <= 65535) {
                clientOut.write(126);
                clientOut.write((payload.length >> 8) & 0xFF);
                clientOut.write(payload.length & 0xFF);
            }
            clientOut.write(payload);
            clientOut.flush();
        } catch (Exception ignored) {
        }
    }

    private String readWebSocketFrame(InputStream in) throws Exception {
        int b1 = in.read();
        if (b1 == -1) return null;
        int b2 = in.read();
        if (b2 == -1) return null;

        boolean masked = (b2 & 0x80) != 0;
        int length = b2 & 0x7F;

        if (length == 126) {
            length = ((in.read() & 0xFF) << 8) | (in.read() & 0xFF);
        } else if (length == 127) {
            // Unused for small json
            for (int i = 0; i < 8; i++) in.read();
            length = 0;
        }

        byte[] mask = new byte[4];
        if (masked) {
            in.readNBytes(mask, 0, 4);
        }

        byte[] payload = in.readNBytes(length);
        if (masked) {
            for (int i = 0; i < payload.length; i++) {
                payload[i] ^= mask[i % 4];
            }
        }

        return new String(payload, StandardCharsets.UTF_8);
    }

    @Override
    public void close() throws Exception {
        this.running = false;
        if (clientSocket != null) clientSocket.close();
        if (serverSocket != null) serverSocket.close();
    }
}
