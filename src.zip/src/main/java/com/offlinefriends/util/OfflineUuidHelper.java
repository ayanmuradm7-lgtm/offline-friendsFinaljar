package com.offlinefriends.util;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * OfflineUuidHelper
 * 
 * Computes deterministic UUIDs for offline/cracked accounts without contacting
 * Mojang's session servers. Matches standard offline format:
 * UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8))
 */
public final class OfflineUuidHelper {

    private OfflineUuidHelper() {}

    /**
     * Computes the deterministic offline UUID for a given username.
     * 
     * @param username The player's display username.
     * @return The offline UUID.
     */
    public static UUID getOfflineUuid(String username) {
        if (username == null || username.trim().isEmpty()) {
            return UUID.nameUUIDFromBytes("OfflinePlayer:unknown".getBytes(StandardCharsets.UTF_8));
        }
        String clean = username.trim();
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + clean).getBytes(StandardCharsets.UTF_8));
    }

    public static UUID getOfflinePlayerUuid(String username) {
        return getOfflineUuid(username);
    }

    /**
     * Compares two usernames in a case-insensitive manner for cracked player compatibility.
     */
    public static boolean matchUsernames(String a, String b) {
        if (a == null || b == null) return false;
        return a.trim().equalsIgnoreCase(b.trim());
    }

    /**
     * Sanitizes username input to conform to standard Minecraft alphanumeric rules.
     */
    public static String sanitizeUsername(String input) {
        if (input == null) return "";
        return input.trim().replaceAll("[^a-zA-Z0-9_]", "");
    }
}
