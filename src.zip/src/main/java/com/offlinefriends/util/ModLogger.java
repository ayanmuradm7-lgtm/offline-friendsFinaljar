package com.offlinefriends.util;

import com.offlinefriends.OfflineFriendsMod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * ModLogger
 * 
 * Central logger for Offline Friends.
 * Guarantees that friend events (friend_request, friend_accept, friend_decline, friend_added, friend_removed)
 * and server errors are logged with timestamps and full details to offlinefriends-debug.log.
 * 
 * Token Redaction:
 * Never prints user secret tokens to any log stream or file.
 */
public final class ModLogger {

    public static final String MOD_VERSION = "1.3.5";
    private static final Logger LOGGER = LoggerFactory.getLogger(OfflineFriendsMod.MOD_ID);
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private static final Object FILE_LOCK = new Object();
    private static File debugLogFile = null;
    private static File rootLogFile = null;
    private static String redactedToken = null;
    private static boolean initializedHeader = false;

    private ModLogger() {}

    public static void setRedactedToken(String token) {
        if (token != null && !token.trim().isEmpty()) {
            redactedToken = token.trim();
        }
    }

    private static String sanitize(String message) {
        if (message == null) return "null";
        if (redactedToken != null && !redactedToken.isEmpty() && message.contains(redactedToken)) {
            return message.replace(redactedToken, "[SECRET_TOKEN_REDACTED]");
        }
        return message;
    }

    public static synchronized void initDebugLog() {
        if (initializedHeader) return;
        initializedHeader = true;
        String stamp = "Offline Friends v" + MOD_VERSION + " [Minecraft 1.21.11, Fabric Loader 0.18.4] - " + LocalDateTime.now().format(TIME_FORMATTER);
        writeInitialStamp(new File("logs/offlinefriends-debug.log"), stamp);
        writeInitialStamp(new File("offlinefriends-debug.log"), stamp);
    }

    private static void writeInitialStamp(File file, String stamp) {
        try {
            if (file.getParentFile() != null && !file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            boolean isNew = !file.exists() || file.length() == 0;
            try (FileWriter fw = new FileWriter(file, true);
                 PrintWriter pw = new PrintWriter(fw)) {
                if (isNew) {
                    pw.println(stamp);
                    pw.println("================================================================================");
                } else {
                    pw.println("");
                    pw.println("=== " + stamp + " ===");
                }
                pw.flush();
            }
        } catch (Exception ignored) {}
    }

    private static synchronized File getDebugLogFile() {
        if (debugLogFile == null) {
            File logsDir = new File("logs");
            if (!logsDir.exists()) {
                logsDir.mkdirs();
            }
            debugLogFile = new File(logsDir, "offlinefriends-debug.log");
            rootLogFile = new File("offlinefriends-debug.log");
        }
        return debugLogFile;
    }

    private static void writeToFile(String line) {
        initDebugLog();
        try {
            File file = getDebugLogFile();
            synchronized (FILE_LOCK) {
                try (FileWriter fw = new FileWriter(file, true);
                     PrintWriter pw = new PrintWriter(fw)) {
                    pw.println(sanitize(line));
                    pw.flush();
                }
                if (rootLogFile != null) {
                    try (FileWriter rfw = new FileWriter(rootLogFile, true);
                         PrintWriter rpw = new PrintWriter(rfw)) {
                        rpw.println(sanitize(line));
                        rpw.flush();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to append to offlinefriends-debug.log", e);
        }
    }

    public static void info(String message, Object... args) {
        LOGGER.info(sanitize(message), args);
    }

    public static void warn(String message, Object... args) {
        LOGGER.warn(sanitize(message), args);
    }

    /**
     * Dedicated protocol and friend event logger with timestamped file recording.
     * Logs every friend_request, friend_accept, friend_decline, and friend_added message sent or received.
     */
    public static void logEvent(String eventType, String details) {
        String time = LocalDateTime.now().format(TIME_FORMATTER);
        String logLine = "[" + time + "] [v" + MOD_VERSION + "] [" + eventType.toUpperCase() + "] " + details;
        LOGGER.info(sanitize(logLine));
        writeToFile(logLine);
    }

    public static void error(String message, Throwable throwable) {
        String cleanMsg = sanitize(message);
        LOGGER.error(cleanMsg, throwable);

        // Write full stack trace to offlinefriends-debug.log
        try {
            String time = LocalDateTime.now().format(TIME_FORMATTER);
            writeToFile("[" + time + "] [ERROR] " + cleanMsg + (throwable != null ? " - " + throwable.getMessage() : ""));
            if (throwable != null) {
                StringWriter sw = new StringWriter();
                throwable.printStackTrace(new PrintWriter(sw));
                writeToFile(sw.toString());
            }
        } catch (Exception e) {
            LOGGER.error("Failed to append to offlinefriends-debug.log", e);
        }
    }
}
