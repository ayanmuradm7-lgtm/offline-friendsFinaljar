package com.offlinefriends.social;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.offlinefriends.util.ModLogger;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * ChatHistoryManager
 * 
 * Manages local persistent DM conversations per cracked/offline friend.
 * Memory Profile:
 * - Strictly bounded (max 50 messages per friend) to prevent memory accumulation (< 1 GB heap).
 * - Tracks unread badges per friend.
 * - Tracks delivery status per message: "sending", "delivered", "queued", "failed".
 */
public class ChatHistoryManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int MAX_MESSAGES_PER_FRIEND = 50;
    private static final Object LOCK = new Object();
    private static ChatHistoryManager instance;

    public static class DirectMessage {
        private final String id;
        private final String from;
        private final String to;
        private final String text;
        private final long timestamp;
        private String status; // "sending", "delivered", "queued", "failed"

        public DirectMessage(String id, String from, String to, String text, long timestamp, String status) {
            this.id = id != null ? id : UUID.randomUUID().toString();
            this.from = from != null ? from : "Unknown";
            this.to = to != null ? to : "Unknown";
            this.text = text != null ? text : "";
            this.timestamp = timestamp;
            this.status = status != null ? status : "delivered";
        }

        public String getId() {
            return id;
        }

        public String getFrom() {
            return from;
        }

        public String getTo() {
            return to;
        }

        public String getText() {
            return text;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }

    // Map: Friend Lowercase Username -> List of Messages
    private final Map<String, List<DirectMessage>> conversations = new ConcurrentHashMap<>();
    // Map: Friend Lowercase Username -> Unread Count
    private final Map<String, Integer> unreadCounts = new ConcurrentHashMap<>();
    private String currentlyViewingFriend = null;

    public static synchronized ChatHistoryManager getInstance() {
        if (instance == null) {
            instance = new ChatHistoryManager();
            instance.loadFromDisk();
        }
        return instance;
    }

    private File getHistoryFile() {
        File dir = new File("config", "offlinefriends");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return new File(dir, "chat_history.json");
    }

    public synchronized void setCurrentlyViewingFriend(String friendUsername) {
        this.currentlyViewingFriend = friendUsername != null ? friendUsername.toLowerCase().trim() : null;
        if (this.currentlyViewingFriend != null) {
            markAsRead(this.currentlyViewingFriend);
        }
    }

    public List<DirectMessage> getConversation(String friendUsername) {
        if (friendUsername == null) return Collections.emptyList();
        String key = friendUsername.toLowerCase().trim();
        return conversations.computeIfAbsent(key, k -> new CopyOnWriteArrayList<>());
    }

    public int getUnreadCount(String friendUsername) {
        if (friendUsername == null) return 0;
        String key = friendUsername.toLowerCase().trim();
        return unreadCounts.getOrDefault(key, 0);
    }

    public void markAsRead(String friendUsername) {
        if (friendUsername == null) return;
        String key = friendUsername.toLowerCase().trim();
        unreadCounts.put(key, 0);
    }

    public void addMessage(DirectMessage msg, boolean incoming) {
        if (msg == null) return;
        String otherUser = incoming ? msg.getFrom() : msg.getTo();
        if (otherUser == null || otherUser.isEmpty()) return;
        String key = otherUser.toLowerCase().trim();

        List<DirectMessage> list = conversations.computeIfAbsent(key, k -> new CopyOnWriteArrayList<>());
        // Prevent duplicate IDs
        for (DirectMessage m : list) {
            if (m.getId().equals(msg.getId())) {
                return;
            }
        }

        list.add(msg);
        while (list.size() > MAX_MESSAGES_PER_FRIEND) {
            list.remove(0);
        }

        // Increment unread if incoming and not actively viewing
        if (incoming) {
            if (currentlyViewingFriend == null || !currentlyViewingFriend.equals(key)) {
                unreadCounts.merge(key, 1, Integer::sum);
            }
        }

        saveToDiskAsync();
    }

    public DirectMessage getMessage(String messageId) {
        if (messageId == null) return null;
        for (List<DirectMessage> list : conversations.values()) {
            for (DirectMessage m : list) {
                if (m.getId().equals(messageId)) {
                    return m;
                }
            }
        }
        return null;
    }

    public void updateMessageStatus(String messageId, String status) {
        if (messageId == null || status == null) return;
        boolean updated = false;

        for (List<DirectMessage> list : conversations.values()) {
            for (DirectMessage m : list) {
                if (m.getId().equals(messageId)) {
                    m.setStatus(status);
                    updated = true;
                }
            }
        }

        if (updated) {
            saveToDiskAsync();
        }
    }

    private void saveToDiskAsync() {
        new Thread(() -> {
            synchronized (LOCK) {
                try {
                    File file = getHistoryFile();
                    try (FileWriter writer = new FileWriter(file)) {
                        GSON.toJson(conversations, writer);
                        writer.flush();
                    }
                } catch (Exception e) {
                    ModLogger.error("Failed to save chat history to disk", e);
                }
            }
        }, "OfflineFriends-ChatSave").start();
    }

    private void loadFromDisk() {
        synchronized (LOCK) {
            File file = getHistoryFile();
            if (!file.exists()) return;

            try (FileReader reader = new FileReader(file)) {
                Type type = new TypeToken<Map<String, List<DirectMessage>>>() {}.getType();
                Map<String, List<DirectMessage>> data = GSON.fromJson(reader, type);
                if (data != null) {
                    conversations.clear();
                    data.forEach((k, v) -> {
                        CopyOnWriteArrayList<DirectMessage> list = new CopyOnWriteArrayList<>(v);
                        while (list.size() > MAX_MESSAGES_PER_FRIEND) {
                            list.remove(0);
                        }
                        conversations.put(k.toLowerCase().trim(), list);
                    });
                }
            } catch (Exception e) {
                ModLogger.error("Failed to load chat history from disk", e);
            }
        }
    }
}
