package com.offlinefriends.social;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.offlinefriends.client.gui.SocialScreen;
import com.offlinefriends.client.notification.LeftNotificationManager;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.util.ModLogger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * GroupManager
 * 
 * Implements client-side Group Messaging built on top of DM transport.
 * Protocol:
 * DMs prefixed with invisible character U+2063 + OFG1|<groupId>|<action>|...
 * 
 * Actions:
 * - Message: OFG1|<groupId>|M|<msgId>|<text>
 * - Create / Member sync: OFG1|<groupId>|C|<name>|<member1,member2,...>
 * - Rename: OFG1|<groupId>|N|<newName>
 * - Leave: OFG1|<groupId>|L|
 * 
 * Constraints:
 * - Max 8 members per group.
 * - Name max 24 chars, no '|' or ','.
 * - Max 256 chars total per DM packet including header.
 * - Enforces relay rate limit (max 20 messages per 30s) via background queue.
 * - Deduplication of group messages by (groupId, sender, msgId).
 */
public class GroupManager {

    public static final String PROTOCOL_HEADER = "\u2063OFG1|";
    private static final int MAX_GROUP_MESSAGES = 50;
    private static final int MAX_SENDS_PER_30_SEC = 19; // Safe margin below server's 20/30s
    private static final long WINDOW_MS = 30_000L;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Object FILE_LOCK = new Object();
    private static GroupManager instance;

    public static class GroupInfo {
        private String id;
        private String name;
        private List<String> members = new CopyOnWriteArrayList<>();

        public GroupInfo() {}

        public GroupInfo(String id, String name, List<String> members) {
            this.id = id;
            this.name = name != null ? name.trim() : "Group";
            if (members != null) {
                for (String m : members) {
                    if (m != null && !m.trim().isEmpty() && !hasMember(m)) {
                        this.members.add(m.trim());
                    }
                }
            }
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name != null ? name : "Group";
        }

        public void setName(String name) {
            this.name = name != null ? name.trim() : "Group";
        }

        public List<String> getMembers() {
            return members;
        }

        public boolean hasMember(String username) {
            if (username == null) return false;
            for (String m : members) {
                if (m.equalsIgnoreCase(username.trim())) return true;
            }
            return false;
        }

        public void addMember(String username) {
            if (username != null && !username.trim().isEmpty() && !hasMember(username) && members.size() < 8) {
                members.add(username.trim());
            }
        }

        public void removeMember(String username) {
            if (username == null) return;
            members.removeIf(m -> m.equalsIgnoreCase(username.trim()));
        }

        public void setMembers(List<String> newMembers) {
            this.members.clear();
            if (newMembers != null) {
                for (String m : newMembers) {
                    if (m != null && !m.trim().isEmpty() && !hasMember(m)) {
                        this.members.add(m.trim());
                    }
                }
            }
        }
    }

    public static class GroupMessage {
        private String msgId;
        private String groupId;
        private String sender;
        private String text;
        private long timestamp;
        // Map of recipient username -> delivery status ("sending", "delivered", "queued", "failed")
        private Map<String, String> recipientStatuses = new ConcurrentHashMap<>();
        // Map of dmPacketId -> recipient username
        private Map<String, String> packetIdToRecipient = new ConcurrentHashMap<>();

        public GroupMessage() {}

        public GroupMessage(String msgId, String groupId, String sender, String text, long timestamp) {
            this.msgId = msgId;
            this.groupId = groupId;
            this.sender = sender;
            this.text = text;
            this.timestamp = timestamp;
        }

        public String getMsgId() { return msgId; }
        public String getGroupId() { return groupId; }
        public String getSender() { return sender; }
        public String getText() { return text; }
        public long getTimestamp() { return timestamp; }
        public Map<String, String> getRecipientStatuses() { return recipientStatuses; }
        public Map<String, String> getPacketIdToRecipient() { return packetIdToRecipient; }
    }

    public static class OutboundDm {
        public final String dmPacketId;
        public final String to;
        public final String text;
        public final String groupMsgId;
        public final String groupId;

        public OutboundDm(String dmPacketId, String to, String text, String groupMsgId, String groupId) {
            this.dmPacketId = dmPacketId;
            this.to = to;
            this.text = text;
            this.groupMsgId = groupMsgId;
            this.groupId = groupId;
        }
    }

    // In-Memory Groups & Messages
    private final Map<String, GroupInfo> groups = new ConcurrentHashMap<>();
    private final Map<String, List<GroupMessage>> groupMessages = new ConcurrentHashMap<>();
    private final Map<String, Integer> unreadCounts = new ConcurrentHashMap<>();
    private final Set<String> processedMessageKeys = ConcurrentHashMap.newKeySet();

    // Active viewing group
    private volatile String currentlyViewingGroupId = null;

    public static synchronized GroupManager getInstance() {
        if (instance == null) {
            instance = new GroupManager();
            instance.loadFromDisk();
        }
        return instance;
    }

    private GroupManager() {}

    private File getStorageFile() {
        File dir = new File("config");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "offlinefriends_groups.json");
    }

    public static class GroupStorageData {
        public Map<String, GroupInfo> groups = new HashMap<>();
        public Map<String, List<GroupMessage>> messages = new HashMap<>();
    }

    private void loadFromDisk() {
        synchronized (FILE_LOCK) {
            File file = getStorageFile();
            if (file.exists()) {
                try (FileReader reader = new FileReader(file)) {
                    GroupStorageData data = GSON.fromJson(reader, GroupStorageData.class);
                    if (data != null) {
                        if (data.groups != null) this.groups.putAll(data.groups);
                        if (data.messages != null) {
                            for (Map.Entry<String, List<GroupMessage>> entry : data.messages.entrySet()) {
                                this.groupMessages.put(entry.getKey(), new CopyOnWriteArrayList<>(entry.getValue()));
                            }
                        }
                    }
                } catch (Exception e) {
                    ModLogger.error("Failed to load group storage", e);
                }
            }
        }
    }

    private void saveAsync() {
        new Thread(() -> {
            synchronized (FILE_LOCK) {
                try {
                    File file = getStorageFile();
                    GroupStorageData data = new GroupStorageData();
                    data.groups.putAll(this.groups);
                    for (Map.Entry<String, List<GroupMessage>> entry : this.groupMessages.entrySet()) {
                        data.messages.put(entry.getKey(), new ArrayList<>(entry.getValue()));
                    }
                    try (FileWriter writer = new FileWriter(file)) {
                        GSON.toJson(data, writer);
                        writer.flush();
                    }
                } catch (Exception e) {
                    ModLogger.error("Failed to save group storage", e);
                }
            }
        }, "GroupStorage-Save").start();
    }

    public boolean isCurrentlyRateLimited() {
        return SocialWebSocketClient.getInstance().isRateLimited();
    }

    // ==========================================
    // Group Management API
    // ==========================================

    public Map<String, GroupInfo> getGroups() {
        return groups;
    }

    public GroupInfo getGroup(String groupId) {
        return groupId != null ? groups.get(groupId) : null;
    }

    public List<GroupMessage> getMessages(String groupId) {
        if (groupId == null) return Collections.emptyList();
        return groupMessages.computeIfAbsent(groupId, k -> new CopyOnWriteArrayList<>());
    }

    public int getUnreadCount(String groupId) {
        if (groupId == null) return 0;
        return unreadCounts.getOrDefault(groupId, 0);
    }

    public void setCurrentlyViewingGroupId(String groupId) {
        this.currentlyViewingGroupId = groupId;
        if (groupId != null) {
            unreadCounts.put(groupId, 0);
        }
    }

    /**
     * Creates a new local group and broadcasts the 'C' sync frame to all members.
     */
    public GroupInfo createGroup(String name, List<String> memberUsernames) {
        String cleanName = sanitizeGroupName(name);
        String groupId = UUID.randomUUID().toString().substring(0, 8);
        String myName = ModConfig.getInstance().getEffectiveUsername();

        List<String> allMembers = new ArrayList<>();
        allMembers.add(myName);
        if (memberUsernames != null) {
            for (String m : memberUsernames) {
                if (m != null && !m.trim().isEmpty() && !m.equalsIgnoreCase(myName) && allMembers.size() < 8) {
                    allMembers.add(m.trim());
                }
            }
        }

        GroupInfo group = new GroupInfo(groupId, cleanName, allMembers);
        groups.put(groupId, group);
        groupMessages.put(groupId, new CopyOnWriteArrayList<>());
        saveAsync();

        ModLogger.logEvent("GROUP_CREATED", "ID: " + groupId + ", Name: '" + cleanName + "', Members: " + allMembers);

        // Broadcast Create frame to all other members
        broadcastSync(group);

        return group;
    }

    public void renameGroup(String groupId, String newName) {
        GroupInfo group = groups.get(groupId);
        if (group == null) return;
        String cleanName = sanitizeGroupName(newName);
        group.setName(cleanName);
        saveAsync();

        ModLogger.logEvent("GROUP_RENAMED", "ID: " + groupId + " new name: '" + cleanName + "'");

        String myName = ModConfig.getInstance().getEffectiveUsername();
        String payload = PROTOCOL_HEADER + groupId + "|N|" + cleanName;
        sendToAllOtherMembers(group, payload, null, null);

        addSystemMessage(groupId, "You renamed the group to " + cleanName);
    }

    public void addMemberToGroup(String groupId, String newMember) {
        GroupInfo group = groups.get(groupId);
        if (group == null || newMember == null || newMember.trim().isEmpty()) return;
        String clean = newMember.trim();
        if (group.hasMember(clean) || group.getMembers().size() >= 8) return;

        group.addMember(clean);
        saveAsync();

        ModLogger.logEvent("GROUP_MEMBER_ADDED", "ID: " + groupId + " added: '" + clean + "'");

        broadcastSync(group);
        addSystemMessage(groupId, "You added " + clean + " to the group");
    }

    public void leaveGroup(String groupId) {
        GroupInfo group = groups.get(groupId);
        if (group == null) return;

        String myName = ModConfig.getInstance().getEffectiveUsername();
        String payload = PROTOCOL_HEADER + groupId + "|L|";
        sendToAllOtherMembers(group, payload, null, null);

        groups.remove(groupId);
        groupMessages.remove(groupId);
        unreadCounts.remove(groupId);
        saveAsync();

        ModLogger.logEvent("GROUP_LEFT", "Left group ID: " + groupId + " ('" + group.getName() + "')");
    }

    public void broadcastSync(GroupInfo group) {
        String payload = PROTOCOL_HEADER + group.getId() + "|C|" + group.getName() + "|" + String.join(",", group.getMembers());
        sendToAllOtherMembers(group, payload, null, null);
    }

    /**
     * Sends a chat message to all other members of the group.
     */
    public boolean sendGroupMessage(String groupId, String rawText) {
        GroupInfo group = groups.get(groupId);
        if (group == null || rawText == null || rawText.trim().isEmpty()) return false;

        String myName = ModConfig.getInstance().getEffectiveUsername();
        String msgId = UUID.randomUUID().toString().substring(0, 10);
        String cleanText = rawText.trim();

        // Enforce 256 char total limit
        int maxVisible = getMaxVisibleTextLength(groupId);
        if (cleanText.length() > maxVisible) {
            cleanText = cleanText.substring(0, maxVisible);
        }

        // Add local message
        GroupMessage groupMsg = new GroupMessage(msgId, groupId, myName, cleanText, System.currentTimeMillis());
        List<GroupMessage> list = groupMessages.computeIfAbsent(groupId, k -> new CopyOnWriteArrayList<>());
        list.add(groupMsg);
        while (list.size() > MAX_GROUP_MESSAGES) {
            list.remove(0);
        }

        String payload = PROTOCOL_HEADER + groupId + "|M|" + msgId + "|" + cleanText;

        // Send group DM to each other member via shared outbound queue
        for (String member : group.getMembers()) {
            if (member.equalsIgnoreCase(myName)) continue;

            String dmPacketId = UUID.randomUUID().toString();
            groupMsg.getRecipientStatuses().put(member, "sending");
            groupMsg.getPacketIdToRecipient().put(dmPacketId, member);

            SocialWebSocketClient.getInstance().sendGroupDm(member, payload, dmPacketId, msgId, groupId);
        }

        saveAsync();
        ModLogger.logEvent("GROUP_MSG_SENT", "Group ID: " + groupId + ", msgId: " + msgId + ", text: '" + cleanText + "'");
        return true;
    }

    private void sendToAllOtherMembers(GroupInfo group, String payload, String groupMsgId, String groupId) {
        String myName = ModConfig.getInstance().getEffectiveUsername();
        for (String member : group.getMembers()) {
            if (member.equalsIgnoreCase(myName)) continue;
            String dmPacketId = UUID.randomUUID().toString();
            SocialWebSocketClient.getInstance().sendGroupDm(member, payload, dmPacketId, groupMsgId, groupId);
        }
    }

    public static int getMaxVisibleTextLength(String groupId) {
        // \u2063OFG1|<groupId>|M|<msgId>| -> 1 + 4 + 1 + length(groupId) + 1 + 1 + 1 + 10 + 1
        int gLen = groupId != null ? groupId.length() : 8;
        int headerLen = 20 + gLen;
        return Math.max(10, 256 - headerLen);
    }

    public static String sanitizeGroupName(String name) {
        if (name == null || name.trim().isEmpty()) return "Squad";
        String clean = name.replace("|", " ").replaceAll("[,!]", "").replaceAll("\\s+", " ").trim();
        if (clean.length() > 24) clean = clean.substring(0, 24);
        return clean.isEmpty() ? "Squad" : clean;
    }

    private void addSystemMessage(String groupId, String notice) {
        GroupMessage sys = new GroupMessage(UUID.randomUUID().toString().substring(0, 10), groupId, "System", notice, System.currentTimeMillis());
        List<GroupMessage> list = groupMessages.computeIfAbsent(groupId, k -> new CopyOnWriteArrayList<>());
        list.add(sys);
        saveAsync();
    }

    // ==========================================
    // Inbound Protocol Parser
    // ==========================================

    /**
     * Checks if incoming DM text is an OFG1 group protocol packet.
     */
    public boolean handleIncomingGroupDm(String sender, String rawText) {
        if (rawText == null || (!rawText.startsWith(PROTOCOL_HEADER) && !rawText.startsWith("\u2063OFG1|"))) {
            return false;
        }

        // 1. Blocked check
        if (ModConfig.getInstance().isUserBlocked(sender)) {
            ModLogger.logEvent("BLOCKED_GROUP_MSG_DROPPED", "Dropped group frame from blocked user: '" + sender + "'");
            return true; // Consumed, do NOT show as normal DM!
        }

        try {
            String stripped = rawText.startsWith("\u2063") ? rawText.substring(1) : rawText;
            String[] parts = stripped.split("\\|", -1);
            if (parts.length < 3 || !parts[0].equals("OFG1")) {
                return true;
            }

            String groupId = parts[1];
            String action = parts[2];

            switch (action) {
                case "C" -> handleGroupSync(sender, groupId, parts);
                case "M" -> handleGroupMessage(sender, groupId, stripped, parts);
                case "N" -> handleGroupRename(sender, groupId, parts);
                case "L" -> handleGroupLeave(sender, groupId);
                default -> ModLogger.warn("Unknown group action: {}", action);
            }
        } catch (Exception e) {
            ModLogger.error("Failed to parse incoming group DM from " + sender, e);
        }

        return true; // Always return true so it is NEVER shown as a regular DM
    }

    private void handleGroupSync(String sender, String groupId, String[] parts) {
        if (parts.length < 5) return;
        String groupName = sanitizeGroupName(parts[3]);
        String membersCsv = parts[4];

        // Setting check
        if (!ModConfig.getInstance().isAllowGroupInvitesFromFriends()) {
            ModLogger.logEvent("GROUP_INVITE_DECLINED", "Ignored group invite from '" + sender + "' because group invites are disabled");
            return;
        }

        // Must be friend
        if (!SocialWebSocketClient.getInstance().friends.containsKey(sender.toLowerCase().trim())) {
            ModLogger.logEvent("GROUP_INVITE_DECLINED", "Ignored group sync from non-friend '" + sender + "'");
            return;
        }

        String myName = ModConfig.getInstance().getEffectiveUsername();
        List<String> memberList = new ArrayList<>();
        for (String m : membersCsv.split(",")) {
            String clean = m.trim();
            if (!clean.isEmpty() && memberList.size() < 8) {
                memberList.add(clean);
            }
        }

        // Must include self
        if (!memberList.contains(myName)) {
            memberList.add(myName);
        }

        GroupInfo existing = groups.get(groupId);
        if (existing == null) {
            GroupInfo newGroup = new GroupInfo(groupId, groupName, memberList);
            groups.put(groupId, newGroup);
            groupMessages.put(groupId, new CopyOnWriteArrayList<>());
            saveAsync();

            LeftNotificationManager.showGroupMessage(groupId, groupName, sender, "Invited you to the group!");
            ModLogger.logEvent("GROUP_SYNC_CREATED", "Created group '" + groupName + "' (" + groupId + ") from sync by " + sender);

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                mc.player.sendMessage(Text.literal("§d[Offline Friends] " + sender + " added you to group §f" + groupName), false);
            }
        } else {
            existing.setName(groupName);
            existing.setMembers(memberList);
            saveAsync();
            ModLogger.logEvent("GROUP_SYNC_UPDATED", "Updated members for group '" + groupName + "' (" + groupId + ")");
        }
    }

    private void handleGroupMessage(String sender, String groupId, String rawStripped, String[] parts) {
        if (parts.length < 5) return;
        String msgId = parts[3];

        // Deduplication
        String dedupKey = groupId + ":" + sender.toLowerCase().trim() + ":" + msgId;
        if (processedMessageKeys.contains(dedupKey)) {
            return; // Duplicate
        }
        processedMessageKeys.add(dedupKey);

        // Text is remainder after 4th pipe
        int prefixLen = parts[0].length() + 1 + parts[1].length() + 1 + parts[2].length() + 1 + parts[3].length() + 1;
        String text = (prefixLen < rawStripped.length()) ? rawStripped.substring(prefixLen) : "";

        GroupInfo group = groups.get(groupId);
        String groupName = (group != null) ? group.getName() : "Group";

        GroupMessage msg = new GroupMessage(msgId, groupId, sender, text, System.currentTimeMillis());
        List<GroupMessage> list = groupMessages.computeIfAbsent(groupId, k -> new CopyOnWriteArrayList<>());
        list.add(msg);
        while (list.size() > MAX_GROUP_MESSAGES) {
            list.remove(0);
        }

        saveAsync();
        ModLogger.logEvent("GROUP_MSG_RECEIVED", "Group: " + groupName + " from " + sender + ": '" + text + "'");

        // Notification and Unread handling
        if (currentlyViewingGroupId == null || !currentlyViewingGroupId.equals(groupId)) {
            unreadCounts.merge(groupId, 1, Integer::sum);
            LeftNotificationManager.showGroupMessage(groupId, groupName, sender, text);
        }
    }

    private void handleGroupRename(String sender, String groupId, String[] parts) {
        if (parts.length < 4) return;
        String newName = sanitizeGroupName(parts[3]);
        GroupInfo group = groups.get(groupId);
        if (group != null) {
            group.setName(newName);
            addSystemMessage(groupId, sender + " renamed the group to " + newName);
            saveAsync();
            ModLogger.logEvent("GROUP_RENAMED", "Group " + groupId + " renamed by " + sender + " to " + newName);
        }
    }

    private void handleGroupLeave(String sender, String groupId) {
        GroupInfo group = groups.get(groupId);
        if (group != null) {
            group.removeMember(sender);
            addSystemMessage(groupId, sender + " left the group");
            saveAsync();
            ModLogger.logEvent("GROUP_MEMBER_LEFT", sender + " left group " + groupId);
        }
    }

    /**
     * Updates delivery status when a dm_ack packet is received from the server.
     */
    public boolean handleDmAck(String dmPacketId, String status) {
        if (dmPacketId == null || status == null) return false;

        for (List<GroupMessage> list : groupMessages.values()) {
            for (GroupMessage msg : list) {
                if (msg.getPacketIdToRecipient().containsKey(dmPacketId)) {
                    String recipient = msg.getPacketIdToRecipient().get(dmPacketId);
                    msg.getRecipientStatuses().put(recipient, status);
                    saveAsync();
                    return true;
                }
            }
        }
        return false;
    }
}
