package com.offlinefriends.social;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.offlinefriends.client.OfflineFriendsClient;
import com.offlinefriends.client.gui.SocialScreen;
import com.offlinefriends.client.notification.LeftNotificationManager;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.util.ModLogger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * SocialWebSocketClient
 * 
 * Implements Protocol Version 1 for Offline Friends Social & Tracker backend.
 * Live Endpoint: wss://my-offline-friends.onrender.com/ws
 * 
 * Features:
 * - Thread-safe single-threaded outbound network queue (guarantees WebSocket.sendText
 *   CompletableFuture completes before any subsequent frame, preventing IllegalStateException).
 * - Shared rate-limiting window (20 per 30s) across DMs and group sends with priority
 *   given to user direct messages. Pings and presence frames bypass the limit.
 * - Robust error handling: immediate 'failed' status for DMs sent while offline,
 *   plus 10-second timeout transition if dm_ack is not received.
 * - Complete presence lifecycle: offline status default for new friends until friend_update,
 *   immediate disconnect flushing, and graceful 500ms shutdown on client stop.
 * - Relay-based Position Tracking: track_pos stream from tracked player to relay,
 *   and track_pos_in stream from relay to tracker (no game-server mod required).
 */
public class SocialWebSocketClient implements WebSocket.Listener {

    private static final Gson GSON = new Gson();
    private static SocialWebSocketClient instance;

    // Friend presence entry
    public record FriendInfo(String username, boolean online, String server) {}

    public interface FriendRequestListener {
        void onFriendRequestStatus(String target, boolean success, String message);
        void onRequestsUpdated();
    }

    private final List<FriendRequestListener> friendRequestListeners = new CopyOnWriteArrayList<>();

    public void addFriendRequestListener(FriendRequestListener listener) {
        if (listener != null && !friendRequestListeners.contains(listener)) {
            friendRequestListeners.add(listener);
        }
    }

    public void removeFriendRequestListener(FriendRequestListener listener) {
        if (listener != null) {
            friendRequestListeners.remove(listener);
        }
    }

    public void notifyFriendRequestStatus(String target, boolean success, String message) {
        for (FriendRequestListener l : friendRequestListeners) {
            try { l.onFriendRequestStatus(target, success, message); } catch (Throwable ignored) {}
        }
    }

    public void notifyRequestsUpdated() {
        for (FriendRequestListener l : friendRequestListeners) {
            try { l.onRequestsUpdated(); } catch (Throwable ignored) {}
        }
    }

    public enum Priority {
        HIGH,   // User Direct Messages
        NORMAL, // Group DMs, Presence, Tracking Pos
        LOW     // Heartbeat Pings
    }

    public static class OutboundPacket implements Comparable<OutboundPacket> {
        public final JsonObject payload;
        public final Priority priority;
        public final long enqueueTime;
        public final boolean countsTowardsRateLimit;
        public final String messageId;
        public final CompletableFuture<Boolean> completionFuture;

        public OutboundPacket(JsonObject payload, Priority priority, boolean countsTowardsRateLimit, String messageId) {
            this.payload = payload;
            this.priority = priority;
            this.enqueueTime = System.currentTimeMillis();
            this.countsTowardsRateLimit = countsTowardsRateLimit;
            this.messageId = messageId;
            this.completionFuture = new CompletableFuture<>();
        }

        @Override
        public int compareTo(OutboundPacket other) {
            int pComp = Integer.compare(this.priority.ordinal(), other.priority.ordinal());
            if (pComp != 0) return pComp;
            return Long.compare(this.enqueueTime, other.enqueueTime);
        }
    }

    private WebSocket webSocket;
    private final AtomicBoolean connecting = new AtomicBoolean(false);
    private volatile boolean connected = false;
    private volatile boolean authenticated = false;
    private String lastErrorMessage = null;
    private String lastReadableError = null;

    public boolean isAuthenticated() {
        return this.connected && this.authenticated;
    }

    // Active GUI listener for instant feedback updates
    private volatile SocialScreen activeSocialScreen = null;

    // Current local game server address (e.g. "play.hypixel.net", "singleplayer", "lan", or null)
    private String localServer = null;

    // Social Data
    public final Map<String, FriendInfo> friends = new ConcurrentHashMap<>();
    public final Set<String> pendingIncomingRequests = ConcurrentHashMap.newKeySet();
    public final Set<String> pendingOutgoingRequests = ConcurrentHashMap.newKeySet();
    private volatile boolean initialWelcomeReceived = false;

    // Tracking Consent State
    private volatile String pendingOutgoingTrackTarget = null;
    public final Set<String> pendingIncomingTrackRequests = ConcurrentHashMap.newKeySet();
    private volatile String activeTrackingTarget = null;
    private volatile String activeBeingTrackedBy = null;

    // Single-threaded outbound send queue
    private final PriorityBlockingQueue<OutboundPacket> sendQueue = new PriorityBlockingQueue<>();
    private final Queue<Long> rateLimitWindow = new ConcurrentLinkedQueue<>();
    private final AtomicBoolean isRateLimited = new AtomicBoolean(false);
    private volatile long rateLimitResetTime = 0L;

    // Background Executors
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "OfflineFriends-Scheduler");
        t.setDaemon(true);
        return t;
    });

    private Thread networkSenderThread;
    private long backoffDelaySec = 2;
    private long lastMessageReceivedTime = 0;

    public static synchronized SocialWebSocketClient getInstance() {
        if (instance == null) {
            instance = new SocialWebSocketClient();
            instance.initBackgroundTasks();
        }
        return instance;
    }

    public void setActiveSocialScreen(SocialScreen screen) {
        this.activeSocialScreen = screen;
    }

    private void initBackgroundTasks() {
        // 1. Single-threaded network sender worker
        networkSenderThread = new Thread(this::runSendLoop, "OfflineFriends-NetworkSender");
        networkSenderThread.setDaemon(true);
        networkSenderThread.start();

        // 2. Heartbeat Ping Timer (every 30 seconds)
        scheduler.scheduleAtFixedRate(() -> {
            try {
                if (this.connected && this.webSocket != null) {
                    JsonObject ping = new JsonObject();
                    ping.addProperty("type", "ping");
                    sendJson(ping);

                    // Drop silent connection if no traffic received for 75 seconds
                    if (lastMessageReceivedTime > 0 && (System.currentTimeMillis() - lastMessageReceivedTime) > 75_000L) {
                        ModLogger.warn("Relay server timed out (>75s without traffic), reconnecting...");
                        reconnectAsync();
                    }
                }
            } catch (Exception e) {
                ModLogger.error("Error during scheduled ping", e);
            }
        }, 30, 30, TimeUnit.SECONDS);

        // 3. Periodic Position Broadcaster for Tracked Player (~1 Hz)
        scheduler.scheduleAtFixedRate(() -> {
            try {
                if (this.connected && activeBeingTrackedBy != null) {
                    broadcastLocalPlayerPosition(activeBeingTrackedBy);
                }
            } catch (Exception e) {
                ModLogger.warn("Error broadcasting tracked position: {}", e.getMessage());
            }
        }, 1, 1, TimeUnit.SECONDS);
    }

    /**
     * Dedicated single-threaded outbound transmission loop.
     * Guarantees each WebSocket.sendText CompletableFuture finishes before sending the next frame.
     */
    private void runSendLoop() {
        while (!Thread.currentThread().isInterrupted()) {
            OutboundPacket packet = null;
            try {
                packet = sendQueue.take();

                if (this.webSocket == null || !this.connected) {
                    ModLogger.logEvent("SEND_FAILED_OFFLINE", "Dropped packet type '" +
                            (packet.payload.has("type") ? packet.payload.get("type").getAsString() : "unknown") +
                            "': WebSocket disconnected");
                    if (packet.messageId != null) {
                        ChatHistoryManager.getInstance().updateMessageStatus(packet.messageId, "failed");
                    }
                    packet.completionFuture.complete(false);
                    continue;
                }

                // Shared Rate-Limiting Window for DMs and group messages (20 per 30s)
                if (packet.countsTowardsRateLimit) {
                    long now = System.currentTimeMillis();
                    while (!rateLimitWindow.isEmpty() && (now - rateLimitWindow.peek()) > 30_000L) {
                        rateLimitWindow.poll();
                    }

                    if (rateLimitResetTime > 0 && now >= rateLimitResetTime) {
                        isRateLimited.set(false);
                        rateLimitResetTime = 0L;
                    }

                    if (rateLimitWindow.size() >= 19 || isRateLimited.get()) {
                        isRateLimited.set(true);
                        Long oldest = rateLimitWindow.peek();
                        long waitTime = oldest != null ? Math.max(100L, 30_000L - (now - oldest) + 50L) : 1000L;
                        ModLogger.logEvent("RATE_LIMIT_QUEUE", "Outbound DM queue waiting " + waitTime + "ms for rate-limit window");

                        if (packet.priority == Priority.HIGH) {
                            // User DM: mark queued visually if waiting longer than 1 second
                            if (packet.messageId != null && waitTime > 1000L) {
                                ChatHistoryManager.getInstance().updateMessageStatus(packet.messageId, "queued");
                            }
                        }

                        Thread.sleep(Math.min(waitTime, 2000L));
                        now = System.currentTimeMillis();
                        while (!rateLimitWindow.isEmpty() && (now - rateLimitWindow.peek()) > 30_000L) {
                            rateLimitWindow.poll();
                        }
                    }
                }

                // Execute synchronous transmission and await completion
                String jsonStr = GSON.toJson(packet.payload);
                CompletableFuture<WebSocket> future = this.webSocket.sendText(jsonStr, true);
                future.get(5, TimeUnit.SECONDS);

                if (packet.countsTowardsRateLimit) {
                    rateLimitWindow.add(System.currentTimeMillis());
                }
                packet.completionFuture.complete(true);

                // Short 50ms pause between consecutive frames to prevent socket buffer churn
                Thread.sleep(50);
            } catch (InterruptedException ie) {
                break;
            } catch (Throwable t) {
                ModLogger.error("Failed to send WebSocket text frame", t);
                if (packet != null) {
                    if (packet.messageId != null) {
                        ChatHistoryManager.getInstance().updateMessageStatus(packet.messageId, "failed");
                    }
                    packet.completionFuture.complete(false);
                }
            }
        }
    }

    /**
     * Broadcasts current Minecraft player coords over relay to active tracker.
     */
    private void broadcastLocalPlayerPosition(String trackerUsername) {
        if (trackerUsername == null || trackerUsername.trim().isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.world == null) return;

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "track_pos");
        obj.addProperty("with", trackerUsername.trim());
        obj.addProperty("x", mc.player.getX());
        obj.addProperty("y", mc.player.getY());
        obj.addProperty("z", mc.player.getZ());
        obj.addProperty("dim", mc.world.getRegistryKey().getValue().toString());
        obj.addProperty("health", mc.player.getHealth());
        obj.addProperty("maxHealth", mc.player.getMaxHealth());

        String srv = ModConfig.getInstance().isShareMyServer() ? this.localServer : null;
        if (srv != null) {
            obj.addProperty("server", srv);
        } else {
            obj.add("server", JsonNull.INSTANCE);
        }

        sendJson(obj);
    }

    /**
     * Connects asynchronously. Never blocks render thread.
     */
    public synchronized void connect() {
        String serverAddress = ModConfig.getInstance().getRelayUrl();
        if (serverAddress == null || serverAddress.trim().isEmpty()) {
            disconnect();
            return;
        }

        if (this.connected || this.connecting.get()) {
            return;
        }

        this.connecting.set(true);

        scheduler.execute(() -> {
            try {
                final String finalTargetUrl = (serverAddress.startsWith("ws://") || serverAddress.startsWith("wss://"))
                        ? serverAddress.trim()
                        : "ws://" + serverAddress.trim();

                URI uri = URI.create(finalTargetUrl);
                HttpClient client = HttpClient.newBuilder()
                        .connectTimeout(Duration.ofSeconds(6))
                        .build();

                client.newWebSocketBuilder()
                        .connectTimeout(Duration.ofSeconds(6))
                        .buildAsync(uri, this)
                        .thenAccept(ws -> {
                            this.webSocket = ws;
                            this.connected = true;
                            this.connecting.set(false);
                            this.backoffDelaySec = 2;
                            this.lastErrorMessage = null;
                            this.lastReadableError = null;
                            this.lastMessageReceivedTime = System.currentTimeMillis();
                            ModLogger.info("Connected to Offline Friends Relay Server at {}", finalTargetUrl);
                            ModLogger.logEvent("CONNECTION_STATE", "Connected to " + finalTargetUrl);

                            // Send Hello Handshake
                            sendHello();
                        })
                        .exceptionally(ex -> {
                            this.connected = false;
                            this.connecting.set(false);
                            this.lastErrorMessage = ex.getMessage();
                            this.lastReadableError = "Relay server offline or unreachable";
                            ModLogger.warn("Failed to connect to relay server: {}", ex.getMessage());
                            ModLogger.logEvent("CONNECTION_STATE", "Connection failed: " + ex.getMessage());
                            markFriendsDisconnected();
                            scheduleReconnect();
                            return null;
                        });
            } catch (Throwable t) {
                this.connecting.set(false);
                this.connected = false;
                this.lastErrorMessage = t.getMessage();
                this.lastReadableError = "Failed to initialize network client: " + t.getMessage();
                ModLogger.error("Failed to initialize WebSocket client", t);
                markFriendsDisconnected();
                scheduleReconnect();
            }
        });
    }

    private void scheduleReconnect() {
        String addr = ModConfig.getInstance().getRelayUrl();
        if (addr == null || addr.isEmpty()) return;

        long delay = backoffDelaySec;
        backoffDelaySec = Math.min(30, backoffDelaySec * 2);

        scheduler.schedule(() -> {
            if (!connected && !connecting.get() && !ModConfig.getInstance().getRelayUrl().isEmpty()) {
                connect();
            }
        }, delay, TimeUnit.SECONDS);
    }

    public synchronized void reconnectAsync() {
        disconnect();
        scheduler.schedule(this::connect, 1, TimeUnit.SECONDS);
    }

    public synchronized void disconnect() {
        try {
            if (this.webSocket != null) {
                this.webSocket.sendClose(WebSocket.NORMAL_CLOSURE, "Client shutdown");
            }
        } catch (Throwable t) {
            ModLogger.warn("WebSocket close exception: {}", t.getMessage());
        } finally {
            this.webSocket = null;
            this.connected = false;
            this.authenticated = false;
            this.connecting.set(false);
            markFriendsDisconnected();
            ModLogger.logEvent("CONNECTION_STATE", "Disconnected");
        }
    }

    /**
     * Flushes presence and performs clean closure on Minecraft client stop.
     */
    public void shutdownGracefully() {
        try {
            if (this.webSocket != null && this.connected) {
                JsonObject presence = new JsonObject();
                presence.addProperty("type", "presence");
                presence.addProperty("invisible", true);
                presence.add("server", JsonNull.INSTANCE);

                String jsonStr = GSON.toJson(presence);
                try {
                    this.webSocket.sendText(jsonStr, true).get(500, TimeUnit.MILLISECONDS);
                } catch (Exception ignored) {}

                try {
                    this.webSocket.sendClose(WebSocket.NORMAL_CLOSURE, "Client shutdown")
                            .get(500, TimeUnit.MILLISECONDS);
                } catch (Exception ignored) {}
            }
        } catch (Throwable t) {
            ModLogger.warn("Error during graceful shutdown: {}", t.getMessage());
        } finally {
            this.webSocket = null;
            this.connected = false;
            this.connecting.set(false);
            markFriendsDisconnected();
            ModLogger.logEvent("CONNECTION_STATE", "Client stopping - shutdown completed");
        }
    }

    /**
     * Marks all friends as offline when my own connection drops, preventing stale online labels.
     */
    public void markFriendsDisconnected() {
        for (Map.Entry<String, FriendInfo> entry : friends.entrySet()) {
            FriendInfo old = entry.getValue();
            friends.put(entry.getKey(), new FriendInfo(old.username(), false, null));
        }
    }

    public void onWorldDisconnect() {
        if (activeTrackingTarget != null) {
            sendTrackStop(activeTrackingTarget);
            activeTrackingTarget = null;
        }
        if (activeBeingTrackedBy != null) {
            sendTrackStop(activeBeingTrackedBy);
            activeBeingTrackedBy = null;
        }
        OfflineFriendsClient.clearTrackedTarget();
    }

    public void setLocalServer(String server) {
        this.localServer = server;
        if (this.connected) {
            sendPresence();
        }
    }

    public String getLocalServer() {
        return localServer;
    }

    public boolean isRateLimited() {
        return isRateLimited.get() || (rateLimitResetTime > 0 && System.currentTimeMillis() < rateLimitResetTime);
    }

    // ==========================================
    // Outgoing Protocol Messages (Client -> Server)
    // ==========================================

    private void sendHello() {
        ModConfig config = ModConfig.getInstance();
        String username = config.getEffectiveUsername();

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "hello");
        obj.addProperty("protocol", 1);
        obj.addProperty("username", username);
        obj.addProperty("token", config.getToken());
        obj.addProperty("invisible", config.isInvisible());

        String reportedServer = config.isShareMyServer() ? this.localServer : null;
        if (reportedServer != null) {
            obj.addProperty("server", reportedServer);
        } else {
            obj.add("server", JsonNull.INSTANCE);
        }

        ModLogger.logEvent("HELLO_SENT", "Username: '" + username + "', Invisible: " + config.isInvisible() + ", Server: " + reportedServer);
        sendJson(obj);
    }

    public void sendPresence() {
        ModConfig config = ModConfig.getInstance();
        JsonObject obj = new JsonObject();
        obj.addProperty("type", "presence");
        obj.addProperty("invisible", config.isInvisible());

        String reportedServer = config.isShareMyServer() ? this.localServer : null;
        if (reportedServer != null) {
            obj.addProperty("server", reportedServer);
        } else {
            obj.add("server", JsonNull.INSTANCE);
        }

        sendJson(obj);
    }

    public void sendFriendRequest(String toUsername) {
        if (toUsername == null || toUsername.trim().isEmpty()) return;
        String cleanTarget = toUsername.trim();

        if (!isAuthenticated()) {
            String reason = lastReadableError != null ? lastReadableError : "Not authenticated with relay server";
            ModLogger.logEvent("FRIEND_REQUEST_BLOCKED", "Cannot send request to " + cleanTarget + ": " + reason);
            if (activeSocialScreen != null) {
                activeSocialScreen.setFeedback("Cannot send request: " + reason, true);
            }
            notifyFriendRequestStatus(cleanTarget, false, "Not connected to the relay");
            return;
        }

        pendingOutgoingRequests.add(cleanTarget);
        ModLogger.logEvent("FRIEND_REQUEST_SENT", "Target: '" + cleanTarget + "'");

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "friend_request");
        obj.addProperty("to", cleanTarget);
        sendJson(obj);

        notifyFriendRequestStatus(cleanTarget, true, "Request sent to " + cleanTarget);
        notifyRequestsUpdated();
    }

    public void cancelOutgoingFriendRequest(String targetUsername) {
        if (targetUsername == null) return;
        String clean = targetUsername.trim();
        pendingOutgoingRequests.remove(clean);
        ModLogger.logEvent("FRIEND_REQUEST_CANCELLED", "Target: '" + clean + "'");
        notifyRequestsUpdated();
    }

    public void sendFriendAccept(String fromUsername) {
        if (fromUsername == null) return;
        String cleanRequester = fromUsername.trim();

        pendingIncomingRequests.remove(cleanRequester);
        ModLogger.logEvent("FRIEND_ACCEPT_SENT", "Requester: '" + cleanRequester + "'");

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "friend_accept");
        obj.addProperty("from", cleanRequester);
        sendJson(obj);

        notifyRequestsUpdated();
    }

    public void sendFriendDecline(String fromUsername) {
        if (fromUsername == null) return;
        String cleanRequester = fromUsername.trim();

        pendingIncomingRequests.remove(cleanRequester);
        ModLogger.logEvent("FRIEND_DECLINE_SENT", "Requester: '" + cleanRequester + "'");

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "friend_decline");
        obj.addProperty("from", cleanRequester);
        sendJson(obj);

        notifyRequestsUpdated();
    }

    public void sendFriendRemove(String username) {
        if (username == null) return;
        String clean = username.trim();

        friends.remove(clean.toLowerCase());
        pendingOutgoingRequests.remove(clean);
        pendingIncomingRequests.remove(clean);
        ModLogger.logEvent("FRIEND_REMOVE_SENT", "Username: '" + clean + "'");

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "friend_remove");
        obj.addProperty("username", clean);
        sendJson(obj);

        notifyRequestsUpdated();
    }

    /**
     * Sends a direct message with immediate offline detection, single send-queue routing,
     * and 10-second ACK timeout tracking.
     */
    public boolean sendDirectMessage(String toUsername, String text) {
        if (toUsername == null || text == null || text.trim().isEmpty()) return false;
        String cleanText = text.trim();
        if (cleanText.length() > 256) {
            cleanText = cleanText.substring(0, 256);
        }

        String myName = ModConfig.getInstance().getEffectiveUsername();
        String msgId = UUID.randomUUID().toString();

        // Check if client is READY (connected)
        if (!this.connected || this.webSocket == null) {
            ChatHistoryManager.DirectMessage localMsg = new ChatHistoryManager.DirectMessage(
                    msgId, myName, toUsername, cleanText, System.currentTimeMillis(), "failed"
            );
            ChatHistoryManager.getInstance().addMessage(localMsg, false);
            if (activeSocialScreen != null) {
                activeSocialScreen.setFeedback("Not connected: Cannot send message to " + toUsername, true);
            }
            ModLogger.logEvent("DM_SEND_FAILED", "Not connected: Dropped DM " + msgId + " to " + toUsername);
            return false;
        }

        // Add locally as "sending"
        ChatHistoryManager.DirectMessage localMsg = new ChatHistoryManager.DirectMessage(
                msgId, myName, toUsername, cleanText, System.currentTimeMillis(), "sending"
        );
        ChatHistoryManager.getInstance().addMessage(localMsg, false);

        // Build DM packet
        JsonObject obj = new JsonObject();
        obj.addProperty("type", "dm");
        obj.addProperty("id", msgId);
        obj.addProperty("to", toUsername.trim());
        obj.addProperty("text", cleanText);

        // High priority queueing
        OutboundPacket packet = new OutboundPacket(obj, Priority.HIGH, true, msgId);
        sendQueue.add(packet);

        ModLogger.logEvent("DM_SENT", "Queued DM " + msgId + " to " + toUsername + " ('" + cleanText + "')");

        // 10-second timeout checker for dm_ack
        scheduler.schedule(() -> {
            ChatHistoryManager.DirectMessage dm = ChatHistoryManager.getInstance().getMessage(msgId);
            if (dm != null && "sending".equalsIgnoreCase(dm.getStatus())) {
                dm.setStatus("failed");
                ChatHistoryManager.getInstance().updateMessageStatus(msgId, "failed");
                ModLogger.logEvent("DM_TIMEOUT", "DM " + msgId + " timed out after 10s without ACK; marked failed");
            }
        }, 10, TimeUnit.SECONDS);

        return true;
    }

    /**
     * Enqueues a group DM through the shared outbound queue.
     */
    public boolean sendGroupDm(String to, String text, String dmPacketId, String groupMsgId, String groupId) {
        if (!this.connected || this.webSocket == null) {
            ModLogger.logEvent("GROUP_SEND_FAILED", "Not connected: Dropped group DM packet " + dmPacketId + " to " + to);
            return false;
        }

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "dm");
        obj.addProperty("id", dmPacketId);
        obj.addProperty("to", to.trim());
        obj.addProperty("text", text);

        OutboundPacket packet = new OutboundPacket(obj, Priority.NORMAL, true, dmPacketId);
        sendQueue.add(packet);
        return true;
    }

    public void sendTrackRequest(String toUsername) {
        if (toUsername == null || toUsername.trim().isEmpty()) return;
        this.pendingOutgoingTrackTarget = toUsername.trim();

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "track_request");
        obj.addProperty("to", toUsername.trim());
        sendJson(obj);
        ModLogger.logEvent("TRACK_REQUEST_SENT", "Target: '" + toUsername.trim() + "'");
    }

    public void sendTrackAccept(String fromUsername) {
        if (fromUsername == null) return;
        pendingIncomingTrackRequests.remove(fromUsername.trim());
        this.activeBeingTrackedBy = fromUsername.trim();

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "track_accept");
        obj.addProperty("from", fromUsername.trim());
        sendJson(obj);
        ModLogger.logEvent("TRACK_ACCEPT_SENT", "Accepting tracking from: '" + fromUsername.trim() + "'");
    }

    public void sendTrackDecline(String fromUsername) {
        if (fromUsername == null) return;
        pendingIncomingTrackRequests.remove(fromUsername.trim());

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "track_decline");
        obj.addProperty("from", fromUsername.trim());
        sendJson(obj);
        ModLogger.logEvent("TRACK_DECLINE_SENT", "Declined tracking from: '" + fromUsername.trim() + "'");
    }

    public void sendTrackStop(String withUsername) {
        if (withUsername == null) return;
        if (withUsername.equalsIgnoreCase(activeTrackingTarget)) {
            activeTrackingTarget = null;
            OfflineFriendsClient.clearTrackedTarget();
        }
        if (withUsername.equalsIgnoreCase(activeBeingTrackedBy)) {
            activeBeingTrackedBy = null;
        }

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "track_stop");
        obj.addProperty("with", withUsername.trim());
        sendJson(obj);
        ModLogger.logEvent("TRACK_STOP_SENT", "Stopped tracking session with: '" + withUsername.trim() + "'");
    }

    /**
     * Enqueues an outgoing JSON packet through the single-threaded queue.
     */
    public boolean sendJson(JsonObject obj) {
        if (obj == null) return false;
        if (this.webSocket == null || !this.connected) {
            return false;
        }

        String type = obj.has("type") ? obj.get("type").getAsString() : "";
        Priority priority;
        boolean countsTowardsRateLimit;

        switch (type) {
            case "dm" -> {
                priority = Priority.HIGH;
                countsTowardsRateLimit = true;
            }
            case "ping" -> {
                priority = Priority.LOW;
                countsTowardsRateLimit = false;
            }
            default -> {
                priority = Priority.NORMAL;
                countsTowardsRateLimit = false;
            }
        }

        OutboundPacket packet = new OutboundPacket(obj, priority, countsTowardsRateLimit, null);
        sendQueue.add(packet);
        return true;
    }

    // ==========================================
    // Incoming Protocol Messages (Server -> Client)
    // ==========================================

    @Override
    public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
        this.lastMessageReceivedTime = System.currentTimeMillis();

        try {
            JsonObject json = GSON.fromJson(data.toString(), JsonObject.class);
            if (json != null && json.has("type")) {
                String type = json.get("type").getAsString();
                handleIncomingPacket(type, json);
            }
        } catch (Exception e) {
            ModLogger.error("Failed to parse incoming WebSocket message: " + data, e);
        }

        return WebSocket.Listener.super.onText(webSocket, data, last);
    }

    private void handleIncomingPacket(String type, JsonObject json) {
        switch (type) {
            case "welcome" -> handleWelcome(json);
            case "friend_request_in" -> handleFriendRequestIn(json);
            case "friend_added" -> handleFriendAdded(json);
            case "friend_removed" -> handleFriendRemoved(json);
            case "friend_update" -> handleFriendUpdate(json);
            case "dm_in" -> handleDmIn(json);
            case "dm_ack" -> handleDmAck(json);
            case "track_request_in" -> handleTrackRequestIn(json);
            case "track_accepted" -> handleTrackAccepted(json);
            case "track_declined" -> handleTrackDeclined(json);
            case "track_stopped" -> handleTrackStopped(json);
            case "track_pos_in" -> handleTrackPosIn(json);
            case "error" -> handleError(json);
            case "pong" -> { /* Heartbeat ACK */ }
            default -> ModLogger.warn("Received unknown packet type: {}", type);
        }
    }

    private void handleWelcome(JsonObject json) {
        this.authenticated = true;
        this.lastErrorMessage = null;
        this.lastReadableError = null;
        if (json.has("friends") && json.get("friends").isJsonArray()) {
            friends.clear();
            JsonArray arr = json.getAsJsonArray("friends");
            for (JsonElement el : arr) {
                if (el.isJsonObject()) {
                    JsonObject f = el.getAsJsonObject();
                    String user = f.get("username").getAsString();
                    boolean online = f.has("online") && f.get("online").getAsBoolean();
                    String srv = (f.has("server") && !f.get("server").isJsonNull()) ? f.get("server").getAsString() : null;
                    friends.put(user.toLowerCase(), new FriendInfo(user, online, srv));
                }
            }
        }

        if (json.has("pending_in") && json.get("pending_in").isJsonArray()) {
            pendingIncomingRequests.clear();
            JsonArray arr = json.getAsJsonArray("pending_in");
            boolean autoAccept = ModConfig.getInstance().isAutoAcceptFriends();

            for (JsonElement el : arr) {
                String requester = el.getAsString();
                if (ModConfig.getInstance().isUserBlocked(requester)) {
                    ModLogger.logEvent("BLOCKED_FRIEND_REQUEST_DROPPED", "Dropped welcome pending request from blocked user: '" + requester + "'");
                    continue;
                }

                if (autoAccept) {
                    sendFriendAccept(requester);
                    // Default to offline until friend_update arrives!
                    friends.put(requester.toLowerCase(), new FriendInfo(requester, false, null));
                    sendPresence();
                    LeftNotificationManager.showFriendAccepted(requester);
                    ModLogger.logEvent("AUTO_ACCEPT_WELCOME", "Auto-accepted friend request from: '" + requester + "'");

                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc != null && mc.player != null) {
                        mc.player.sendMessage(Text.literal("§a[Offline Friends] Auto-accepted friend request from: §f" + requester), false);
                    }
                } else {
                    pendingIncomingRequests.add(requester);
                    LeftNotificationManager.showFriendRequest(requester);

                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc != null && mc.player != null) {
                        mc.player.sendMessage(Text.literal("§e[Offline Friends] You have a pending friend request from: §f" + requester), false);
                    }
                }
            }
        }

        ModLogger.logEvent("WELCOME_RECEIVED", "Friends count: " + friends.size() + ", Pending requests: " + pendingIncomingRequests.size());

        if (json.has("queued_dms") && json.get("queued_dms").isJsonArray()) {
            JsonArray arr = json.getAsJsonArray("queued_dms");
            for (JsonElement el : arr) {
                if (el.isJsonObject()) {
                    JsonObject dm = el.getAsJsonObject();
                    String id = dm.has("id") ? dm.get("id").getAsString() : UUID.randomUUID().toString();
                    String from = dm.has("from") ? dm.get("from").getAsString() : "Friend";
                    String text = dm.has("text") ? dm.get("text").getAsString() : "";
                    long ts = dm.has("ts") ? dm.get("ts").getAsLong() : System.currentTimeMillis();

                    // Check for group protocol packet
                    if (GroupManager.getInstance().handleIncomingGroupDm(from, text)) {
                        continue;
                    }

                    if (ModConfig.getInstance().isUserBlocked(from)) {
                        ModLogger.logEvent("BLOCKED_DM_DROPPED", "Dropped queued DM from blocked user: '" + from + "'");
                        continue;
                    }

                    String myName = ModConfig.getInstance().getEffectiveUsername();
                    ChatHistoryManager.DirectMessage msg = new ChatHistoryManager.DirectMessage(id, from, myName, text, ts, "delivered");
                    ChatHistoryManager.getInstance().addMessage(msg, true);

                    if (!ModConfig.getInstance().isFriendMuted(from)) {
                        LeftNotificationManager.showDirectMessage(from, text);
                    }
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc != null && mc.player != null) {
                        mc.player.sendMessage(Text.literal("§7[Offline Friends] §b" + from + "§7 (offline message): §f" + text), false);
                    }
                }
            }
        }

        this.initialWelcomeReceived = true;
    }

    private void handleFriendRequestIn(JsonObject json) {
        if (json.has("from")) {
            String from = json.get("from").getAsString();

            if (ModConfig.getInstance().isUserBlocked(from)) {
                ModLogger.logEvent("BLOCKED_FRIEND_REQUEST_DROPPED", "Dropped incoming friend request from blocked user: '" + from + "'");
                return;
            }

            ModLogger.logEvent("FRIEND_REQUEST_IN", "From: '" + from + "'");

            if (ModConfig.getInstance().isAutoAcceptFriends()) {
                sendFriendAccept(from);
                // Create as offline until friend_update arrives!
                friends.put(from.toLowerCase(), new FriendInfo(from, false, null));
                sendPresence();
                LeftNotificationManager.showFriendAccepted(from);
                ModLogger.logEvent("AUTO_ACCEPT_REQUEST", "Auto-accepted friend request from: '" + from + "'");

                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc != null && mc.player != null) {
                    mc.player.sendMessage(Text.literal("§a[Offline Friends] §f" + from + " §ais now your friend! (Auto-accepted)"), false);
                }

                if (activeSocialScreen != null) {
                    activeSocialScreen.setFeedback(from + " is now your friend! (Auto-accepted)", false);
                }
            } else {
                pendingIncomingRequests.add(from);
                LeftNotificationManager.showFriendRequest(from);

                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc != null && mc.player != null) {
                    mc.player.sendMessage(Text.literal("§e[Offline Friends] §f" + from + " §7sent you a friend request!"), false);
                }

                if (activeSocialScreen != null) {
                    activeSocialScreen.setFeedback("New friend request received from " + from + "!", false);
                }
            }
            notifyRequestsUpdated();
        }
    }

    private void handleFriendAdded(JsonObject json) {
        if (json.has("username")) {
            String username = json.get("username").getAsString();
            boolean online = json.has("online") && json.get("online").getAsBoolean();
            String srv = (json.has("server") && !json.get("server").isJsonNull()) ? json.get("server").getAsString() : null;

            friends.put(username.toLowerCase(), new FriendInfo(username, online, srv));
            pendingIncomingRequests.remove(username);
            pendingOutgoingRequests.remove(username);
            ModLogger.logEvent("FRIEND_ADDED", "Username: '" + username + "', Online: " + online + ", Server: " + srv);

            // Send presence so the other side receives my state!
            sendPresence();

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                mc.player.sendMessage(Text.literal("§a[Offline Friends] You and §f" + username + " §aare now friends!"), false);
            }

            if (activeSocialScreen != null) {
                activeSocialScreen.setFeedback("You and " + username + " are now friends!", false);
            }

            notifyFriendRequestStatus(username, true, "You and " + username + " are now friends!");
            notifyRequestsUpdated();
        }
    }

    private void handleFriendRemoved(JsonObject json) {
        if (json.has("username")) {
            String username = json.get("username").getAsString();
            friends.remove(username.toLowerCase());
            pendingOutgoingRequests.remove(username);
            pendingIncomingRequests.remove(username);
            ModLogger.logEvent("FRIEND_REMOVED", "Username: '" + username + "'");

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                mc.player.sendMessage(Text.literal("§c[Offline Friends] §f" + username + " §7was removed from your friends list."), false);
            }

            if (activeSocialScreen != null) {
                activeSocialScreen.setFeedback(username + " was removed from your friends list.", false);
            }

            notifyRequestsUpdated();
        }
    }

    private void handleFriendUpdate(JsonObject json) {
        if (json.has("username")) {
            String username = json.get("username").getAsString();
            boolean online = json.has("online") && json.get("online").getAsBoolean();
            String srv = (json.has("server") && !json.get("server").isJsonNull()) ? json.get("server").getAsString() : null;

            FriendInfo previous = friends.get(username.toLowerCase());
            boolean wasOnline = previous != null && previous.online();

            friends.put(username.toLowerCase(), new FriendInfo(username, online, srv));

            if (!wasOnline && online) {
                // Online Notification on Left HUD
                if (this.initialWelcomeReceived 
                        && ModConfig.getInstance().isOnlineNotificationsEnabled()
                        && !ModConfig.getInstance().isUserBlocked(username)
                        && !ModConfig.getInstance().isFriendMuted(username)) {
                    LeftNotificationManager.showFriendOnline(username, srv);
                    ModLogger.logEvent("FRIEND_ONLINE_NOTIFICATION", "Friend " + username + " came online, server: " + srv);
                }

                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc != null && mc.player != null) {
                    String msg = "§a[Offline Friends] §f" + username + " §7is now online" + (srv != null ? " · playing on " + srv : ".");
                    mc.player.sendMessage(Text.literal(msg), false);
                }
            }
        }
    }

    private void handleDmIn(JsonObject json) {
        String id = json.has("id") ? json.get("id").getAsString() : UUID.randomUUID().toString();
        String from = json.has("from") ? json.get("from").getAsString() : "Friend";
        String text = json.has("text") ? json.get("text").getAsString() : "";
        long ts = json.has("ts") ? json.get("ts").getAsLong() : System.currentTimeMillis();

        // 1. Intercept Group Message protocol frames
        if (GroupManager.getInstance().handleIncomingGroupDm(from, text)) {
            return;
        }

        // 2. Blocked Check
        if (ModConfig.getInstance().isUserBlocked(from)) {
            ModLogger.logEvent("BLOCKED_DM_DROPPED", "Dropped direct message from blocked user: '" + from + "'");
            return;
        }

        String myName = ModConfig.getInstance().getEffectiveUsername();
        ChatHistoryManager.DirectMessage msg = new ChatHistoryManager.DirectMessage(id, from, myName, text, ts, "delivered");
        ChatHistoryManager.getInstance().addMessage(msg, true);

        // Show left-side sliding notification if not muted
        if (!ModConfig.getInstance().isFriendMuted(from)) {
            LeftNotificationManager.showDirectMessage(from, text);
        }

        // Display in chat
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.player != null) {
            mc.player.sendMessage(Text.literal("§d[Offline Friends] §b" + from + " §7-> §f" + text), false);
        }
    }

    private void handleDmAck(JsonObject json) {
        if (json.has("id") && json.has("status")) {
            String id = json.get("id").getAsString();
            String status = json.get("status").getAsString(); // "delivered" | "queued" | "failed"

            // Update Group Manager if part of a group message
            GroupManager.getInstance().handleDmAck(id, status);

            // Update Direct Messages
            ChatHistoryManager.getInstance().updateMessageStatus(id, status);
        }
    }

    private void handleTrackRequestIn(JsonObject json) {
        if (json.has("from")) {
            String from = json.get("from").getAsString();

            if (ModConfig.getInstance().isUserBlocked(from)) {
                ModLogger.logEvent("BLOCKED_TRACK_DROPPED", "Dropped track request from blocked user: '" + from + "'");
                return;
            }

            pendingIncomingTrackRequests.add(from);
            LeftNotificationManager.showTrackRequest(from);

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                mc.player.sendMessage(Text.literal("§e[Offline Friends] §f" + from + " §7requested to track your location! (Open Tracker 'O' to accept)"), false);
            }
        }
    }

    private void handleTrackAccepted(JsonObject json) {
        if (json.has("by")) {
            String by = json.get("by").getAsString();
            if (by.equalsIgnoreCase(pendingOutgoingTrackTarget)) {
                this.pendingOutgoingTrackTarget = null;
                this.activeTrackingTarget = by;
                OfflineFriendsClient.setTrackingVisualsEnabled(true);
                ModLogger.logEvent("TRACK_ACCEPTED", "Target " + by + " accepted our tracking request");

                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc != null && mc.player != null) {
                    mc.player.sendMessage(Text.literal("§a[Offline Friends] §f" + by + " §aaccepted your tracking request!"), false);
                }
            }
        }
    }

    private void handleTrackDeclined(JsonObject json) {
        if (json.has("by")) {
            String by = json.get("by").getAsString();
            if (by.equalsIgnoreCase(pendingOutgoingTrackTarget)) {
                this.pendingOutgoingTrackTarget = null;
                ModLogger.logEvent("TRACK_DECLINED", "Target " + by + " declined tracking request");
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc != null && mc.player != null) {
                    mc.player.sendMessage(Text.literal("§c[Offline Friends] §f" + by + " §cdeclined your tracking request."), false);
                }
            }
        }
    }

    private void handleTrackStopped(JsonObject json) {
        if (json.has("by")) {
            String by = json.get("by").getAsString();
            if (by.equalsIgnoreCase(activeTrackingTarget)) {
                activeTrackingTarget = null;
                OfflineFriendsClient.clearTrackedTarget();
            }
            if (by.equalsIgnoreCase(activeBeingTrackedBy)) {
                activeBeingTrackedBy = null;
            }
            ModLogger.logEvent("TRACK_STOPPED", "Tracking session with " + by + " stopped");

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                mc.player.sendMessage(Text.literal("§e[Offline Friends] Tracking session with §f" + by + " §ehas ended."), false);
            }
        }
    }

    private void handleTrackPosIn(JsonObject json) {
        if (json.has("from")) {
            String from = json.get("from").getAsString();

            if (activeTrackingTarget != null && activeTrackingTarget.equalsIgnoreCase(from)) {
                double x = json.has("x") ? json.get("x").getAsDouble() : 0.0;
                double y = json.has("y") ? json.get("y").getAsDouble() : 0.0;
                double z = json.has("z") ? json.get("z").getAsDouble() : 0.0;
                String dim = json.has("dim") && !json.get("dim").isJsonNull() ? json.get("dim").getAsString() : "unknown";
                float health = json.has("health") ? json.get("health").getAsFloat() : 0.0f;
                float maxHealth = json.has("maxHealth") ? json.get("maxHealth").getAsFloat() : 0.0f;
                String srv = json.has("server") && !json.get("server").isJsonNull() ? json.get("server").getAsString() : null;

                OfflineFriendsClient.setCurrentTrackedTarget(new OfflineFriendsClient.TrackedTarget(
                        from,
                        true,
                        x, y, z,
                        dim,
                        health, maxHealth,
                        srv,
                        System.currentTimeMillis()
                ));
            }
        }
    }

    private void handleError(JsonObject json) {
        String code = json.has("code") ? json.get("code").getAsString() : "unknown";
        String msg = json.has("message") ? json.get("message").getAsString() : "An error occurred";
        String fullPayload = GSON.toJson(json);

        // Never ignore a server error: log to offlinefriends-debug.log with type and full text
        ModLogger.logEvent("SERVER_ERROR", "Type: 'error', Code: '" + code + "', Message: '" + msg + "', Payload: " + fullPayload);

        this.lastErrorMessage = msg;

        // Translate code into readable words
        String readable;
        switch (code) {
            case "bad_token" -> {
                readable = "Authentication failed: Username already registered with another token. (If sharing an account on 2 phones, set a distinct username in Settings).";
                this.authenticated = false;
                this.connected = false;
            }
            case "name_taken" -> {
                readable = "Connection rejected: Username is already online from another device! (Set a distinct username in Settings to connect both phones).";
                this.authenticated = false;
                this.connected = false;
            }
            case "rate_limited" -> {
                isRateLimited.set(true);
                rateLimitResetTime = System.currentTimeMillis() + 30_000L;
                readable = "Rate limited by relay: please wait 30 seconds";
            }
            case "not_friends" -> readable = "Action failed: You must be friends with this player";
            case "invalid" -> {
                String low = msg.toLowerCase();
                if (low.contains("yourself")) readable = "Cannot send friend request to yourself";
                else if (low.contains("recipient")) readable = "Invalid recipient name (must be 3-16 chars: letters, digits, _)";
                else if (low.contains("already")) readable = "Already friends or request already pending";
                else if (low.contains("hello first")) {
                    readable = "Session unauthenticated on relay (must send hello first). Set a distinct username in Settings and reconnect.";
                    this.authenticated = false;
                    this.connected = false;
                }
                else readable = "Invalid request: " + msg;
            }
            default -> readable = "Server Error [" + code + "]: " + msg;
        }

        this.lastReadableError = readable;

        // Clean up pending outgoing if it failed
        if (!pendingOutgoingRequests.isEmpty()) {
            pendingOutgoingRequests.clear();
        }

        // Display in active GUI if open
        if (activeSocialScreen != null) {
            activeSocialScreen.setFeedback(readable, true);
        }

        notifyFriendRequestStatus(null, false, readable);
        notifyRequestsUpdated();

        // Display in chat
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.player != null) {
            mc.player.sendMessage(Text.literal("§c[Offline Friends Error] " + readable), false);
        }
    }

    @Override
    public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
        this.connected = false;
        this.connecting.set(false);
        markFriendsDisconnected();
        ModLogger.logEvent("CONNECTION_STATE", "WebSocket closed: " + statusCode + " - " + reason);
        scheduleReconnect();
        return WebSocket.Listener.super.onClose(webSocket, statusCode, reason);
    }

    @Override
    public void onError(WebSocket webSocket, Throwable error) {
        this.connected = false;
        this.connecting.set(false);
        this.lastErrorMessage = error != null ? error.getMessage() : "Connection error";
        this.lastReadableError = "Connection error: " + (error != null ? error.getMessage() : "Unknown");
        markFriendsDisconnected();
        ModLogger.error("WebSocket connection error", error);
        ModLogger.logEvent("CONNECTION_STATE", "WebSocket error: " + (error != null ? error.getMessage() : "unknown"));
        scheduleReconnect();
    }

    public boolean isConnected() {
        return connected;
    }

    public boolean isConnecting() {
        return connecting.get();
    }

    public String getServerAddress() {
        return ModConfig.getInstance().getRelayUrl();
    }

    public String getPendingOutgoingTrackTarget() {
        return pendingOutgoingTrackTarget;
    }

    public String getActiveTrackingTarget() {
        return activeTrackingTarget;
    }

    public String getActiveBeingTrackedBy() {
        return activeBeingTrackedBy;
    }

    public String getLastErrorMessage() {
        return lastErrorMessage;
    }

    public String getLastReadableError() {
        return lastReadableError;
    }
}
