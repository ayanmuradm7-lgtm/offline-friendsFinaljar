package com.offlinefriends;

import com.offlinefriends.network.TrackPlayerC2SPayload;
import com.offlinefriends.network.TrackedPlayerPosS2CPayload;
import com.offlinefriends.util.OfflineUuidHelper;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * OfflineFriendsMod
 * 
 * Common entrypoint for Offline Friends mod.
 * Features:
 * - Registration of CustomPayloads for C2S and S2C tracking.
 * - Server-side tracking dispatcher: scans the server player list by string username
 *   (case-insensitively, supporting cracked accounts) and broadcasts target coords.
 */
public class OfflineFriendsMod implements ModInitializer {

    public static final String MOD_ID = "offlinefriends";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Map: Tracker Player UUID -> Target Player Username to track
    public static final Map<UUID, String> ACTIVE_TRACKING_REQUESTS = new ConcurrentHashMap<>();

    private int tickCounter = 0;

    @Override
    public void onInitialize() {
        com.offlinefriends.util.ModLogger.initDebugLog();
        LOGGER.info("[Offline Friends] Initializing common mod components v1.3.2 on Minecraft 1.21.11...");

        // 1. Register Payload Types on common side using official Fabric API 0.141.4+1.21.11 interface
        PayloadTypeRegistry.playC2S().register(TrackPlayerC2SPayload.ID, TrackPlayerC2SPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(TrackedPlayerPosS2CPayload.ID, TrackedPlayerPosS2CPayload.CODEC);

        // 2. Handle C2S tracking requests on Server
        ServerPlayNetworking.registerGlobalReceiver(TrackPlayerC2SPayload.ID, (payload, context) -> {
            ServerPlayerEntity sender = context.player();
            context.server().execute(() -> {
                if (payload.enable()) {
                    LOGGER.info("[Offline Friends] Player {} requested tracking for: {}", 
                            sender.getName().getString(), payload.targetUsername());
                    ACTIVE_TRACKING_REQUESTS.put(sender.getUuid(), payload.targetUsername());
                } else {
                    ACTIVE_TRACKING_REQUESTS.remove(sender.getUuid());
                }
            });
        });

        // 3. Periodic Server Tick for Coordinate Sync (every 5 ticks / 250ms)
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;
            if (tickCounter % 5 != 0) return;

            ACTIVE_TRACKING_REQUESTS.forEach((trackerUuid, targetUsername) -> {
                ServerPlayerEntity tracker = server.getPlayerManager().getPlayer(trackerUuid);
                if (tracker == null) {
                    ACTIVE_TRACKING_REQUESTS.remove(trackerUuid);
                    return;
                }

                // Search by string username case-insensitively (Cracked safe)
                ServerPlayerEntity target = null;
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    if (OfflineUuidHelper.matchUsernames(p.getName().getString(), targetUsername)) {
                        target = p;
                        break;
                    }
                }

                TrackedPlayerPosS2CPayload packet;
                if (target != null) {
                    packet = new TrackedPlayerPosS2CPayload(
                            target.getName().getString(),
                            true,
                            target.getX(),
                            target.getY(),
                            target.getZ(),
                            target.getEntityWorld().getRegistryKey().getValue().toString(),
                            target.getHealth(),
                            target.getMaxHealth()
                    );
                } else {
                    // Player is not currently on this server
                    packet = new TrackedPlayerPosS2CPayload(
                            targetUsername,
                            false,
                            0.0, 0.0, 0.0,
                            "unknown",
                            0.0f, 0.0f
                    );
                }

                ServerPlayNetworking.send(tracker, packet);
            });
        });

        LOGGER.info("[Offline Friends] Common initialization complete. Cracked UUID engine active.");
    }
}
