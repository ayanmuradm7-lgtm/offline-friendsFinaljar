package com.offlinefriends.network;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * TrackedPlayerPosS2CPayload
 * 
 * Custom payload sent from server to client containing real-time coordinates,
 * dimension, health status, and presence of the tracked player.
 * Compatible with Fabric 1.21.11 CustomPayload API.
 */
public record TrackedPlayerPosS2CPayload(
        String username,
        boolean online,
        double x,
        double y,
        double z,
        String dimension,
        float health,
        float maxHealth
) implements CustomPayload {

    public static final CustomPayload.Id<TrackedPlayerPosS2CPayload> ID = 
            new CustomPayload.Id<>(Identifier.of("offlinefriends", "tracked_player_pos_s2c"));

    public static final PacketCodec<PacketByteBuf, TrackedPlayerPosS2CPayload> CODEC = 
            CustomPayload.codecOf(TrackedPlayerPosS2CPayload::write, TrackedPlayerPosS2CPayload::new);

    public TrackedPlayerPosS2CPayload(PacketByteBuf buf) {
        this(
            buf.readString(32),
            buf.readBoolean(),
            buf.readDouble(),
            buf.readDouble(),
            buf.readDouble(),
            buf.readString(64),
            buf.readFloat(),
            buf.readFloat()
        );
    }

    private void write(PacketByteBuf buf) {
        buf.writeString(this.username, 32);
        buf.writeBoolean(this.online);
        buf.writeDouble(this.x);
        buf.writeDouble(this.y);
        buf.writeDouble(this.z);
        buf.writeString(this.dimension, 64);
        buf.writeFloat(this.health);
        buf.writeFloat(this.maxHealth);
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
