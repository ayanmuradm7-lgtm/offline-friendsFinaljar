package com.offlinefriends.network;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * TrackPlayerC2SPayload
 * 
 * Custom payload sent from client to server to request or cancel tracking
 * for a target player username. Compatible with Fabric 1.21.11 CustomPayload API.
 */
public record TrackPlayerC2SPayload(String targetUsername, boolean enable) implements CustomPayload {

    public static final CustomPayload.Id<TrackPlayerC2SPayload> ID = 
            new CustomPayload.Id<>(Identifier.of("offlinefriends", "track_player_c2s"));

    public static final PacketCodec<PacketByteBuf, TrackPlayerC2SPayload> CODEC = 
            CustomPayload.codecOf(TrackPlayerC2SPayload::write, TrackPlayerC2SPayload::new);

    public TrackPlayerC2SPayload(PacketByteBuf buf) {
        this(buf.readString(32), buf.readBoolean());
    }

    private void write(PacketByteBuf buf) {
        buf.writeString(this.targetUsername, 32);
        buf.writeBoolean(this.enable);
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
