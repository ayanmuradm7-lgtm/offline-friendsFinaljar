package com.offlinefriends.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import com.offlinefriends.util.ModLogger;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * ModConfig
 * 
 * Local persistent configuration stored in config/offlinefriends.json.
 * 
 * Protocol Version 1 Configuration Schema:
 * {
 *   "relay_url": "wss://my-offline-friends.onrender.com/ws",
 *   "username": "<player_minecraft_username>",
 *   "token": "<saved_secret_token>",
 *   "sound_enabled": true,
 *   "notification_position": "TOP_LEFT",
 *   "share_my_server": true,
 *   "invisible": false,
 *   "auto_accept_friends": true,
 *   "online_notifications_enabled": true,
 *   "allow_group_invites": true,
 *   "blocked_users": [],
 *   "muted_friends": []
 * }
 */
public class ModConfig {

    public static final String DEFAULT_RELAY_URL = "wss://my-offline-friends.onrender.com/ws";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Object LOCK = new Object();
    private static ModConfig instance;

    @SerializedName("relay_url")
    private String relayUrl = DEFAULT_RELAY_URL;

    @SerializedName("username")
    private String username = "";

    @SerializedName("token")
    private String token = "";

    @SerializedName("sound_enabled")
    private boolean soundEnabled = true;

    @SerializedName("notification_position")
    private String notificationPosition = "TOP_LEFT";

    @SerializedName("share_my_server")
    private boolean shareMyServer = true;

    @SerializedName("invisible")
    private boolean invisible = false;

    @SerializedName("auto_accept_friends")
    private boolean autoAcceptFriends = true;

    @SerializedName("online_notifications_enabled")
    private boolean onlineNotificationsEnabled = true;

    @SerializedName("allow_group_invites")
    private boolean allowGroupInvitesFromFriends = true;

    @SerializedName("blocked_users")
    private Set<String> blockedUsers = new CopyOnWriteArraySet<>();

    @SerializedName("muted_friends")
    private Set<String> mutedFriends = new CopyOnWriteArraySet<>();

    @SerializedName("accent_color")
    private String accentColor = "CYAN";

    @SerializedName("reduce_animations")
    private boolean reduceAnimations = false;

    @SerializedName("avatar_mode")
    private String avatarMode = "AUTO";

    // Transient alias for backward compatibility
    private transient String serverAddress = null;

    public static synchronized ModConfig getInstance() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static File getPrimaryConfigFile() {
        File dir = new File("config");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return new File(dir, "offlinefriends.json");
    }

    private static File getLegacyConfigFile() {
        return new File(new File("config", "offlinefriends"), "config.json");
    }

    public static ModConfig load() {
        synchronized (LOCK) {
            File primary = getPrimaryConfigFile();
            File legacy = getLegacyConfigFile();
            File targetFile = primary.exists() ? primary : (legacy.exists() ? legacy : primary);

            if (targetFile.exists()) {
                try (FileReader reader = new FileReader(targetFile)) {
                    ModConfig cfg = GSON.fromJson(reader, ModConfig.class);
                    if (cfg != null) {
                        // Handle backward compatibility
                        if (cfg.relayUrl == null || cfg.relayUrl.trim().isEmpty()) {
                            if (cfg.serverAddress != null && !cfg.serverAddress.trim().isEmpty()) {
                                cfg.relayUrl = cfg.serverAddress.trim();
                            } else {
                                cfg.relayUrl = DEFAULT_RELAY_URL;
                            }
                        }

                        // Auto-generate secure token on first launch if absent
                        if (cfg.token == null || cfg.token.trim().isEmpty()) {
                            cfg.token = UUID.randomUUID().toString().replace("-", "");
                            cfg.save();
                        }
                        ModLogger.setRedactedToken(cfg.token);
                        return cfg;
                    }
                } catch (Exception e) {
                    ModLogger.error("Failed to load config from " + targetFile.getPath() + ", generating fresh config", e);
                }
            }

            // Fresh install
            ModConfig cfg = new ModConfig();
            cfg.relayUrl = DEFAULT_RELAY_URL;
            cfg.token = UUID.randomUUID().toString().replace("-", "");
            ModLogger.setRedactedToken(cfg.token);
            cfg.save();
            return cfg;
        }
    }

    public void save() {
        synchronized (LOCK) {
            try {
                File file = getPrimaryConfigFile();
                try (FileWriter writer = new FileWriter(file)) {
                    GSON.toJson(this, writer);
                    writer.flush();
                }
            } catch (Exception e) {
                ModLogger.error("Failed to save config to disk", e);
            }
        }
    }

    // Getters and Setters

    public String getRelayUrl() {
        return relayUrl != null ? relayUrl.trim() : "";
    }

    public void setRelayUrl(String relayUrl) {
        this.relayUrl = relayUrl != null ? relayUrl.trim() : "";
    }

    public String getServerAddress() {
        return getRelayUrl();
    }

    public void setServerAddress(String serverAddress) {
        setRelayUrl(serverAddress);
    }

    public String getUsername() {
        return username != null ? username.trim() : "";
    }

    public void setUsername(String username) {
        this.username = username != null ? username.trim() : "";
    }

    /**
     * Retrieves configured username or automatically detects from Minecraft session.
     */
    public String getEffectiveUsername() {
        if (username != null && !username.trim().isEmpty()) {
            return username.trim();
        }

        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.getSession() != null && mc.getSession().getUsername() != null) {
                String detected = mc.getSession().getUsername().trim();
                if (!detected.isEmpty() && !detected.equalsIgnoreCase("Player")) {
                    this.username = detected;
                    save();
                    return detected;
                }
            }
        } catch (Throwable t) {
            // Ignore during headless unit testing
        }

        return !this.username.isEmpty() ? this.username : "Player";
    }

    public boolean isSoundEnabled() {
        return soundEnabled;
    }

    public void setSoundEnabled(boolean soundEnabled) {
        this.soundEnabled = soundEnabled;
    }

    public String getNotificationPosition() {
        return notificationPosition != null ? notificationPosition : "TOP_LEFT";
    }

    public void setNotificationPosition(String notificationPosition) {
        this.notificationPosition = notificationPosition;
    }

    public boolean isShareMyServer() {
        return shareMyServer;
    }

    public void setShareMyServer(boolean shareMyServer) {
        this.shareMyServer = shareMyServer;
    }

    public boolean isInvisible() {
        return invisible;
    }

    public void setInvisible(boolean invisible) {
        this.invisible = invisible;
    }

    public String getToken() {
        return token != null ? token : "";
    }

    public void regenerateToken() {
        this.token = UUID.randomUUID().toString().replace("-", "");
        ModLogger.setRedactedToken(this.token);
        save();
    }

    public boolean isAutoAcceptFriends() {
        return autoAcceptFriends;
    }

    public void setAutoAcceptFriends(boolean autoAcceptFriends) {
        this.autoAcceptFriends = autoAcceptFriends;
    }

    public boolean isOnlineNotificationsEnabled() {
        return onlineNotificationsEnabled;
    }

    public void setOnlineNotificationsEnabled(boolean onlineNotificationsEnabled) {
        this.onlineNotificationsEnabled = onlineNotificationsEnabled;
    }

    public boolean isAllowGroupInvitesFromFriends() {
        return allowGroupInvitesFromFriends;
    }

    public void setAllowGroupInvitesFromFriends(boolean allowGroupInvitesFromFriends) {
        this.allowGroupInvitesFromFriends = allowGroupInvitesFromFriends;
    }

    public boolean isUserBlocked(String username) {
        if (username == null) return false;
        String clean = username.trim().toLowerCase();
        if (blockedUsers == null) return false;
        return blockedUsers.contains(clean);
    }

    public void blockUser(String username) {
        if (username == null || username.trim().isEmpty()) return;
        if (blockedUsers == null) blockedUsers = new CopyOnWriteArraySet<>();
        String clean = username.trim().toLowerCase();
        blockedUsers.add(clean);
        ModLogger.logEvent("USER_BLOCKED", "Blocked user: " + username.trim());
        save();
    }

    public void unblockUser(String username) {
        if (username == null || username.trim().isEmpty()) return;
        if (blockedUsers == null) return;
        String clean = username.trim().toLowerCase();
        if (blockedUsers.remove(clean)) {
            ModLogger.logEvent("USER_UNBLOCKED", "Unblocked user: " + username.trim());
            save();
        }
    }

    public Set<String> getBlockedUsers() {
        if (blockedUsers == null) blockedUsers = new CopyOnWriteArraySet<>();
        return blockedUsers;
    }

    public boolean isFriendMuted(String username) {
        if (username == null) return false;
        String clean = username.trim().toLowerCase();
        if (mutedFriends == null) return false;
        return mutedFriends.contains(clean);
    }

    public void muteFriend(String username) {
        if (username == null || username.trim().isEmpty()) return;
        if (mutedFriends == null) mutedFriends = new CopyOnWriteArraySet<>();
        String clean = username.trim().toLowerCase();
        mutedFriends.add(clean);
        ModLogger.logEvent("FRIEND_MUTED", "Muted friend: " + username.trim());
        save();
    }

    public void unmuteFriend(String username) {
        if (username == null || username.trim().isEmpty()) return;
        if (mutedFriends == null) return;
        String clean = username.trim().toLowerCase();
        if (mutedFriends.remove(clean)) {
            ModLogger.logEvent("FRIEND_UNMUTED", "Unmuted friend: " + username.trim());
            save();
        }
    }

    public Set<String> getMutedFriends() {
        if (mutedFriends == null) mutedFriends = new CopyOnWriteArraySet<>();
        return mutedFriends;
    }

    public String getAccentColor() {
        return accentColor != null ? accentColor.toUpperCase() : "CYAN";
    }

    public void setAccentColor(String accentColor) {
        this.accentColor = accentColor != null ? accentColor.toUpperCase() : "CYAN";
    }

    public boolean isReduceAnimations() {
        return reduceAnimations;
    }

    public void setReduceAnimations(boolean reduceAnimations) {
        this.reduceAnimations = reduceAnimations;
    }

    public String getAvatarMode() {
        return avatarMode != null ? avatarMode.toUpperCase() : "AUTO";
    }

    public void setAvatarMode(String avatarMode) {
        this.avatarMode = avatarMode != null ? avatarMode.toUpperCase() : "AUTO";
    }
}
