package com.offlinefriends.client.gui;

import com.offlinefriends.client.OfflineFriendsClient;
import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.social.SocialWebSocketClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * TrackerScreen
 * 
 * Dark glass-styled dedicated screen for player tracking with mutual consent:
 * - Lists friends online on the same server with avatar heads and 40px touch buttons.
 * - Manual username tracking field.
 * - Active tracking status with distance, coordinates, dimension, and signal check.
 * - Tracked player alert with one-tap Stop button.
 * - Under 400 lines (modularized).
 */
public class TrackerScreen extends Screen {

    private final Screen parent;
    private TextFieldWidget manualTargetField;
    private ButtonWidget toggleVisualsBtn;

    public TrackerScreen() {
        this(null);
    }

    public TrackerScreen(Screen parent) {
        super(Text.literal("Offline Friends - Player Tracker"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int topY = 28;

        // Manual Target Input Field (min 40px touch height)
        this.manualTargetField = this.addDrawableChild(new TextFieldWidget(
                this.textRenderer,
                centerX - 140, topY + 128,
                180, 22,
                Text.literal("Target Username")
        ));
        this.manualTargetField.setMaxLength(16);
        this.manualTargetField.setPlaceholder(Text.literal("Player username..."));

        // Request Track Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Track"), b -> {
            String name = this.manualTargetField.getText().trim();
            if (!name.isEmpty()) {
                requestTracking(name);
                this.manualTargetField.setText("");
            }
        }).dimensions(centerX + 48, topY + 128, 92, 22).build());

        // Stop Active Tracking Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Stop Tracking"), b -> stopAllTracking())
                .dimensions(centerX - 140, topY + 156, 136, 22).build());

        // Toggle Visuals (HUD Compass + 3D Waypoint)
        this.toggleVisualsBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Visuals: " + (OfflineFriendsClient.isTrackingVisualsEnabled() ? "ON" : "OFF")),
                b -> {
                    boolean next = !OfflineFriendsClient.isTrackingVisualsEnabled();
                    OfflineFriendsClient.setTrackingVisualsEnabled(next);
                    b.setMessage(Text.literal("Visuals: " + (next ? "ON" : "OFF")));
                }
        ).dimensions(centerX + 4, topY + 156, 136, 22).build());

        // Settings Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("⚙ Settings"), b -> {
            if (this.client != null) this.client.setScreen(new SettingsScreen(this));
        }).dimensions(centerX - 140, topY + 184, 136, 22).build());

        // Done / Close Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> this.close())
                .dimensions(centerX + 4, topY + 184, 136, 22).build());
    }

    private void requestTracking(String targetUsername) {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        if (social.isConnected()) {
            social.sendTrackRequest(targetUsername);
        }
        OfflineFriendsClient.setTrackingVisualsEnabled(true);
    }

    private void stopAllTracking() {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        String target = social.getActiveTrackingTarget();
        if (target != null) social.sendTrackStop(target);
        String beingTrackedBy = social.getActiveBeingTrackedBy();
        if (beingTrackedBy != null) social.sendTrackStop(beingTrackedBy);
        OfflineFriendsClient.clearTrackedTarget();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);
        int centerX = this.width / 2;
        int topY = 20;
        int cardW = 300;
        int cardH = 220;

        // Dark translucent glass card
        context.fill(0, 0, this.width, this.height, 0x66000000);
        Theme.drawRoundedRect(context, centerX - cardW / 2, topY, cardW, cardH, Theme.BG_DARK_GLASS, Theme.BORDER_SUBTLE);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int topY = 26;
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();

        // 1. Title Header
        context.drawCenteredTextWithShadow(this.textRenderer, "Player Compass Tracker", centerX, topY, Theme.TEXT_TITLE);

        // 2. Active Tracking Status Section
        String tracking = social.getActiveTrackingTarget();
        String trackedBy = social.getActiveBeingTrackedBy();
        String pendingOut = social.getPendingOutgoingTrackTarget();

        int statusY = topY + 18;
        if (tracking != null) {
            OfflineFriendsClient.TrackedTarget target = OfflineFriendsClient.getCurrentTrackedTarget();
            if (target != null && target.active()) {
                long now = System.currentTimeMillis();
                boolean isSignalLost = (now - target.lastUpdateTime()) > 10_000L;

                String myServer = social.getLocalServer();
                String myDim = (this.client != null && this.client.player != null && this.client.player.getEntityWorld() != null) ?
                        this.client.player.getEntityWorld().getRegistryKey().getValue().toString() : "";

                boolean sameServer = (target.server() == null && myServer == null) ||
                        (target.server() != null && target.server().equalsIgnoreCase(myServer));
                boolean sameDim = target.dimension() != null && target.dimension().equalsIgnoreCase(myDim);

                AvatarWidget.drawHead(context, tracking, centerX - 135, statusY, 18);
                if (isSignalLost) {
                    context.drawText(this.textRenderer, "Tracking: " + tracking + " (Signal lost >10s)", centerX - 112, statusY + 5, 0xFFEF4444, false);
                } else if (!sameServer || !sameDim) {
                    String diff = !sameServer ? "Different server" : "Different dimension (" + target.dimension() + ")";
                    context.drawText(this.textRenderer, "Tracking: " + tracking + " (" + diff + ")", centerX - 112, statusY + 5, 0xFFF59E0B, false);
                } else {
                    double dx = target.x() - (this.client != null && this.client.player != null ? this.client.player.getX() : 0);
                    double dy = target.y() - (this.client != null && this.client.player != null ? this.client.player.getY() : 0);
                    double dz = target.z() - (this.client != null && this.client.player != null ? this.client.player.getZ() : 0);
                    double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    String info = String.format("Tracking: %s • %.0fm | XYZ: %.0f, %.0f, %.0f", tracking, distance, target.x(), target.y(), target.z());
                    context.drawText(this.textRenderer, info, centerX - 112, statusY + 5, Theme.getAccentPrimary(), false);
                }
            } else {
                AvatarWidget.drawHead(context, tracking, centerX - 135, statusY, 18);
                context.drawText(this.textRenderer, "Tracking: " + tracking + " (Awaiting relay packet...)", centerX - 112, statusY + 5, Theme.TEXT_SECONDARY, false);
            }
        } else if (pendingOut != null) {
            AvatarWidget.drawHead(context, pendingOut, centerX - 135, statusY, 18);
            context.drawText(this.textRenderer, "Request sent to " + pendingOut + " (Awaiting consent...)", centerX - 112, statusY + 5, 0xFFF59E0B, false);
        } else {
            context.drawCenteredTextWithShadow(this.textRenderer, "No active tracking session", centerX, statusY + 5, Theme.TEXT_MUTED);
        }

        // 3. Tracked by Banner with One-Tap Stop
        if (trackedBy != null) {
            int bannerY = statusY + 22;
            Theme.drawRoundedRect(context, centerX - 135, bannerY, 270, 18, 0xDD7F1D1D, 0xFFEF4444);
            AvatarWidget.drawHead(context, trackedBy, centerX - 131, bannerY + 2, 14);
            context.drawText(this.textRenderer, "Tracked by: " + trackedBy, centerX - 112, bannerY + 5, 0xFFFFFFFF, false);

            int stopX = centerX + 85;
            context.fill(stopX, bannerY + 2, stopX + 46, bannerY + 16, 0xFFDC2626);
            context.drawCenteredTextWithShadow(this.textRenderer, "Stop", stopX + 23, bannerY + 5, 0xFFFFFFFF);
            statusY += 22;
        }

        // 4. Pending Incoming Tracking Requests
        int reqY = statusY + 20;
        if (!social.pendingIncomingTrackRequests.isEmpty()) {
            for (String reqUser : social.pendingIncomingTrackRequests) {
                AvatarWidget.drawHead(context, reqUser, centerX - 135, reqY, 14);
                context.drawText(this.textRenderer, reqUser + " wants to track you:", centerX - 116, reqY + 3, 0xFFF59E0B, false);

                // Accept button
                int accX = centerX + 40;
                context.fill(accX, reqY, accX + 44, reqY + 14, Theme.getAccentPrimary());
                context.drawCenteredTextWithShadow(this.textRenderer, "Accept", accX + 22, reqY + 3, 0xFFFFFFFF);

                // Decline button
                int decX = centerX + 90;
                context.fill(decX, reqY, decX + 44, reqY + 14, 0xDDEF4444);
                context.drawCenteredTextWithShadow(this.textRenderer, "Decline", decX + 22, reqY + 3, 0xFFFFFFFF);
                reqY += 18;
            }
        }

        // 5. Friends on Same Server
        int friendsY = reqY + 2;
        context.drawText(this.textRenderer, "Friends on current server:", centerX - 135, friendsY, Theme.TEXT_SECONDARY, false);

        List<SocialWebSocketClient.FriendInfo> sameServerFriends = getSameServerFriends(social);
        int itemY = friendsY + 12;
        if (sameServerFriends.isEmpty()) {
            context.drawText(this.textRenderer, "None detected on this server", centerX - 125, itemY + 2, Theme.TEXT_MUTED, false);
        } else {
            for (SocialWebSocketClient.FriendInfo f : sameServerFriends) {
                AvatarWidget.drawHead(context, f.username(), centerX - 135, itemY, 14);
                context.drawText(this.textRenderer, f.username(), centerX - 116, itemY + 3, Theme.TEXT_PRIMARY, false);

                int trackBtnX = centerX + 85;
                context.fill(trackBtnX, itemY, trackBtnX + 48, itemY + 14, Theme.BG_CARD);
                context.drawCenteredTextWithShadow(this.textRenderer, "Track", trackBtnX + 24, itemY + 3, Theme.getAccentPrimary());
                itemY += 18;
            }
        }
    }

    private List<SocialWebSocketClient.FriendInfo> getSameServerFriends(SocialWebSocketClient social) {
        List<SocialWebSocketClient.FriendInfo> list = new ArrayList<>();
        String myServer = social.getLocalServer();
        if (myServer == null || myServer.isEmpty()) return list;

        for (SocialWebSocketClient.FriendInfo f : social.friends.values()) {
            if (f.online() && f.server() != null && f.server().equalsIgnoreCase(myServer)) {
                list.add(f);
            }
        }
        return list;
    }

    @Override
    public boolean mouseClicked(Click click, boolean bl) {
        double mouseX = click.x();
        double mouseY = click.y();
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();

        int centerX = this.width / 2;
        int topY = 26;
        int statusY = topY + 18;

        String trackedBy = social.getActiveBeingTrackedBy();
        if (trackedBy != null) {
            int bannerY = statusY + 22;
            int stopX = centerX + 85;
            if (mouseX >= stopX && mouseX <= stopX + 46 && mouseY >= bannerY + 2 && mouseY <= bannerY + 16) {
                social.sendTrackStop(trackedBy);
                return true;
            }
            statusY += 22;
        }

        int reqY = statusY + 20;
        for (String reqUser : new ArrayList<>(social.pendingIncomingTrackRequests)) {
            int accX = centerX + 40;
            if (mouseX >= accX && mouseX <= accX + 44 && mouseY >= reqY && mouseY <= reqY + 14) {
                social.sendTrackAccept(reqUser);
                return true;
            }
            int decX = centerX + 90;
            if (mouseX >= decX && mouseX <= decX + 44 && mouseY >= reqY && mouseY <= reqY + 14) {
                social.sendTrackDecline(reqUser);
                return true;
            }
            reqY += 18;
        }

        int friendsY = reqY + 2;
        int itemY = friendsY + 12;
        List<SocialWebSocketClient.FriendInfo> sameServerFriends = getSameServerFriends(social);
        for (SocialWebSocketClient.FriendInfo f : sameServerFriends) {
            int trackBtnX = centerX + 85;
            if (mouseX >= trackBtnX && mouseX <= trackBtnX + 48 && mouseY >= itemY && mouseY <= itemY + 14) {
                requestTracking(f.username());
                return true;
            }
            itemY += 18;
        }

        return super.mouseClicked(click, bl);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(this.parent);
        else super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
