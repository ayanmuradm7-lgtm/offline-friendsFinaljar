package com.offlinefriends.client.gui;

import com.offlinefriends.client.ui.Anim;
import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.tabs.LeftRailTab;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.social.SocialWebSocketClient;
import com.offlinefriends.util.ModLogger;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * AddFriendScreen
 * 
 * Standalone, high-contrast modal screen for adding friends:
 * - Solid opaque centered card (0xFF0B0F19) with accent border (no glass bleed).
 * - Dim solid-color backdrop (0xAA000000, zero blur passes).
 * - Live avatar head preview with hat layer for typed name.
 * - Live validation chips: 3-16 chars, letters/0-9/_, self-check, already friend, pending.
 * - Outgoing/incoming requests sections with Cancel, Accept, Decline.
 * - Closes on '✕', Escape, Android back key (256), or outside tap, returning to Friends tab.
 * - Strictly under 350 lines.
 */
public class AddFriendScreen extends Screen implements SocialWebSocketClient.FriendRequestListener {

    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{3,16}$");

    private final Screen parent;
    private TextFieldWidget usernameField;
    private ButtonWidget sendButton;
    private ButtonWidget pasteButton;

    private long openNano = 0L;
    private boolean isSending = false;
    private String statusMessage = null;
    private int statusColor = Theme.STATUS_ONLINE;
    private long statusExpiry = 0L;
    private String lastSentTarget = null;
    private int cardX, cardY, cardW, cardH;

    public AddFriendScreen(Screen parent) {
        super(Text.literal("Add a friend"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.openNano = System.nanoTime();
        SocialWebSocketClient.getInstance().addFriendRequestListener(this);
        ModLogger.logEvent("ADD_FRIEND_OPENED", "AddFriendScreen opened");

        this.cardW = Math.min(310, this.width - 24);
        this.cardH = computeCardHeight();
        this.cardX = (this.width - cardW) / 2;
        this.cardY = Math.max(12, (this.height - cardH) / 3);

        int fieldY = cardY + 36;
        this.usernameField = this.addDrawableChild(new TextFieldWidget(this.textRenderer, cardX + 42, fieldY, cardW - 88, 22, Text.literal("Username")));
        this.usernameField.setMaxLength(16);
        this.usernameField.setPlaceholder(Text.literal("Username..."));
        this.usernameField.setEditableColor(0xFFFFFFFF);
        this.usernameField.setChangedListener(text -> updateValidationState());
        this.setFocused(this.usernameField);

        this.pasteButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("📋"), b -> handlePaste())
                .dimensions(cardX + cardW - 40, fieldY, 28, 22).build());

        this.sendButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("Send friend request"), b -> doSendRequest())
                .dimensions(cardX + 14, cardY + 80, cardW - 28, 24).build());

        updateValidationState();
    }

    private int computeCardHeight() {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int h = 114;
        if (statusMessage != null && System.currentTimeMillis() < statusExpiry) h += 18;
        if (!social.pendingOutgoingRequests.isEmpty()) h += 22 + (social.pendingOutgoingRequests.size() * 26);
        if (!social.pendingIncomingRequests.isEmpty()) h += 22 + (social.pendingIncomingRequests.size() * 30);
        return Math.min(h, this.height - 20);
    }

    private void handlePaste() {
        if (this.client != null && this.client.keyboard != null) {
            String clip = this.client.keyboard.getClipboard();
            if (clip != null && !clip.trim().isEmpty()) {
                String clean = clip.trim().replaceAll("[^a-zA-Z0-9_]", "");
                if (clean.length() > 16) clean = clean.substring(0, 16);
                if (usernameField != null) {
                    usernameField.setText(clean);
                    updateValidationState();
                }
            }
        }
    }

    private void updateValidationState() {
        if (sendButton == null) return;
        String text = usernameField != null ? usernameField.getText().trim() : "";
        boolean valid = isInputValid(text);
        sendButton.active = valid && !isSending;
        sendButton.setMessage(Text.literal(isSending ? "Sending..." : "Send friend request"));
    }

    private boolean isInputValid(String text) {
        if (text == null || text.length() < 3 || text.length() > 16) return false;
        if (!USERNAME_PATTERN.matcher(text).matches()) return false;
        if (text.equalsIgnoreCase(ModConfig.getInstance().getEffectiveUsername())) return false;
        SocialWebSocketClient s = SocialWebSocketClient.getInstance();
        return !s.friends.containsKey(text.toLowerCase()) && !s.pendingOutgoingRequests.contains(text);
    }

    private void doSendRequest() {
        if (usernameField == null) return;
        String target = usernameField.getText().trim();
        if (!isInputValid(target) || isSending) return;

        this.isSending = true;
        this.lastSentTarget = target;
        updateValidationState();
        ModLogger.logEvent("ADD_FRIEND_SENT", "Sending friend request to: " + target);
        SocialWebSocketClient.getInstance().sendFriendRequest(target);
    }

    @Override
    public void onFriendRequestStatus(String target, boolean success, String message) {
        this.isSending = false;
        if (success) {
            String name = target != null ? target : (lastSentTarget != null ? lastSentTarget : "player");
            this.statusMessage = "✔ Request sent to " + name + "!";
            this.statusColor = Theme.STATUS_ONLINE;
            this.statusExpiry = System.currentTimeMillis() + 6000L;
            if (usernameField != null) usernameField.setText("");
        } else {
            this.statusMessage = message != null ? message : "Failed to send request";
            this.statusColor = Theme.STATUS_ERROR;
            this.statusExpiry = System.currentTimeMillis() + 8000L;
            ModLogger.logEvent("ADD_FRIEND_ERROR", "Target: " + (target != null ? target : lastSentTarget) + " - " + statusMessage);
        }
        this.cardH = computeCardHeight();
        updateValidationState();
    }

    @Override
    public void onRequestsUpdated() {
        this.cardH = computeCardHeight();
        updateValidationState();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xAA000000);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float p = Anim.easeOutCubic(Anim.progress(openNano, 180));
        int slideOffset = (int) ((1.0f - p) * 12);

        this.cardW = Math.min(310, this.width - 24);
        this.cardH = computeCardHeight();
        this.cardX = (this.width - cardW) / 2;
        this.cardY = Math.max(12, (this.height - cardH) / 3) + slideOffset;

        Theme.drawRoundedRect(context, cardX, cardY, cardW, cardH, 0xFF0B0F19, Theme.getAccentPrimary());
        context.drawTextWithShadow(this.textRenderer, "Add a friend", cardX + 14, cardY + 10, Theme.TEXT_TITLE);
        context.drawText(this.textRenderer, "Type their exact Minecraft username", cardX + 14, cardY + 22, Theme.TEXT_MUTED, false);

        int closeX = cardX + cardW - 20, closeY = cardY + 9;
        boolean closeHover = mouseX >= closeX - 2 && mouseX <= closeX + 10 && mouseY >= closeY - 2 && mouseY <= closeY + 10;
        context.drawTextWithShadow(this.textRenderer, "✕", closeX, closeY, closeHover ? Theme.STATUS_ERROR : Theme.TEXT_MUTED);

        int fieldY = cardY + 36;
        String curText = usernameField != null ? usernameField.getText().trim() : "";
        AvatarWidget.render(context, curText.isEmpty() ? "Steve" : curText, cardX + 14, fieldY, 22);

        if (usernameField != null) {
            usernameField.setPosition(cardX + 42, fieldY);
            usernameField.setWidth(cardW - 88);
        }
        if (pasteButton != null) pasteButton.setPosition(cardX + cardW - 40, fieldY);
        if (sendButton != null) {
            sendButton.setPosition(cardX + 14, cardY + 80);
            sendButton.setWidth(cardW - 28);
        }

        super.render(context, mouseX, mouseY, delta);
        renderValidationChips(context, cardX + 14, cardY + 63, curText);

        int nextY = cardY + 108;
        if (statusMessage != null && System.currentTimeMillis() < statusExpiry) {
            context.drawCenteredTextWithShadow(this.textRenderer, statusMessage, cardX + cardW / 2, nextY, statusColor);
            nextY += 16;
        }

        renderPendingSections(context, mouseX, mouseY, nextY);
    }

    private void renderValidationChips(DrawContext context, int x, int y, String text) {
        int len = text.length();
        boolean lenOk = len >= 3 && len <= 16;
        boolean charsOk = !text.isEmpty() && USERNAME_PATTERN.matcher(text).matches();

        Theme.drawRoundedRect(context, x, y, 62, 12, lenOk ? 0x3310B981 : 0x22334155, lenOk ? Theme.STATUS_ONLINE : Theme.BORDER_CARD);
        context.drawText(this.textRenderer, "3-16 chars", x + 5, y + 2, lenOk ? Theme.STATUS_ONLINE : Theme.TEXT_MUTED, false);

        int c2X = x + 66;
        Theme.drawRoundedRect(context, c2X, y, 70, 12, charsOk ? 0x3310B981 : 0x22334155, charsOk ? Theme.STATUS_ONLINE : Theme.BORDER_CARD);
        context.drawText(this.textRenderer, "Letters, 0-9, _", c2X + 4, y + 2, charsOk ? Theme.STATUS_ONLINE : Theme.TEXT_MUTED, false);

        int statusX = c2X + 74;
        String myName = ModConfig.getInstance().getEffectiveUsername();
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();

        if (text.isEmpty()) context.drawText(this.textRenderer, "Enter name", statusX, y + 2, Theme.TEXT_DIM, false);
        else if (text.equalsIgnoreCase(myName)) context.drawText(this.textRenderer, "Cannot add self", statusX, y + 2, Theme.STATUS_ERROR, false);
        else if (social.friends.containsKey(text.toLowerCase())) context.drawText(this.textRenderer, "Already friends", statusX, y + 2, Theme.STATUS_AWAY, false);
        else if (social.pendingOutgoingRequests.contains(text)) context.drawText(this.textRenderer, "Request pending", statusX, y + 2, Theme.STATUS_AWAY, false);
        else if (social.pendingIncomingRequests.contains(text)) context.drawText(this.textRenderer, "Accept below!", statusX, y + 2, Theme.STATUS_ONLINE, false);
        else if (lenOk && charsOk) context.drawText(this.textRenderer, "Ready", statusX, y + 2, Theme.STATUS_ONLINE, false);
    }

    private void renderPendingSections(DrawContext context, int mouseX, int mouseY, int startY) {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int curY = startY;

        if (!social.pendingOutgoingRequests.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, "Requests I sent (" + social.pendingOutgoingRequests.size() + ")", cardX + 14, curY, Theme.TEXT_SECONDARY);
            curY += 12;
            for (String target : new ArrayList<>(social.pendingOutgoingRequests)) {
                Theme.drawSolidCard(context, cardX + 14, curY, cardW - 28, 22, false);
                AvatarWidget.render(context, target, cardX + 18, curY + 2, 18);
                context.drawTextWithShadow(this.textRenderer, target, cardX + 40, curY + 6, Theme.TEXT_PRIMARY);

                int cancelX = cardX + cardW - 56;
                boolean hov = mouseX >= cancelX && mouseX <= cancelX + 38 && mouseY >= curY + 2 && mouseY <= curY + 20;
                context.fill(cancelX, curY + 2, cancelX + 38, curY + 20, hov ? 0xFFDC2626 : 0xFF7F1D1D);
                context.drawCenteredTextWithShadow(this.textRenderer, "Cancel", cancelX + 19, curY + 6, 0xFFFFFFFF);
                curY += 26;
            }
        }

        if (!social.pendingIncomingRequests.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, "Requests for you (" + social.pendingIncomingRequests.size() + ")", cardX + 14, curY, Theme.STATUS_AWAY);
            curY += 12;
            for (String req : new ArrayList<>(social.pendingIncomingRequests)) {
                Theme.drawSolidCard(context, cardX + 14, curY, cardW - 28, 26, false);
                AvatarWidget.render(context, req, cardX + 18, curY + 3, 20);
                context.drawTextWithShadow(this.textRenderer, req, cardX + 42, curY + 8, Theme.TEXT_PRIMARY);

                int accX = cardX + cardW - 54, decX = cardX + cardW - 30;
                context.fill(accX, curY + 4, accX + 20, curY + 22, Theme.STATUS_ONLINE);
                context.drawCenteredTextWithShadow(this.textRenderer, "✔", accX + 10, curY + 8, 0xFFFFFFFF);
                context.fill(decX, curY + 4, decX + 20, curY + 22, Theme.STATUS_ERROR);
                context.drawCenteredTextWithShadow(this.textRenderer, "✖", decX + 10, curY + 8, 0xFFFFFFFF);
                curY += 30;
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean bl) {
        double mx = click.x(), my = click.y();
        int closeX = cardX + cardW - 20, closeY = cardY + 9;
        if ((mx >= closeX - 4 && mx <= closeX + 12 && my >= closeY - 4 && my <= closeY + 12)
                || (mx < cardX || mx > cardX + cardW || my < cardY || my > cardY + cardH)) {
            close();
            return true;
        }

        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int checkY = cardY + 108 + ((statusMessage != null && System.currentTimeMillis() < statusExpiry) ? 16 : 0);

        if (!social.pendingOutgoingRequests.isEmpty()) {
            checkY += 12;
            for (String target : new ArrayList<>(social.pendingOutgoingRequests)) {
                int cancelX = cardX + cardW - 56;
                if (mx >= cancelX && mx <= cancelX + 38 && my >= checkY + 2 && my <= checkY + 20) {
                    social.cancelOutgoingFriendRequest(target);
                    return true;
                }
                checkY += 26;
            }
        }

        if (!social.pendingIncomingRequests.isEmpty()) {
            checkY += 12;
            for (String requester : new ArrayList<>(social.pendingIncomingRequests)) {
                int accX = cardX + cardW - 54, decX = cardX + cardW - 30;
                if (mx >= accX && mx <= accX + 20 && my >= checkY + 4 && my <= checkY + 22) {
                    social.sendFriendAccept(requester);
                    return true;
                } else if (mx >= decX && mx <= decX + 20 && my >= checkY + 4 && my <= checkY + 22) {
                    social.sendFriendDecline(requester);
                    return true;
                }
                checkY += 30;
            }
        }

        return super.mouseClicked(click, bl);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input != null) {
            if (input.key() == 256) { close(); return true; }
            if ((input.key() == 257 || input.key() == 335) && sendButton != null && sendButton.active) {
                doSendRequest();
                return true;
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        return super.charTyped(input);
    }

    @Override
    public void close() {
        if (this.client != null) {
            if (this.parent instanceof SocialScreen social) {
                social.setActiveTab(LeftRailTab.FRIENDS);
                this.client.setScreen(social);
            } else {
                SocialScreen social = new SocialScreen(this.parent);
                social.setActiveTab(LeftRailTab.FRIENDS);
                this.client.setScreen(social);
            }
        } else {
            super.close();
        }
    }

    @Override
    public void removed() {
        SocialWebSocketClient.getInstance().removeFriendRequestListener(this);
        super.removed();
    }
}
