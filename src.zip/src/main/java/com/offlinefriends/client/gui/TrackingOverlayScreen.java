package com.offlinefriends.client.gui;

/**
 * TrackingOverlayScreen
 * 
 * Maintained as an alias to TrackerScreen for backward compatibility.
 */
public class TrackingOverlayScreen extends TrackerScreen {
    public TrackingOverlayScreen() {
        super(null);
    }
}
