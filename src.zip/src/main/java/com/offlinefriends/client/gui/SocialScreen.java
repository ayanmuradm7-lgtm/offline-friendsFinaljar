package com.offlinefriends.client.gui;

import com.offlinefriends.client.OfflineFriendsClient;
import com.offlinefriends.client.notification.LeftNotificationManager;
import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.modals.GroupModalDialog;
import com.offlinefriends.client.ui.tabs.ChatPanelView;
import com.offlinefriends.client.ui.tabs.ConversationListView;
import com.offlinefriends.client.ui.tabs.FriendsTabView;
import com.offlinefriends.client.ui.tabs.LeftRailTab;
import com.offlinefriends.client.ui.widgets.IconButton;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.social.ChatHistoryManager;
import com.offlinefriends.social.GroupManager;
import com.offlinefriends.social.SocialWebSocketClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

import java.util.*;

/**
 * SocialScreen
 * 
 * Modular social interface featuring:
 * - Prominent Top Navigation Bar [ ★ Friends ] [ ✉ Chats ] [ ◆ Groups ] [ ◎ Tracker ] [ ⚙ Config ]
 * - Dedicated Friends Hub (FriendsTabView) taking full main panel on Friends tab.
 * - Split conversation & chat panel on Chats and Groups tabs.
 * - Proper draw order: base panels -> widgets -> topmost overlays.
 * - Header banner displaying Offline Friends v1.3.5.
 * - Strictly under 350 lines.
 */
public class SocialScreen extends Screen implements ConversationListView.Listener, FriendsTabView.Listener, ChatPanelView.ActionHandler {

    private final Screen parent;
    private LeftRailTab activeTab = LeftRailTab.FRIENDS; // Default to Friends
    private final List<IconButton> railButtons = new ArrayList<>();

    private FriendsTabView friendsTab;
    private ConversationListView conversationList;
    private ChatPanelView chatPanel;
    private final GroupModalDialog groupModals = new GroupModalDialog();

    private String selectedFriend = null;
    private String selectedGroupId = null;

    private TextFieldWidget chatInputField;
    private ButtonWidget sendButton;

    private String feedbackMessage = null;
    private int feedbackColor = 0xFF10B981;
    private long feedbackExpiryTime = 0L;

    public SocialScreen(Screen parent) { this(parent, null, null); }
    public SocialScreen(Screen parent, String initialFriend) { this(parent, initialFriend, null); }
    public SocialScreen(Screen parent, String initialFriend, String initialGroupId) {
        super(Text.literal("Offline Friends"));
        this.parent = parent;
        this.selectedFriend = initialFriend;
        this.selectedGroupId = initialGroupId;
        if (initialFriend != null || initialGroupId != null) this.activeTab = LeftRailTab.CHATS;
    }

    public void setFeedback(String message, boolean isError) {
        this.feedbackMessage = message;
        this.feedbackColor = isError ? 0xFFEF4444 : 0xFF10B981;
        this.feedbackExpiryTime = System.currentTimeMillis() + 8000L;
    }

    @Override
    protected void init() {
        SocialWebSocketClient.getInstance().setActiveSocialScreen(this);
        if (!ModConfig.getInstance().getRelayUrl().isEmpty() && !SocialWebSocketClient.getInstance().isConnected()) {
            SocialWebSocketClient.getInstance().connect();
        }

        railButtons.clear();
        int railW = 44, railX = 4, startY = 38;
        LeftRailTab[] tabs = LeftRailTab.values();
        int tabCount = tabs.length;

        int availableH = this.height - 42 - startY;
        int btnH = Math.max(24, Math.min(36, (availableH / tabCount) - 3));
        int stepY = btnH + 3;

        for (int i = 0; i < tabCount; i++) {
            LeftRailTab tab = tabs[i];
            railButtons.add(new IconButton(railX, startY + (i * stepY), railW, btnH, tab.icon, tab.label, tab.title, () -> {
                if (tab == LeftRailTab.TRACKER) { if (this.client != null) this.client.setScreen(new TrackerScreen(this)); }
                else if (tab == LeftRailTab.SETTINGS) { if (this.client != null) this.client.setScreen(new SettingsScreen(this)); }
                else if (tab == LeftRailTab.HOSTING) { setFeedback("Local P2P Hosting (Coming Soon)", false); }
                else { this.activeTab = tab; updateRailActiveStates(); updateInputBarVisibility(); }
            }));
        }
        updateRailActiveStates();
        railButtons.add(new IconButton(railX, this.height - 38, railW, 28, "✕", null, "Close", this::close));

        int contentX = railX + railW + 4, contentY = 38, contentH = this.height - 44;
        this.friendsTab = new FriendsTabView(contentX, contentY, this.width - contentX - 6, contentH, this);

        int listW = Math.max(140, Math.min(200, (this.width - contentX) * 36 / 100));
        this.conversationList = new ConversationListView(contentX, contentY, listW, contentH, this);

        int chatX = contentX + listW + 4, chatW = this.width - chatX - 6, inputH = 22, inputY = this.height - 30;
        this.chatPanel = new ChatPanelView(chatX, contentY, chatW, contentH, this);

        this.chatInputField = this.addDrawableChild(new TextFieldWidget(this.textRenderer, chatX + 6, inputY, chatW - 66, inputH, Text.literal("Chat Input")));
        this.chatInputField.setMaxLength(256);
        this.chatInputField.setEditableColor(0xFFFFFFFF);
        this.chatInputField.setUneditableColor(0xFFA0AEC0);

        this.sendButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("➤"), b -> sendMessage()).dimensions(chatX + chatW - 56, inputY, 50, inputH).build());
        this.groupModals.init(this.width, this.height, this.textRenderer, this::addDrawableChild);
        updateInputBarVisibility();
    }

    private void updateRailActiveStates() {
        for (int i = 0; i < LeftRailTab.values().length && i < railButtons.size(); i++) {
            railButtons.get(i).setActive(LeftRailTab.values()[i] == activeTab);
        }
    }

    private void updateInputBarVisibility() {
        boolean showChat = (activeTab != LeftRailTab.FRIENDS);
        if (chatInputField != null) chatInputField.setVisible(showChat);
        if (sendButton != null) sendButton.visible = showChat;
    }

    @Override public void onOpenAddFriend() { if (this.client != null) this.client.setScreen(new AddFriendScreen(this)); }
    @Override public void onSelectFriend(String friendName) {
        this.selectedFriend = friendName;
        this.selectedGroupId = null;
        this.activeTab = LeftRailTab.CHATS;
        updateRailActiveStates();
        updateInputBarVisibility();
        ChatHistoryManager.getInstance().setCurrentlyViewingFriend(friendName);
        GroupManager.getInstance().setCurrentlyViewingGroupId(null);
        if (this.chatInputField != null) { this.chatInputField.setMaxLength(256); this.setFocused(this.chatInputField); }
        if (this.chatPanel != null) this.chatPanel.scrollToBottom();
    }

    @Override public void onTrackFriend(String friendName) {
        if (this.client != null && this.client.player != null) {
            OfflineFriendsClient.startTracking(friendName);
            setFeedback("Tracking compass pointing towards " + friendName, false);
        }
    }

    @Override public void onSelectGroup(String groupId) {
        this.selectedGroupId = groupId;
        this.selectedFriend = null;
        this.activeTab = LeftRailTab.GROUPS;
        updateRailActiveStates();
        updateInputBarVisibility();
        GroupManager.getInstance().setCurrentlyViewingGroupId(groupId);
        ChatHistoryManager.getInstance().setCurrentlyViewingFriend(null);
        if (this.chatInputField != null && groupId != null) {
            this.chatInputField.setMaxLength(GroupManager.getMaxVisibleTextLength(groupId));
            this.setFocused(this.chatInputField);
        }
        if (this.chatPanel != null) this.chatPanel.scrollToBottom();
    }

    @Override public void onOpenCreateGroupModal() { this.groupModals.openCreate(); }
    @Override public void onTabChanged(LeftRailTab tab) { this.activeTab = tab; updateRailActiveStates(); updateInputBarVisibility(); }
    @Override public void onRetryMessage(String friendName, String text) {
        SocialWebSocketClient.getInstance().sendDirectMessage(friendName, text);
        setFeedback("Retrying send to " + friendName + "...", false);
    }
    @Override public void onOpenGroupDetails() {}
    @Override public void onRenameGroup() {
        if (selectedGroupId != null) {
            GroupManager.GroupInfo g = GroupManager.getInstance().getGroup(selectedGroupId);
            this.groupModals.openRename(selectedGroupId, g != null ? g.getName() : "");
        }
    }
    @Override public void onLeaveGroup() {
        if (selectedGroupId != null) {
            GroupManager.getInstance().leaveGroup(selectedGroupId);
            this.selectedGroupId = null;
            setFeedback("Left group", false);
        }
    }

    private void sendMessage() {
        if (chatInputField == null) return;
        String text = chatInputField.getText().trim();
        if (text.isEmpty()) return;

        if (selectedGroupId != null) {
            GroupManager.getInstance().sendGroupMessage(selectedGroupId, text);
            chatInputField.setText("");
            if (chatPanel != null) chatPanel.scrollToBottom();
        } else if (selectedFriend != null) {
            boolean ok = SocialWebSocketClient.getInstance().sendDirectMessage(selectedFriend, text);
            chatInputField.setText("");
            if (chatPanel != null) chatPanel.scrollToBottom();
            if (!ok && !SocialWebSocketClient.getInstance().isConnected()) setFeedback("Not connected: Message queued", true);
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);
        context.fill(0, 0, this.width, this.height, 0x88000000);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // (a) Header Bar & Navigation Tabs (Pinned at top: y = 4 to y = 34)
        Theme.drawGlassPanel(context, 4, 4, this.width - 8, 30);
        context.drawTextWithShadow(this.textRenderer, "Offline Friends", 12, 14, Theme.TEXT_TITLE);
        Theme.drawRoundedRect(context, 102, 10, 40, 16, Theme.BG_CARD_HOVER, Theme.BORDER_CARD);
        context.drawCenteredTextWithShadow(this.textRenderer, "v1.3.5", 122, 14, Theme.getAccentText());

        renderTopTabBar(context, mouseX, mouseY);

        // (b) Left Rail
        Theme.drawGlassPanel(context, 4, 38, 44, this.height - 44);
        for (IconButton btn : railButtons) btn.render(context, this.textRenderer, mouseX, mouseY);

        // (c) Main Content Area based on activeTab
        if (activeTab == LeftRailTab.FRIENDS) {
            if (friendsTab != null) friendsTab.renderContent(context, this.textRenderer, mouseX, mouseY, selectedFriend);
        } else {
            if (conversationList != null) conversationList.renderContent(context, this.textRenderer, mouseX, mouseY, activeTab, selectedFriend, selectedGroupId);
            if (chatPanel != null) chatPanel.renderContent(context, this.textRenderer, mouseX, mouseY, selectedFriend, selectedGroupId);
        }

        // (d) Widgets Layer
        context.createNewRootLayer();
        if (activeTab != LeftRailTab.FRIENDS && chatPanel != null && chatInputField != null && chatInputField.isVisible()) {
            boolean hasChat = (selectedFriend != null || selectedGroupId != null);
            chatInputField.setEditable(hasChat);
            chatInputField.setPlaceholder(Text.literal(hasChat ? "Type message..." : "Select a conversation"));
            if (sendButton != null) sendButton.active = hasChat;

            int chatX = chatPanel.getX(), chatW = chatPanel.getWidth(), inputY = this.height - 30, inputH = 22;
            context.fill(chatX + 1, inputY - 4, chatX + chatW - 1, inputY + inputH + 4, 0xFF0B0F19);
            context.fill(chatX + 1, inputY - 5, chatX + chatW - 1, inputY - 4, 0xFF334155);
            context.fill(chatInputField.getX() - 1, inputY - 1, chatInputField.getX() + chatInputField.getWidth() + 1, inputY + inputH + 1, 0xFF334155);
        }

        super.render(context, mouseX, mouseY, delta);

        // (e) Topmost overlays
        context.createNewRootLayer();
        if (activeTab == LeftRailTab.FRIENDS) {
            if (friendsTab != null) friendsTab.renderOverlay(context, this.textRenderer);
        } else {
            if (chatPanel != null) chatPanel.renderOverlay(context, this.textRenderer);
            if (conversationList != null) conversationList.renderOverlay(context, this.textRenderer);
        }

        if (feedbackMessage != null && System.currentTimeMillis() < feedbackExpiryTime) {
            int bw = Math.min(320, this.width - 80), bx = this.width / 2 - bw / 2;
            Theme.drawRoundedRect(context, bx, 44, bw, 20, 0xFF0B0F19, feedbackColor);
            context.drawCenteredTextWithShadow(this.textRenderer, feedbackMessage, bx + bw / 2, 50, feedbackColor);
        }

        groupModals.render(context, this.textRenderer, this.width, this.height);
        LeftNotificationManager.render(context, mouseX, mouseY, delta);
    }

    private void renderTopTabBar(DrawContext context, int mouseX, int mouseY) {
        LeftRailTab[] navTabs = { LeftRailTab.FRIENDS, LeftRailTab.CHATS, LeftRailTab.GROUPS, LeftRailTab.TRACKER, LeftRailTab.SETTINGS };
        int startX = 148, tabH = 22, tabY = 8;
        int maxTabW = Math.max(46, Math.min(72, (this.width - startX - 34) / navTabs.length));

        for (int i = 0; i < navTabs.length; i++) {
            LeftRailTab tab = navTabs[i];
            int tx = startX + (i * (maxTabW + 4));
            boolean isCur = (tab == activeTab);
            boolean hov = mouseX >= tx && mouseX <= tx + maxTabW && mouseY >= tabY && mouseY <= tabY + tabH;

            if (isCur) {
                Theme.drawRoundedRect(context, tx, tabY, maxTabW, tabH, Theme.getAccentPrimary(), Theme.BORDER_HIGHLIGHT);
                context.drawCenteredTextWithShadow(this.textRenderer, tab.label, tx + maxTabW / 2, tabY + 7, 0xFFFFFFFF);
            } else {
                Theme.drawSolidCard(context, tx, tabY, maxTabW, tabH, hov);
                context.drawCenteredTextWithShadow(this.textRenderer, tab.label, tx + maxTabW / 2, tabY + 7, hov ? Theme.TEXT_TITLE : Theme.TEXT_PRIMARY);
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean bl) {
        double mx = click.x(), my = click.y();

        if (groupModals.mouseClicked(mx, my, click.button(), this.width, this.height,
                createdGroup -> onSelectGroup(createdGroup.getId()),
                renamedName -> setFeedback("Group renamed to " + renamedName, false))) return true;

        if (my >= 8 && my <= 30) {
            LeftRailTab[] navTabs = { LeftRailTab.FRIENDS, LeftRailTab.CHATS, LeftRailTab.GROUPS, LeftRailTab.TRACKER, LeftRailTab.SETTINGS };
            int startX = 148, maxTabW = Math.max(46, Math.min(72, (this.width - startX - 34) / navTabs.length));
            for (int i = 0; i < navTabs.length; i++) {
                int tx = startX + (i * (maxTabW + 4));
                if (mx >= tx && mx <= tx + maxTabW) {
                    LeftRailTab tab = navTabs[i];
                    if (tab == LeftRailTab.TRACKER) { if (this.client != null) this.client.setScreen(new TrackerScreen(this)); }
                    else if (tab == LeftRailTab.SETTINGS) { if (this.client != null) this.client.setScreen(new SettingsScreen(this)); }
                    else { this.activeTab = tab; updateRailActiveStates(); updateInputBarVisibility(); }
                    return true;
                }
            }
        }

        if (activeTab == LeftRailTab.FRIENDS) {
            if (friendsTab != null && friendsTab.mouseClickedOverlay(mx, my)) return true;
        } else {
            if (conversationList != null && conversationList.mouseClickedOverlay(mx, my)) return true;
            if (chatPanel != null && chatPanel.mouseClickedOverlay(mx, my)) return true;
        }

        if (super.mouseClicked(click, bl)) return true;
        for (IconButton btn : railButtons) { if (btn.mouseClicked(mx, my, click.button())) return true; }

        if (activeTab == LeftRailTab.FRIENDS) {
            if (friendsTab != null && friendsTab.mouseClickedContent(mx, my, click.button())) return true;
        } else {
            if (conversationList != null && conversationList.mouseClickedContent(mx, my, click.button(), activeTab, selectedFriend, selectedGroupId)) return true;
            if (chatPanel != null && chatPanel.mouseClickedContent(mx, my, click.button(), selectedFriend, selectedGroupId)) return true;
        }

        return LeftNotificationManager.handleClick(mx, my);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (activeTab == LeftRailTab.FRIENDS) {
            if (friendsTab != null && friendsTab.mouseDragged(click.x(), click.y(), click.button(), dx, dy)) return true;
        } else {
            if (conversationList != null && conversationList.mouseDragged(click.x(), click.y(), click.button(), dx, dy)) return true;
            if (chatPanel != null && chatPanel.mouseDragged(click.x(), click.y(), click.button(), dx, dy)) return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        for (IconButton btn : railButtons) btn.mouseReleased(click.x(), click.y(), click.button());
        if (activeTab == LeftRailTab.FRIENDS) {
            if (friendsTab != null) friendsTab.mouseReleased(click.x(), click.y(), click.button());
        } else {
            if (conversationList != null) conversationList.mouseReleased(click.x(), click.y(), click.button());
            if (chatPanel != null) chatPanel.mouseReleased(click.x(), click.y(), click.button());
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (activeTab == LeftRailTab.FRIENDS) {
            if (friendsTab != null && friendsTab.mouseScrolled(mx, my, hAmount, vAmount)) return true;
        } else {
            if (conversationList != null && conversationList.mouseScrolled(mx, my, hAmount, vAmount)) return true;
            if (chatPanel != null && chatPanel.mouseScrolled(mx, my, hAmount, vAmount)) return true;
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (groupModals.charTyped(input)) return true;
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (groupModals.keyPressed(input)) return true;
        if (input != null && input.key() == 257 && chatInputField != null && chatInputField.isFocused()) {
            sendMessage();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(this.parent);
        else super.close();
    }
}
