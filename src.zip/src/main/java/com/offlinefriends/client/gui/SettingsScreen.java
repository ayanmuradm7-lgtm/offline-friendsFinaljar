package com.offlinefriends.client.gui;

import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.modals.BlockedMutedDialog;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.social.SocialWebSocketClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * SettingsScreen
 * 
 * Dark glass-style settings screen with 6 selectable accent colors,
 * avatar profile selector, reduce animations toggle, blocked/muted manager,
 * and secret token security. Modularized under 350 lines.
 */
public class SettingsScreen extends Screen {

    private final Screen parent;
    private TextFieldWidget serverAddressField;
    private TextFieldWidget usernameField;

    private boolean tempSound;
    private String tempPos;
    private boolean tempShareServer;
    private boolean tempInvisible;
    private boolean tempAutoAccept;
    private boolean tempOnlineNotifications;
    private boolean tempAllowGroupInvites;
    private String tempAvatarMode;
    private boolean tempReduceAnimations;
    private String tempAccentColor;
    private boolean tokenRegenerated = false;

    private final BlockedMutedDialog blockedMutedDialog = new BlockedMutedDialog();

    private ButtonWidget autoAcceptBtn;
    private ButtonWidget onlineNotifBtn;
    private ButtonWidget groupInvitesBtn;
    private ButtonWidget soundBtn;
    private ButtonWidget posBtn;
    private ButtonWidget shareServerBtn;
    private ButtonWidget avatarBtn;
    private ButtonWidget animBtn;
    private ButtonWidget accentBtn;
    private ButtonWidget invisibleBtn;
    private ButtonWidget blockedMutedBtn;

    public SettingsScreen(Screen parent) {
        super(Text.literal("Offline Friends - Settings"));
        this.parent = parent;

        ModConfig config = ModConfig.getInstance();
        this.tempSound = config.isSoundEnabled();
        this.tempPos = config.getNotificationPosition();
        this.tempShareServer = config.isShareMyServer();
        this.tempInvisible = config.isInvisible();
        this.tempAutoAccept = config.isAutoAcceptFriends();
        this.tempOnlineNotifications = config.isOnlineNotificationsEnabled();
        this.tempAllowGroupInvites = config.isAllowGroupInvitesFromFriends();
        this.tempAvatarMode = config.getAvatarMode();
        this.tempReduceAnimations = config.isReduceAnimations();
        this.tempAccentColor = config.getAccentColor();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = 12;

        // 1. Server Address Field
        this.serverAddressField = this.addDrawableChild(new TextFieldWidget(
                this.textRenderer,
                centerX - 150, startY + 12,
                300, 18,
                Text.literal("Server Address")
        ));
        this.serverAddressField.setMaxLength(128);
        this.serverAddressField.setPlaceholder(Text.literal("Empty = Default Live Relay"));
        this.serverAddressField.setText(ModConfig.getInstance().getServerAddress());

        // 2. Social Username Tag Field
        this.usernameField = this.addDrawableChild(new TextFieldWidget(
                this.textRenderer,
                centerX - 150, startY + 42,
                300, 18,
                Text.literal("Social Username")
        ));
        this.usernameField.setMaxLength(32);
        this.usernameField.setPlaceholder(Text.literal("Username tag (e.g. Player_2 if sharing account)"));
        this.usernameField.setText(ModConfig.getInstance().getEffectiveUsername());

        // 3. Row 1: Auto-Accept & Online Alerts
        this.autoAcceptBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Auto-Accept: " + (tempAutoAccept ? "ON" : "OFF")),
                b -> {
                    tempAutoAccept = !tempAutoAccept;
                    b.setMessage(Text.literal("Auto-Accept: " + (tempAutoAccept ? "ON" : "OFF")));
                }
        ).dimensions(centerX - 150, startY + 66, 145, 18).build());

        this.onlineNotifBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Online Alerts: " + (tempOnlineNotifications ? "ON" : "OFF")),
                b -> {
                    tempOnlineNotifications = !tempOnlineNotifications;
                    b.setMessage(Text.literal("Online Alerts: " + (tempOnlineNotifications ? "ON" : "OFF")));
                }
        ).dimensions(centerX + 5, startY + 66, 145, 18).build());

        // 4. Row 2: Group Invites & Sound Effects
        this.groupInvitesBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Group Invites: " + (tempAllowGroupInvites ? "ON" : "OFF")),
                b -> {
                    tempAllowGroupInvites = !tempAllowGroupInvites;
                    b.setMessage(Text.literal("Group Invites: " + (tempAllowGroupInvites ? "ON" : "OFF")));
                }
        ).dimensions(centerX - 150, startY + 87, 145, 18).build());

        this.soundBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Sound: " + (tempSound ? "ON" : "MUTED")),
                b -> {
                    tempSound = !tempSound;
                    b.setMessage(Text.literal("Sound: " + (tempSound ? "ON" : "MUTED")));
                }
        ).dimensions(centerX + 5, startY + 87, 145, 18).build());

        // 5. Row 3: Toast Position & Share Server
        this.posBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Toasts: " + tempPos),
                b -> {
                    tempPos = "TOP_LEFT".equalsIgnoreCase(tempPos) ? "BOTTOM_LEFT" : "TOP_LEFT";
                    b.setMessage(Text.literal("Toasts: " + tempPos));
                }
        ).dimensions(centerX - 150, startY + 108, 145, 18).build());

        this.shareServerBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Share Server: " + (tempShareServer ? "ON" : "HIDDEN")),
                b -> {
                    tempShareServer = !tempShareServer;
                    b.setMessage(Text.literal("Share Server: " + (tempShareServer ? "ON" : "HIDDEN")));
                }
        ).dimensions(centerX + 5, startY + 108, 145, 18).build());

        // 6. Row 4: Avatar Mode & Reduce Animations
        final String[] AVATAR_MODES = {"AUTO", "STEVE", "ALEX", "ARI", "EFE", "KAI", "MAKENA", "NOOR", "SUNNY", "ZURI", "LOCAL_SKIN"};
        this.avatarBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Avatar: " + tempAvatarMode),
                b -> {
                    int nextIdx = 0;
                    for (int i = 0; i < AVATAR_MODES.length; i++) {
                        if (AVATAR_MODES[i].equalsIgnoreCase(tempAvatarMode)) {
                            nextIdx = (i + 1) % AVATAR_MODES.length;
                            break;
                        }
                    }
                    tempAvatarMode = AVATAR_MODES[nextIdx];
                    b.setMessage(Text.literal("Avatar: " + tempAvatarMode));
                }
        ).dimensions(centerX - 150, startY + 129, 145, 18).build());

        this.animBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Anim: " + (tempReduceAnimations ? "REDUCED" : "SMOOTH")),
                b -> {
                    tempReduceAnimations = !tempReduceAnimations;
                    b.setMessage(Text.literal("Anim: " + (tempReduceAnimations ? "REDUCED" : "SMOOTH")));
                }
        ).dimensions(centerX + 5, startY + 129, 145, 18).build());

        // 7. Row 5: Accent Color Picker (6 selectable accents) & Invisible Mode
        final Theme.AccentColor[] ACCENTS = Theme.AccentColor.values();
        this.accentBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Theme Accent: " + tempAccentColor),
                b -> {
                    int nextIdx = 0;
                    for (int i = 0; i < ACCENTS.length; i++) {
                        if (ACCENTS[i].name().equalsIgnoreCase(tempAccentColor)) {
                            nextIdx = (i + 1) % ACCENTS.length;
                            break;
                        }
                    }
                    Theme.AccentColor chosen = ACCENTS[nextIdx];
                    tempAccentColor = chosen.name();
                    Theme.setAccent(chosen);
                    b.setMessage(Text.literal("Theme Accent: " + tempAccentColor));
                }
        ).dimensions(centerX - 150, startY + 150, 145, 18).build());

        this.invisibleBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Invisible: " + (tempInvisible ? "ON" : "OFF")),
                b -> {
                    tempInvisible = !tempInvisible;
                    b.setMessage(Text.literal("Invisible: " + (tempInvisible ? "ON" : "OFF")));
                }
        ).dimensions(centerX + 5, startY + 150, 145, 18).build());

        // 8. Row 6: Manage Blocked/Muted & Regenerate Token
        int blockedCount = ModConfig.getInstance().getBlockedUsers().size();
        int mutedCount = ModConfig.getInstance().getMutedFriends().size();
        this.blockedMutedBtn = this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Blocked (" + blockedCount + ") / Muted (" + mutedCount + ")"),
                b -> blockedMutedDialog.setOpen(!blockedMutedDialog.isOpen())
        ).dimensions(centerX - 150, startY + 171, 145, 18).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Regenerate Secret Token"),
                b -> {
                    ModConfig.getInstance().regenerateToken();
                    this.tokenRegenerated = true;
                    b.setMessage(Text.literal("Token Regenerated!"));
                }
        ).dimensions(centerX + 5, startY + 171, 145, 18).build());

        // 9. Save & Connect / Cancel Buttons
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Save & Connect"), b -> handleSave())
                .dimensions(centerX - 150, startY + 195, 145, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> this.close())
                .dimensions(centerX + 5, startY + 195, 145, 20).build());
    }

    private void handleSave() {
        ModConfig config = ModConfig.getInstance();
        String oldAddr = config.getServerAddress();
        String newAddr = this.serverAddressField.getText().trim();

        String oldUsername = config.getEffectiveUsername();
        String newUsername = this.usernameField != null ? this.usernameField.getText().trim() : "";

        boolean usernameChanged = !newUsername.isEmpty() && !newUsername.equalsIgnoreCase(oldUsername);
        if (usernameChanged) {
            config.setUsername(newUsername);
            config.regenerateToken();
            this.tokenRegenerated = true;
        }

        config.setServerAddress(newAddr);
        config.setSoundEnabled(tempSound);
        config.setNotificationPosition(tempPos);
        config.setShareMyServer(tempShareServer);
        config.setInvisible(tempInvisible);
        config.setAutoAcceptFriends(tempAutoAccept);
        config.setOnlineNotificationsEnabled(tempOnlineNotifications);
        config.setAllowGroupInvitesFromFriends(tempAllowGroupInvites);
        config.setAvatarMode(tempAvatarMode);
        config.setReduceAnimations(tempReduceAnimations);
        config.setAccentColor(tempAccentColor);
        config.save();

        if (!newAddr.equalsIgnoreCase(oldAddr) || tokenRegenerated || usernameChanged) {
            SocialWebSocketClient.getInstance().reconnectAsync();
        } else {
            SocialWebSocketClient.getInstance().sendPresence();
        }

        this.close();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);
        int centerX = this.width / 2;
        int startY = 12;
        context.fill(0, 0, this.width, this.height, 0x66000000);
        Theme.drawRoundedRect(context, centerX - 160, startY - 6, 320, 240, Theme.BG_DARK_GLASS, Theme.BORDER_SUBTLE);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int startY = 12;

        context.drawCenteredTextWithShadow(this.textRenderer, "Offline Friends Settings", centerX, startY - 3, Theme.TEXT_TITLE);
        context.drawText(this.textRenderer, "Server Address (WebSocket URL):", centerX - 150, startY + 2, Theme.TEXT_MUTED, false);
        context.drawText(this.textRenderer, "Social Username Tag (Override for dual phone):", centerX - 150, startY + 32, Theme.TEXT_MUTED, false);

        // Security indicator
        context.drawCenteredTextWithShadow(this.textRenderer,
                "Secret Token: •••••••••••• (Stored locally in config)",
                centerX, startY + 220, Theme.TEXT_DIM);

        // Modal for Blocked & Muted Users
        blockedMutedDialog.render(context, this.textRenderer, this.width, this.height, mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(Click click, boolean bl) {
        if (blockedMutedDialog.mouseClicked(click.x(), click.y(), this.width, this.height, () -> {
            if (blockedMutedBtn != null) {
                int b = ModConfig.getInstance().getBlockedUsers().size();
                int m = ModConfig.getInstance().getMutedFriends().size();
                blockedMutedBtn.setMessage(Text.literal("Blocked (" + b + ") / Muted (" + m + ")"));
            }
        })) {
            return true;
        }

        if (!blockedMutedDialog.isOpen()) {
            if (this.usernameField != null && this.usernameField.mouseClicked(click, bl)) {
                this.setFocused(this.usernameField);
                return true;
            }
            if (this.serverAddressField != null && this.serverAddressField.mouseClicked(click, bl)) {
                this.setFocused(this.serverAddressField);
                return true;
            }
        }

        return super.mouseClicked(click, bl);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (this.usernameField != null && this.usernameField.isFocused()) return this.usernameField.charTyped(input);
        if (this.serverAddressField != null && this.serverAddressField.isFocused()) return this.serverAddressField.charTyped(input);
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (blockedMutedDialog.isOpen() && input != null && input.key() == 256) {
            blockedMutedDialog.setOpen(false);
            return true;
        }
        if (this.usernameField != null && this.usernameField.isFocused()) {
            if (input != null && input.key() == 256) { this.close(); return true; }
            return this.usernameField.keyPressed(input);
        }
        if (this.serverAddressField != null && this.serverAddressField.isFocused()) {
            if (input != null && input.key() == 256) { this.close(); return true; }
            return this.serverAddressField.keyPressed(input);
        }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(this.parent);
        else super.close();
    }
}
