package com.offlinefriends.client.render;

import com.offlinefriends.client.OfflineFriendsClient;
import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.social.SocialWebSocketClient;
import com.offlinefriends.util.ModLogger;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * PlayerTrackingRenderer
 * 
 * Implements In-Server & Relay Player Tracking Visuals:
 * - HUD Compass Radar Badge with dark glass styling, friend avatar, distance, health, and dimension.
 * - Active "Tracked by" warning badge with 40px touch-friendly [STOP] button.
 * - Safe 3D billboard waypoint marker in-world.
 * - Zero blur, zero custom shaders, zero per-frame allocations.
 */
public class PlayerTrackingRenderer {

    public static void renderHud(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return;

        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        OfflineFriendsClient.TrackedTarget target = OfflineFriendsClient.getCurrentTrackedTarget();
        String activeTarget = social.getActiveTrackingTarget();
        String beingTrackedBy = social.getActiveBeingTrackedBy();

        int screenWidth = client.getWindow() != null ? client.getWindow().getScaledWidth() : 360;
        TextRenderer tr = client.textRenderer;

        // 1. Being Tracked Alert on HUD with One-Tap Stop
        if (beingTrackedBy != null) {
            int trackAlertX = Math.max(8, screenWidth / 2 - 130);
            int trackAlertY = 32;
            int boxW = 260;
            int boxH = 18;
            Theme.drawRoundedRect(context, trackAlertX, trackAlertY, boxW, boxH, 0xDD7F1D1D, 0xFFEF4444);

            AvatarWidget.drawHead(context, beingTrackedBy, trackAlertX + 4, trackAlertY + 2, 14);
            context.drawText(tr, "Tracked by: " + beingTrackedBy, trackAlertX + 22, trackAlertY + 5, 0xFFFFFFFF, false);

            int stopX = trackAlertX + boxW - 48;
            context.fill(stopX, trackAlertY + 2, stopX + 44, trackAlertY + boxH - 2, 0xFFDC2626);
            context.drawCenteredTextWithShadow(tr, "STOP", stopX + 22, trackAlertY + 5, 0xFFFFFFFF);
        }

        // 2. Outgoing Tracking Radar Compass
        if (!OfflineFriendsClient.isTrackingVisualsEnabled()) {
            return;
        }
        if (target == null && activeTarget == null) {
            return;
        }

        try {
            int bannerX = Math.max(8, screenWidth / 2 - 135);
            int bannerY = 6;
            int bannerWidth = 270;
            int bannerHeight = 24;

            if (target != null && target.active()) {
                long now = System.currentTimeMillis();
                boolean isSignalLost = (now - target.lastUpdateTime()) > 10_000L;

                String myServer = social.getLocalServer();
                String myDim = client.player.getEntityWorld() != null ?
                        client.player.getEntityWorld().getRegistryKey().getValue().toString() : "";

                boolean sameServer = (target.server() == null && myServer == null) ||
                        (target.server() != null && target.server().equalsIgnoreCase(myServer));
                boolean sameDim = target.dimension() != null && target.dimension().equalsIgnoreCase(myDim);

                if (isSignalLost) {
                    Theme.drawRoundedRect(context, bannerX, bannerY, bannerWidth, bannerHeight, Theme.BG_DARK_GLASS, 0xFFEF4444);
                    AvatarWidget.drawHead(context, target.username(), bannerX + 4, bannerY + 3, 18);
                    context.drawText(tr, target.username() + " • Signal lost (>10s)", bannerX + 26, bannerY + 8, 0xFFEF4444, false);
                } else if (!sameServer || !sameDim) {
                    Theme.drawRoundedRect(context, bannerX, bannerY, bannerWidth, bannerHeight, Theme.BG_DARK_GLASS, 0xFFF59E0B);
                    AvatarWidget.drawHead(context, target.username(), bannerX + 4, bannerY + 3, 18);
                    String diff = !sameServer ? "Different server" : "Different dimension (" + target.dimension() + ")";
                    context.drawText(tr, target.username() + " • " + diff, bannerX + 26, bannerY + 8, 0xFFF59E0B, false);
                } else {
                    double dx = target.x() - client.player.getX();
                    double dy = target.y() - client.player.getY();
                    double dz = target.z() - client.player.getZ();
                    double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);

                    // Compass angle relative to player yaw
                    double angleToTarget = Math.toDegrees(Math.atan2(-dx, dz));
                    double playerYaw = client.player.getYaw() % 360.0;
                    if (playerYaw < -180.0) playerYaw += 360.0;
                    if (playerYaw > 180.0) playerYaw -= 360.0;

                    double relAngle = angleToTarget - playerYaw;
                    while (relAngle < -180.0) relAngle += 360.0;
                    while (relAngle > 180.0) relAngle -= 360.0;

                    String directionArrow = "▲";
                    if (relAngle > 45.0 && relAngle <= 135.0) directionArrow = "►";
                    else if (relAngle < -45.0 && relAngle >= -135.0) directionArrow = "◄";
                    else if (Math.abs(relAngle) > 135.0) directionArrow = "▼";

                    Theme.drawRoundedRect(context, bannerX, bannerY, bannerWidth, bannerHeight, Theme.BG_DARK_GLASS, Theme.getAccentPrimary());
                    AvatarWidget.drawHead(context, target.username(), bannerX + 4, bannerY + 3, 18);

                    String hpStr = target.maxHealth() > 0 ? String.format(" • %.0f/%.0f HP", target.health(), target.maxHealth()) : "";
                    String info = String.format("%s %.0fm%s", target.username(), distance, hpStr);
                    context.drawText(tr, info, bannerX + 26, bannerY + 8, Theme.TEXT_PRIMARY, false);

                    // Direction Arrow at right
                    context.drawText(tr, directionArrow, bannerX + bannerWidth - 18, bannerY + 7, Theme.getAccentPrimary(), false);
                }
            } else if (activeTarget != null) {
                Theme.drawRoundedRect(context, bannerX, bannerY, bannerWidth, bannerHeight, Theme.BG_DARK_GLASS, Theme.BORDER_SUBTLE);
                AvatarWidget.drawHead(context, activeTarget, bannerX + 4, bannerY + 3, 18);
                context.drawText(tr, activeTarget + " (Connecting via Relay...)", bannerX + 26, bannerY + 8, Theme.TEXT_SECONDARY, false);
            }
        } catch (Exception e) {
            ModLogger.warn("HUD render error: {}", e.getMessage(), e);
        }
    }

    public static boolean handleHudClick(double mouseX, double mouseY) {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        String beingTrackedBy = social.getActiveBeingTrackedBy();
        if (beingTrackedBy == null) return false;

        MinecraftClient client = MinecraftClient.getInstance();
        int screenWidth = (client != null && client.getWindow() != null) ? client.getWindow().getScaledWidth() : 360;
        int trackAlertX = Math.max(8, screenWidth / 2 - 130);
        int trackAlertY = 32;
        int boxW = 260;
        int boxH = 18;
        int stopX = trackAlertX + boxW - 48;

        if (mouseX >= stopX && mouseX <= stopX + 44 && mouseY >= trackAlertY + 2 && mouseY <= trackAlertY + boxH - 2) {
            social.sendTrackStop(beingTrackedBy);
            return true;
        }
        return false;
    }

    public static void renderWorld(WorldRenderContext context) {
        OfflineFriendsClient.TrackedTarget target = OfflineFriendsClient.getCurrentTrackedTarget();
        if (target == null || !target.active() || !OfflineFriendsClient.isTrackingVisualsEnabled()) {
            return;
        }

        if ((System.currentTimeMillis() - target.lastUpdateTime()) > 10_000L) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.world == null) return;

        String myServer = SocialWebSocketClient.getInstance().getLocalServer();
        String myDim = client.player.getEntityWorld().getRegistryKey().getValue().toString();
        boolean sameServer = (target.server() == null && myServer == null) ||
                (target.server() != null && target.server().equalsIgnoreCase(myServer));
        boolean sameDim = target.dimension() != null && target.dimension().equalsIgnoreCase(myDim);

        if (!sameServer || !sameDim) {
            return;
        }

        Camera camera = client.gameRenderer != null ? client.gameRenderer.getCamera() : null;
        if (camera == null) return;
        Vec3d camPos = camera.getCameraPos();
        if (camPos == null) return;
        MatrixStack matrixStack = context.matrices();
        if (matrixStack == null) return;

        try {
            double relX = target.x() - camPos.x;
            double relY = target.y() - camPos.y + 1.2;
            double relZ = target.z() - camPos.z;
            double distance = Math.sqrt(relX * relX + relY * relY + relZ * relZ);

            renderWaypointBillboard(matrixStack, context.consumers(), camera, relX, relY, relZ, target.username(), distance, target.health(), target.maxHealth());
        } catch (Exception e) {
            ModLogger.warn("World render error: {}", e.getMessage(), e);
        }
    }

    private static void renderWaypointBillboard(
            MatrixStack matrixStack,
            VertexConsumerProvider consumers,
            Camera camera,
            double x, double y, double z,
            String username,
            double distance,
            float health,
            float maxHealth
    ) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.textRenderer == null || consumers == null) return;
        TextRenderer textRenderer = mc.textRenderer;

        matrixStack.push();
        matrixStack.translate(x, y, z);
        matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
        matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));

        float baseScale = 0.025f;
        float distFactor = (float) Math.max(1.0, distance * 0.05);
        float scale = Math.min(baseScale * distFactor, 0.45f);
        matrixStack.scale(-scale, -scale, scale);

        Matrix4f mat = matrixStack.peek().getPositionMatrix();

        String hpStr = maxHealth > 0 ? String.format(" [%.0f/%.0f HP]", health, maxHealth) : "";
        String headerText = "◎ " + username + String.format(" [%.0fm]%s", distance, hpStr);
        int headerWidth = textRenderer.getWidth(headerText);
        textRenderer.draw(
                headerText,
                -headerWidth / 2.0f,
                -10.0f,
                Theme.getAccentPrimary(),
                false,
                mat,
                consumers,
                TextRenderer.TextLayerType.SEE_THROUGH,
                0x88000000,
                15728880
        );

        matrixStack.pop();
    }
}
