package com.offlinefriends.client;

import com.offlinefriends.OfflineFriendsMod;
import com.offlinefriends.client.gui.SocialScreen;
import com.offlinefriends.client.gui.TrackerScreen;
import com.offlinefriends.client.notification.LeftNotificationManager;
import com.offlinefriends.client.render.PlayerTrackingRenderer;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.network.TrackedPlayerPosS2CPayload;
import com.offlinefriends.social.SocialWebSocketClient;
import com.offlinefriends.util.ModLogger;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * OfflineFriendsClient
 * 
 * Fabric Client Mod Initializer for Offline Friends 1.1.0 on Minecraft 1.21.11.
 * Features:
 * - 100% Mixin-free architecture using official Fabric API ScreenEvents & ScreenMouseEvents.
 * - Left-side HUD notifications rendered across in-game HUD and any UI screen.
 * - Server presence reporting via ClientPlayConnectionEvents (JOIN/DISCONNECT).
 * - Clean shutdown handling via ClientLifecycleEvents.CLIENT_STOPPING.
 * - Native 1.21.11 KeyBinding.Category without reflection.
 */
public class OfflineFriendsClient implements ClientModInitializer {

    public record TrackedTarget(
            String username,
            boolean active,
            double x, double y, double z,
            String dimension,
            float health, float maxHealth,
            String server,
            long lastUpdateTime
    ) {}

    private static TrackedTarget currentTarget = null;
    private static boolean visualsEnabled = true;

    // Key Category
    public static final KeyBinding.Category OFFLINE_FRIENDS_CATEGORY = 
            KeyBinding.Category.create(Identifier.of("offlinefriends", "main"));

    // Keybindings
    public static KeyBinding openTrackingMenuKey;
    public static KeyBinding toggleTrackingVisualsKey;
    public static KeyBinding openSocialOverlayKey;

    @Override
    public void onInitializeClient() {
        ModLogger.initDebugLog();
        ModLogger.info("[Offline Friends] Initializing Client v1.3.2 for Minecraft 1.21.11...");

        // Load configuration and init token
        ModConfig.getInstance();

        // 1. Safe Screen Integration via official Fabric API ScreenEvents
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            try {
                if (screen instanceof TitleScreen) {
                    int buttonWidth = 150;
                    int buttonHeight = 20;
                    int x = scaledWidth / 2 - buttonWidth / 2;
                    int y = Math.min(scaledHeight - 26, scaledHeight / 4 + 48 + 72 + 14);

                    Screens.getButtons(screen).add(
                            ButtonWidget.builder(
                                    Text.literal("★ Friends & Social (v1.3.5)"),
                                    button -> client.setScreen(new SocialScreen(screen))
                            ).dimensions(x, y, buttonWidth, buttonHeight).build()
                    );
                } else if (screen instanceof GameMenuScreen) {
                    int topPauseY = scaledHeight / 4 - 24;
                    if (topPauseY >= 14) {
                        int midX = scaledWidth / 2;
                        Screens.getButtons(screen).add(
                                ButtonWidget.builder(
                                        Text.literal("★ Friends"),
                                        button -> client.setScreen(new SocialScreen(screen))
                                ).dimensions(midX - 102, topPauseY, 100, 20).build()
                        );
                        Screens.getButtons(screen).add(
                                ButtonWidget.builder(
                                        Text.literal("◎ Tracker"),
                                        button -> client.setScreen(new TrackerScreen(screen))
                                ).dimensions(midX + 2, topPauseY, 100, 20).build()
                        );
                    } else {
                        Screens.getButtons(screen).add(
                                ButtonWidget.builder(
                                        Text.literal("★ Friends"),
                                        button -> client.setScreen(new SocialScreen(screen))
                                ).dimensions(14, 12, 85, 20).build()
                        );
                        Screens.getButtons(screen).add(
                                ButtonWidget.builder(
                                        Text.literal("◎ Tracker"),
                                        button -> client.setScreen(new TrackerScreen(screen))
                                ).dimensions(103, 12, 85, 20).build()
                        );
                    }
                }

                // Render left-side notification overlay on top of any active screen
                ScreenEvents.afterRender(screen).register((scr, drawContext, mouseX, mouseY, tickDelta) -> {
                    LeftNotificationManager.render(drawContext, mouseX, mouseY, tickDelta);
                });

                // Consume clicks on left notifications or HUD stop tracker before they trigger background screen elements
                ScreenMouseEvents.allowMouseClick(screen).register((scr, click) -> {
                    if (PlayerTrackingRenderer.handleHudClick(click.x(), click.y())) {
                        return false;
                    }
                    boolean consumed = LeftNotificationManager.handleClick(click.x(), click.y());
                    return !consumed;
                });
            } catch (Exception e) {
                ModLogger.warn("ScreenEvents injection warning: {}", e.getMessage(), e);
            }
        });

        // 2. Safe HUD Radar & Left Notifications in Game
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            PlayerTrackingRenderer.renderHud(drawContext, tickCounter);

            // If no screen is open, render notifications via HUD
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.currentScreen == null) {
                LeftNotificationManager.render(drawContext, 0, 0, tickCounter.getTickProgress(true));
            }
        });

        // 3. Register Keybinds directly using 1.21.11 KeyBinding.Category
        openTrackingMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.offlinefriends.tracking_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                OFFLINE_FRIENDS_CATEGORY
        ));

        toggleTrackingVisualsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.offlinefriends.toggle_visuals",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_BACKSLASH,
                OFFLINE_FRIENDS_CATEGORY
        ));

        openSocialOverlayKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.offlinefriends.social_overlay",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                OFFLINE_FRIENDS_CATEGORY
        ));

        // 4. Client-side Packet Receiver for coordinate updates from Server mod
        ClientPlayNetworking.registerGlobalReceiver(TrackedPlayerPosS2CPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                if (payload.online()) {
                    currentTarget = new TrackedTarget(
                            payload.username(),
                            true,
                            payload.x(),
                            payload.y(),
                            payload.z(),
                            payload.dimension(),
                            payload.health(),
                            payload.maxHealth(),
                            null,
                            System.currentTimeMillis()
                    );
                } else {
                    currentTarget = null;
                }
            });
        });

        // 5. In-World 3D Waypoint Rendering via 1.21.11 WorldRenderEvents.END_MAIN
        WorldRenderEvents.END_MAIN.register(PlayerTrackingRenderer::renderWorld);

        // 6. Server Presence Tracking via ClientPlayConnectionEvents
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            String serverAddress;
            if (client.isInSingleplayer()) {
                serverAddress = "singleplayer";
            } else if (client.getCurrentServerEntry() != null && client.getCurrentServerEntry().address != null) {
                serverAddress = client.getCurrentServerEntry().address;
            } else if (client.isIntegratedServerRunning()) {
                serverAddress = "lan";
            } else {
                serverAddress = null;
            }
            SocialWebSocketClient.getInstance().setLocalServer(serverAddress);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            SocialWebSocketClient.getInstance().setLocalServer(null);
            SocialWebSocketClient.getInstance().onWorldDisconnect();
            clearTrackedTarget();
        });

        // 7. Client Tick Event for Keypress Detection
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openTrackingMenuKey != null) {
                while (openTrackingMenuKey.wasPressed()) {
                    client.setScreen(new TrackerScreen(client.currentScreen));
                }
            }

            if (toggleTrackingVisualsKey != null) {
                while (toggleTrackingVisualsKey.wasPressed()) {
                    visualsEnabled = !visualsEnabled;
                    if (client.player != null) {
                        client.player.sendMessage(
                                Text.literal("[Offline Friends] Tracking Visuals: " + (visualsEnabled ? "ENABLED" : "DISABLED")),
                                true
                        );
                    }
                }
            }

            if (openSocialOverlayKey != null) {
                while (openSocialOverlayKey.wasPressed()) {
                    client.setScreen(new SocialScreen(client.currentScreen));
                }
            }
        });

        // 8. Clean Shutdown Handler (graceful disconnect with presence packet)
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            SocialWebSocketClient.getInstance().shutdownGracefully();
        });

        // Lazy trigger connect if server configured
        if (!ModConfig.getInstance().getServerAddress().isEmpty()) {
            SocialWebSocketClient.getInstance().connect();
        }

        ModLogger.info("[Offline Friends] Client initialization complete.");
    }

    public static TrackedTarget getCurrentTrackedTarget() {
        return currentTarget;
    }

    public static void setCurrentTrackedTarget(TrackedTarget target) {
        currentTarget = target;
    }

    public static void clearTrackedTarget() {
        currentTarget = null;
    }

    public static boolean isTrackingVisualsEnabled() {
        return visualsEnabled;
    }

    public static void setTrackingVisualsEnabled(boolean enabled) {
        visualsEnabled = enabled;
    }
}
