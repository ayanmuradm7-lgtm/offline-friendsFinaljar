package com.offlinefriends.client.notification;

import com.offlinefriends.client.gui.SocialScreen;
import com.offlinefriends.client.gui.TrackerScreen;
import com.offlinefriends.client.ui.Anim;
import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.util.ModLogger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * LeftNotificationManager
 * 
 * Custom left-side sliding notification toasts styled with dark translucent glass.
 * - Stacks at most 3 notifications vertically.
 * - Smooth time-based slide-in animation with countdown progress bar.
 * - Deterministic avatar skin heads with composite hat layers.
 * - 40px touch-friendly hitboxes: tapping opens the corresponding DM, Tracker, or Group chat.
 * - Respects "Reduce animations" toggle (instant transitions).
 */
public class LeftNotificationManager {

    public enum Type {
        DIRECT_MESSAGE,
        TRACK_REQUEST,
        FRIEND_REQUEST,
        FRIEND_ACCEPTED,
        FRIEND_ONLINE,
        GROUP_MESSAGE
    }

    public static class NotificationItem {
        private final Type type;
        private final String senderUsername;
        private final String title;
        private final String preview;
        private final String groupId;
        private final long createdAt;
        private final long durationMs = 5000L;

        private int currentX = -260;
        private int currentY = 10;
        private int width = 220;
        private int height = 40;

        public NotificationItem(Type type, String senderUsername, String title, String preview, String groupId) {
            this.type = type;
            this.senderUsername = senderUsername != null ? senderUsername : "Friend";
            this.title = title != null ? title : "";
            this.preview = preview != null ? preview : "";
            this.groupId = groupId;
            this.createdAt = System.currentTimeMillis();
        }

        public boolean isExpired() {
            return (System.currentTimeMillis() - createdAt) > durationMs;
        }

        public boolean containsPoint(double mouseX, double mouseY) {
            return mouseX >= currentX && mouseX <= (currentX + width) &&
                   mouseY >= currentY && mouseY <= (currentY + height);
        }

        public Type getType() { return type; }
        public String getSenderUsername() { return senderUsername; }
        public String getGroupId() { return groupId; }
    }

    private static final List<NotificationItem> ACTIVE_NOTIFICATIONS = new CopyOnWriteArrayList<>();
    private static final int MAX_STACK = 3;
    private static final int CARD_WIDTH = 220;
    private static final int CARD_HEIGHT = 40;
    private static final int ANIM_DURATION_MS = 220;

    public static void showDirectMessage(String senderUsername, String preview) {
        addNotification(new NotificationItem(Type.DIRECT_MESSAGE, senderUsername, senderUsername, preview, null));
    }

    public static void showTrackRequest(String requesterUsername) {
        addNotification(new NotificationItem(Type.TRACK_REQUEST, requesterUsername, "Track Request", requesterUsername + " wants to track you", null));
    }

    public static void showFriendRequest(String senderUsername) {
        addNotification(new NotificationItem(Type.FRIEND_REQUEST, senderUsername, "Friend Request", "From " + senderUsername, null));
    }

    public static void showFriendAccepted(String friendUsername) {
        addNotification(new NotificationItem(Type.FRIEND_ACCEPTED, friendUsername, "New Friend", friendUsername + " is now your friend", null));
    }

    public static void showFriendOnline(String friendUsername, String server) {
        String detail = (server != null && !server.isEmpty()) ? "Playing on " + server : "Now online";
        addNotification(new NotificationItem(Type.FRIEND_ONLINE, friendUsername, friendUsername + " is online", detail, null));
    }

    public static void showGroupMessage(String groupId, String groupName, String senderUsername, String preview) {
        String title = groupName + " • " + senderUsername;
        addNotification(new NotificationItem(Type.GROUP_MESSAGE, senderUsername, title, preview, groupId));
    }

    private static void addNotification(NotificationItem item) {
        // Hide if user is locally blocked or notifications disabled
        if (!ModConfig.getInstance().isOnlineNotificationsEnabled()) {
            if (item.type == Type.FRIEND_ONLINE) return;
        }
        if (ModConfig.getInstance().isUserBlocked(item.senderUsername)) {
            return;
        }

        while (ACTIVE_NOTIFICATIONS.size() >= MAX_STACK) {
            ACTIVE_NOTIFICATIONS.remove(0);
        }
        ACTIVE_NOTIFICATIONS.add(item);
        playNotificationSound();
    }

    private static void playNotificationSound() {
        if (!ModConfig.getInstance().isSoundEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.player != null) {
            try {
                mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 0.75f, 1.35f);
            } catch (Exception e) {
                ModLogger.warn("Failed to play notification chime", e);
            }
        }
    }

    public static void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (ACTIVE_NOTIFICATIONS.isEmpty()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.textRenderer == null) return;
        TextRenderer tr = mc.textRenderer;

        long now = System.currentTimeMillis();
        int screenHeight = mc.getWindow() != null ? mc.getWindow().getScaledHeight() : 360;
        boolean bottomPos = "BOTTOM_LEFT".equalsIgnoreCase(ModConfig.getInstance().getNotificationPosition());
        boolean reduceAnim = ModConfig.getInstance().isReduceAnimations();

        int index = 0;
        Iterator<NotificationItem> iterator = ACTIVE_NOTIFICATIONS.iterator();

        while (iterator.hasNext()) {
            NotificationItem item = iterator.next();
            if (item.isExpired()) {
                ACTIVE_NOTIFICATIONS.remove(item);
                continue;
            }

            long elapsed = now - item.createdAt;
            long remaining = item.durationMs - elapsed;

            // Slide in & out interpolation
            float progress = 1.0f;
            if (!reduceAnim) {
                if (elapsed < ANIM_DURATION_MS) {
                    progress = (float) elapsed / ANIM_DURATION_MS;
                } else if (remaining < ANIM_DURATION_MS) {
                    progress = Math.max(0f, (float) remaining / ANIM_DURATION_MS);
                }
            }

            float ease = reduceAnim ? 1.0f : Anim.easeOutCubic(progress);
            int targetX = 8;
            int startX = -CARD_WIDTH - 20;
            int currentX = (int) (startX + (targetX - startX) * ease);

            int currentY = bottomPos ?
                    (screenHeight - 48 - index * (CARD_HEIGHT + 6)) :
                    (8 + index * (CARD_HEIGHT + 6));

            item.currentX = currentX;
            item.currentY = currentY;
            item.width = CARD_WIDTH;
            item.height = CARD_HEIGHT;

            // Card Color
            int accentColor = switch (item.type) {
                case DIRECT_MESSAGE -> Theme.getAccentPrimary();
                case TRACK_REQUEST -> 0xFFF59E0B;
                case FRIEND_REQUEST -> 0xFF38BDF8;
                case FRIEND_ACCEPTED -> 0xFF10B981;
                case FRIEND_ONLINE -> 0xFFA855F7;
                case GROUP_MESSAGE -> 0xFFEC4899;
            };

            // Glass Card Body
            Theme.drawRoundedRect(context, currentX, currentY, CARD_WIDTH, CARD_HEIGHT, Theme.BG_PANEL_GLASS, Theme.BORDER_SUBTLE);

            // Left vertical accent stripe
            context.fill(currentX, currentY + 2, currentX + 3, currentY + CARD_HEIGHT - 2, accentColor);

            // Avatar Head with outer hat layer (24px)
            AvatarWidget.drawHead(context, item.senderUsername, currentX + 8, currentY + 6, 24);

            // Title & Preview Text
            String title = tr.trimToWidth(item.title, CARD_WIDTH - 44);
            context.drawText(tr, title, currentX + 38, currentY + 6, Theme.TEXT_PRIMARY, false);

            String preview = tr.trimToWidth(item.preview, CARD_WIDTH - 44);
            context.drawText(tr, preview, currentX + 38, currentY + 19, Theme.TEXT_MUTED, false);

            // Countdown Progress Bar at Bottom
            float remainingRatio = Math.max(0f, Math.min(1.0f, (float) remaining / (float) item.durationMs));
            int barW = (int) ((CARD_WIDTH - 38) * remainingRatio);
            if (barW > 0) {
                context.fill(currentX + 38, currentY + CARD_HEIGHT - 4, currentX + 38 + barW, currentY + CARD_HEIGHT - 2, accentColor);
            }

            index++;
        }
    }

    public static boolean handleClick(double mouseX, double mouseY) {
        if (ACTIVE_NOTIFICATIONS.isEmpty()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return false;

        for (NotificationItem item : ACTIVE_NOTIFICATIONS) {
            if (item.containsPoint(mouseX, mouseY)) {
                ACTIVE_NOTIFICATIONS.remove(item);

                if (item.type == Type.DIRECT_MESSAGE || item.type == Type.FRIEND_ONLINE || item.type == Type.FRIEND_ACCEPTED) {
                    mc.setScreen(new SocialScreen(mc.currentScreen, item.senderUsername));
                } else if (item.type == Type.GROUP_MESSAGE) {
                    mc.setScreen(new SocialScreen(mc.currentScreen, null, item.groupId));
                } else if (item.type == Type.TRACK_REQUEST) {
                    mc.setScreen(new TrackerScreen(mc.currentScreen));
                } else if (item.type == Type.FRIEND_REQUEST) {
                    mc.setScreen(new SocialScreen(mc.currentScreen, null));
                }
                return true;
            }
        }
        return false;
    }
}
