package com.offlinefriends.client.ui.widgets;

import com.offlinefriends.client.ui.Anim;
import com.offlinefriends.client.ui.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * BadgeWidget
 * 
 * Draws status indicators, online dots, unread count pills, and delivery badges.
 */
public class BadgeWidget {

    /**
     * Draws an animated online/offline presence dot.
     */
    public static void renderStatusDot(DrawContext context, boolean isOnline, boolean isSingleplayer, int x, int y, int radius) {
        if (!isOnline) {
            context.fill(x - radius, y - radius, x + radius, y + radius, Theme.STATUS_OFFLINE);
            return;
        }

        int dotColor = isSingleplayer ? Theme.STATUS_AWAY : Theme.STATUS_ONLINE;

        // Subtle pulsing halo
        float pulse = Anim.getPulse(1.5f);
        int alpha = (int) (40 + 60 * pulse);
        int haloColor = (alpha << 24) | (dotColor & 0x00FFFFFF);

        context.fill(x - radius - 1, y - radius - 1, x + radius + 1, y + radius + 1, haloColor);
        context.fill(x - radius, y - radius, x + radius, y + radius, dotColor);
    }

    /**
     * Draws an unread count badge with bouncing animation.
     */
    public static void renderUnreadBadge(DrawContext context, TextRenderer tr, int count, int x, int y) {
        if (count <= 0) return;
        String text = count > 99 ? "99+" : String.valueOf(count);
        int textW = tr.getWidth(text);
        int badgeW = Math.max(14, textW + 6);
        int badgeH = 12;

        int badgeColor = Theme.getAccentPrimary();

        // Rounded pill shape
        context.fill(x, y + 1, x + badgeW, y + badgeH - 1, badgeColor);
        context.fill(x + 1, y, x + badgeW - 1, y + badgeH, badgeColor);

        // Centered white text
        context.drawCenteredTextWithShadow(tr, text, x + badgeW / 2, y + 2, 0xFFFFFFFF);
    }

    /**
     * Draws a message delivery status badge.
     * Statuses: "sending", "delivered", "queued", "failed"
     */
    public static void renderDeliveryStatus(DrawContext context, TextRenderer tr, String status, int x, int y) {
        if (status == null) return;

        switch (status.toLowerCase()) {
            case "sending": {
                context.drawTextWithShadow(tr, "○ sending...", x, y, Theme.TEXT_MUTED);
                break;
            }
            case "delivered": {
                context.drawTextWithShadow(tr, "✓✓ delivered", x, y, Theme.getCurrentAccent().text);
                break;
            }
            case "queued": {
                context.drawTextWithShadow(tr, "◷ queued", x, y, Theme.STATUS_AWAY);
                break;
            }
            case "failed": {
                context.drawTextWithShadow(tr, "✕ failed [Retry]", x, y, Theme.STATUS_ERROR);
                break;
            }
            default: {
                context.drawTextWithShadow(tr, status, x, y, Theme.TEXT_MUTED);
                break;
            }
        }
    }
}
