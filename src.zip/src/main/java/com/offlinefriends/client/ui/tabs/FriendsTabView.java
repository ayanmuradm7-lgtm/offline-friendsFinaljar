package com.offlinefriends.client.ui.tabs;

import com.offlinefriends.client.OfflineFriendsClient;
import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.client.ui.widgets.BadgeWidget;
import com.offlinefriends.client.ui.widgets.ScrollPane;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.social.SocialWebSocketClient;
import com.offlinefriends.util.ModLogger;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

/**
 * FriendsTabView
 * 
 * Dedicated, full-fidelity Friends Hub view:
 * - Prominent, unmissable "+ Add Friend" button pinned at top.
 * - Pending friend request cards with 1-tap Accept / Decline.
 * - Online and Offline friends sections with avatars, server info, and quick actions.
 * - 1-tap [Chat] and [Track] action buttons on each friend card.
 * - Touch-friendly: minimum 42px item height, swipe scroll, long-press context menu.
 * - Strictly under 350 lines.
 */
public class FriendsTabView {

    private int x, y, width, height;
    private final ScrollPane scrollPane;

    public interface Listener {
        void onOpenAddFriend();
        void onSelectFriend(String friendName);
        void onTrackFriend(String friendName);
    }

    private final Listener listener;
    private long pressStartTime = 0L;
    private double pressX = 0, pressY = 0;
    private String longPressedTarget = null;
    private boolean showContextMenu = false;

    public FriendsTabView(int x, int y, int width, int height, Listener listener) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.listener = listener;
        this.scrollPane = new ScrollPane(x, y + 42, width, height - 44, false);
    }

    public void setBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scrollPane.setBounds(x, y + 42, width, height - 44);
    }

    public boolean mouseClickedOverlay(double mx, double my) {
        if (showContextMenu) {
            handleContextMenuClick(mx, my);
            showContextMenu = false;
            return true;
        }
        return false;
    }

    public boolean mouseClickedContent(double mx, double my, int button) {
        // 1. Pinned Top Action Bar: "+ Add Friend" button
        int addBtnY = y + 4, addBtnH = 32;
        int addBtnW = Math.min(220, width - 16);
        int addBtnX = x + 8;
        if (mx >= addBtnX && mx <= addBtnX + addBtnW && my >= addBtnY && my <= addBtnY + addBtnH) {
            if (listener != null) listener.onOpenAddFriend();
            return true;
        }

        // 2. Delegate to ScrollPane content
        if (scrollPane.isMouseOver(mx, my)) {
            pressStartTime = System.currentTimeMillis();
            pressX = mx;
            pressY = my;
            int contentY = (int) (my - (y + 42) + scrollPane.getScrollOffset());
            handleItemClick(mx, contentY);
            scrollPane.mouseClicked(mx, my, button);
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double mx, double my, int button, double deltaX, double deltaY) {
        if (Math.abs(mx - pressX) > 5 || Math.abs(my - pressY) > 5) pressStartTime = 0L;
        return scrollPane.mouseDragged(mx, my, button, deltaX, deltaY);
    }

    public boolean mouseReleased(double mx, double my, int button) {
        pressStartTime = 0L;
        return scrollPane.mouseReleased(mx, my, button);
    }

    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        return scrollPane.mouseScrolled(mx, my, horizontalAmount, verticalAmount);
    }

    private void handleItemClick(double mx, int contentY) {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int itemY = 0;

        // Pending Requests
        if (!social.pendingIncomingRequests.isEmpty()) {
            itemY += 18;
            for (String reqUser : new ArrayList<>(social.pendingIncomingRequests)) {
                if (contentY >= itemY && contentY <= itemY + 40) {
                    int accX = x + width - 64, decX = x + width - 32;
                    if (mx >= accX && mx <= accX + 28) { social.sendFriendAccept(reqUser); return; }
                    if (mx >= decX && mx <= decX + 28) { social.sendFriendDecline(reqUser); return; }
                }
                itemY += 44;
            }
            itemY += 8;
        }

        // Empty state card click -> opens Add Friend
        if (social.friends.isEmpty() && social.pendingIncomingRequests.isEmpty()) {
            if (contentY >= itemY && contentY <= itemY + 70) {
                if (listener != null) listener.onOpenAddFriend();
                return;
            }
        }

        // Friend items
        List<SocialWebSocketClient.FriendInfo> all = getSortedFriends(social.friends.values());
        for (SocialWebSocketClient.FriendInfo f : all) {
            if (contentY >= itemY && contentY <= itemY + 44) {
                int chatBtnX = x + width - 96, trackBtnX = x + width - 46;
                if (mx >= chatBtnX && mx <= chatBtnX + 46) {
                    if (listener != null) listener.onSelectFriend(f.username());
                    return;
                }
                if (mx >= trackBtnX && mx <= trackBtnX + 40) {
                    if (listener != null) listener.onTrackFriend(f.username());
                    return;
                }
                this.longPressedTarget = f.username();
                if (listener != null) listener.onSelectFriend(f.username());
                return;
            }
            itemY += 48;
        }
    }

    private List<SocialWebSocketClient.FriendInfo> getSortedFriends(Collection<SocialWebSocketClient.FriendInfo> list) {
        List<SocialWebSocketClient.FriendInfo> res = new ArrayList<>(list);
        res.sort((a, b) -> {
            int c = Boolean.compare(b.online(), a.online());
            return c != 0 ? c : a.username().compareToIgnoreCase(b.username());
        });
        return res;
    }

    private void handleContextMenuClick(double mx, double my) {
        if (longPressedTarget == null) return;
        ModConfig cfg = ModConfig.getInstance();
        SocialWebSocketClient soc = SocialWebSocketClient.getInstance();
        int menuX = x + 30, menuY = y + 50, menuW = 130;

        if (mx >= menuX && mx <= menuX + menuW) {
            if (my >= menuY && my <= menuY + 22) {
                if (cfg.isFriendMuted(longPressedTarget)) cfg.unmuteFriend(longPressedTarget);
                else cfg.muteFriend(longPressedTarget);
            } else if (my >= menuY + 22 && my <= menuY + 44) {
                if (cfg.isUserBlocked(longPressedTarget)) cfg.unblockUser(longPressedTarget);
                else cfg.blockUser(longPressedTarget);
            } else if (my >= menuY + 44 && my <= menuY + 68) {
                soc.sendFriendRemove(longPressedTarget);
                if (listener != null) listener.onSelectFriend(null);
            }
        }
    }

    public void renderContent(DrawContext context, TextRenderer tr, int mouseX, int mouseY, String selectedFriend) {
        Theme.drawGlassPanel(context, x, y, width, height);

        // 1. Pinned Top Action Bar: "+ Add Friend" Button & Summary
        int addBtnY = y + 5, addBtnH = 30;
        int addBtnW = Math.min(200, width - 16);
        int addBtnX = x + 8;
        boolean addHov = mouseX >= addBtnX && mouseX <= addBtnX + addBtnW && mouseY >= addBtnY && mouseY <= addBtnY + addBtnH;

        Theme.drawRoundedRect(context, addBtnX, addBtnY, addBtnW, addBtnH, addHov ? Theme.getCurrentAccent().text : Theme.getAccentPrimary(), Theme.BORDER_HIGHLIGHT);
        context.drawCenteredTextWithShadow(tr, "+ Add Friend", addBtnX + addBtnW / 2, addBtnY + 11, 0xFFFFFFFF);

        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int onlineCount = 0;
        for (SocialWebSocketClient.FriendInfo f : social.friends.values()) if (f.online()) onlineCount++;
        String summary = String.format("%d Online  •  %d Total", onlineCount, social.friends.size());
        context.drawTextWithShadow(tr, summary, addBtnX + addBtnW + 12, addBtnY + 11, Theme.TEXT_SECONDARY);

        // Long-press detection
        if (pressStartTime > 0L && (System.currentTimeMillis() - pressStartTime) >= 500L) {
            showContextMenu = true;
            pressStartTime = 0L;
        }

        // 2. Render Scrollable Friends Content
        scrollPane.setBounds(x, y + 42, width, height - 44);
        scrollPane.beginScissor(context);
        int renderY = y + 42 - (int) scrollPane.getScrollOffset();
        int totalContentHeight = renderItems(context, tr, renderY, mouseX, mouseY, selectedFriend);
        scrollPane.endScissor(context);

        scrollPane.setContentHeight(totalContentHeight);
        scrollPane.renderScrollbar(context);
    }

    public void renderOverlay(DrawContext context, TextRenderer tr) {
        if (showContextMenu && longPressedTarget != null) {
            int menuX = x + 30, menuY = y + 50, menuW = 130, menuH = 68;
            Theme.drawRoundedRect(context, menuX, menuY, menuW, menuH, Theme.BG_DARK_GLASS, Theme.BORDER_HIGHLIGHT);
            ModConfig config = ModConfig.getInstance();
            context.drawTextWithShadow(tr, config.isFriendMuted(longPressedTarget) ? "Unmute" : "Mute Notifications", menuX + 8, menuY + 8, Theme.TEXT_PRIMARY);
            context.drawTextWithShadow(tr, config.isUserBlocked(longPressedTarget) ? "Unblock" : "Block User", menuX + 8, menuY + 28, Theme.STATUS_AWAY);
            context.drawTextWithShadow(tr, "Remove Friend", menuX + 8, menuY + 48, Theme.STATUS_ERROR);
        }
    }

    private int renderItems(DrawContext context, TextRenderer tr, int startY, int mouseX, int mouseY, String selectedFriend) {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int curY = startY;

        // Pending Requests Section
        if (!social.pendingIncomingRequests.isEmpty()) {
            context.drawTextWithShadow(tr, "Pending Requests (" + social.pendingIncomingRequests.size() + ")", x + 10, curY + 2, Theme.STATUS_AWAY);
            curY += 16;
            for (String reqUser : new ArrayList<>(social.pendingIncomingRequests)) {
                Theme.drawSolidCard(context, x + 8, curY, width - 16, 40, false);
                AvatarWidget.render(context, reqUser, x + 14, curY + 8, 24);
                context.drawTextWithShadow(tr, reqUser, x + 44, curY + 10, Theme.TEXT_PRIMARY);
                context.drawText(tr, "Sent you a friend request", x + 44, curY + 24, Theme.TEXT_MUTED, false);

                int accX = x + width - 64, decX = x + width - 32;
                context.fill(accX, curY + 8, accX + 28, curY + 32, Theme.STATUS_ONLINE);
                context.drawCenteredTextWithShadow(tr, "Accept", accX + 14, curY + 15, 0xFFFFFFFF);
                context.fill(decX, curY + 8, decX + 28, curY + 32, Theme.STATUS_ERROR);
                context.drawCenteredTextWithShadow(tr, "Decline", decX + 14, curY + 15, 0xFFFFFFFF);
                curY += 46;
            }
            curY += 8;
        }

        // Empty state when no friends
        if (social.friends.isEmpty() && social.pendingIncomingRequests.isEmpty()) {
            Theme.drawSolidCard(context, x + 8, curY, width - 16, 70, false);
            context.drawCenteredTextWithShadow(tr, "No friends added yet", x + width / 2, curY + 16, Theme.TEXT_PRIMARY);
            context.drawCenteredTextWithShadow(tr, "Tap '+ Add Friend' to connect with players across servers!", x + width / 2, curY + 34, Theme.TEXT_SECONDARY);
            context.drawCenteredTextWithShadow(tr, "100% Cracked & Offline Compatible", x + width / 2, curY + 50, Theme.getAccentText());
            curY += 78;
        }

        // Split Online & Offline
        List<SocialWebSocketClient.FriendInfo> online = new ArrayList<>(), offline = new ArrayList<>();
        for (SocialWebSocketClient.FriendInfo f : social.friends.values()) {
            if (f.online()) online.add(f); else offline.add(f);
        }
        online.sort((a, b) -> a.username().compareToIgnoreCase(b.username()));
        offline.sort((a, b) -> a.username().compareToIgnoreCase(b.username()));

        if (!online.isEmpty()) {
            context.drawTextWithShadow(tr, "Online Friends (" + online.size() + ")", x + 10, curY + 2, Theme.STATUS_ONLINE);
            curY += 16;
            for (SocialWebSocketClient.FriendInfo f : online) {
                curY = renderFriendCard(context, tr, curY, mouseX, mouseY, f, selectedFriend);
            }
            curY += 8;
        }

        if (!offline.isEmpty()) {
            context.drawTextWithShadow(tr, "Offline Friends (" + offline.size() + ")", x + 10, curY + 2, Theme.TEXT_MUTED);
            curY += 16;
            for (SocialWebSocketClient.FriendInfo f : offline) {
                curY = renderFriendCard(context, tr, curY, mouseX, mouseY, f, selectedFriend);
            }
        }

        return Math.max(0, curY - startY);
    }

    private int renderFriendCard(DrawContext context, TextRenderer tr, int curY, int mouseX, int mouseY,
                                 SocialWebSocketClient.FriendInfo f, String selectedFriend) {
        boolean isHover = mouseX >= x + 8 && mouseX <= x + width - 8 && mouseY >= curY && mouseY <= curY + 44;
        Theme.drawSolidCard(context, x + 8, curY, width - 16, 44, isHover);

        // Avatar
        AvatarWidget.render(context, f.username(), x + 14, curY + 10, 24);

        // Online Presence Dot
        boolean isSp = f.online() && (f.server() == null || f.server().isEmpty() || f.server().equalsIgnoreCase("singleplayer"));
        BadgeWidget.renderStatusDot(context, f.online(), isSp, x + 36, curY + 32, 3);

        // Username
        context.drawTextWithShadow(tr, f.username(), x + 44, curY + 9, Theme.TEXT_TITLE);

        // Status Subtext
        String subText = f.online() ? (f.server() != null && !f.server().isEmpty() ? "Playing on " + f.server() : "Playing Singleplayer") : "Offline";
        context.drawText(tr, subText, x + 44, curY + 23, f.online() ? Theme.STATUS_ONLINE : Theme.TEXT_MUTED, false);

        // Quick Actions: [ Chat ] and [ Track ]
        int chatBtnX = x + width - 96, trackBtnX = x + width - 46;
        boolean chatHov = mouseX >= chatBtnX && mouseX <= chatBtnX + 46 && mouseY >= curY + 10 && mouseY <= curY + 34;
        boolean trackHov = mouseX >= trackBtnX && mouseX <= trackBtnX + 40 && mouseY >= curY + 10 && mouseY <= curY + 34;

        Theme.drawRoundedRect(context, chatBtnX, curY + 10, 46, 24, chatHov ? Theme.getCurrentAccent().text : Theme.getAccentPrimary(), Theme.BORDER_CARD);
        context.drawCenteredTextWithShadow(tr, "Chat", chatBtnX + 23, curY + 18, 0xFFFFFFFF);

        if (f.online()) {
            Theme.drawRoundedRect(context, trackBtnX, curY + 10, 40, 24, trackHov ? 0xFF059669 : 0xFF10B981, Theme.BORDER_CARD);
            context.drawCenteredTextWithShadow(tr, "Track", trackBtnX + 20, curY + 18, 0xFFFFFFFF);
        }

        return curY + 48;
    }
}
