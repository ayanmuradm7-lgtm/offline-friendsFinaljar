package com.offlinefriends.client.ui.tabs;

import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.client.ui.widgets.BadgeWidget;
import com.offlinefriends.client.ui.widgets.ChatBubbleWidget;
import com.offlinefriends.client.ui.widgets.ScrollPane;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.social.ChatHistoryManager;
import com.offlinefriends.social.GroupManager;
import com.offlinefriends.social.SocialWebSocketClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * ChatPanelView
 * 
 * Renders the right-hand chat panel:
 * - Header bar with Avatar, Name, presence status, and playing-on server.
 * - Inverted ScrollPane for message history (newest anchored at bottom).
 * - Outgoing messages in active accent color; incoming messages in glass with avatar.
 * - Floating "↓ Jump to newest" pill when scrolled up into history.
 * - Touch friendly with hitboxes for [Retry] failed DMs.
 */
public class ChatPanelView {

    private int x, y, width, height;
    private final ScrollPane scrollPane;
    private final List<ChatBubbleWidget.RetryHitbox> retryHits = new ArrayList<>();

    public interface ActionHandler {
        void onRetryMessage(String friendName, String text);
        void onOpenGroupDetails();
        void onRenameGroup();
        void onLeaveGroup();
    }

    private final ActionHandler actionHandler;

    public ChatPanelView(int x, int y, int width, int height, ActionHandler actionHandler) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.actionHandler = actionHandler;
        // Inverted ScrollPane: offset 0 = newest at bottom
        this.scrollPane = new ScrollPane(x, y + 36, width, height - 74, true);
    }

    public void setBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scrollPane.setBounds(x, y + 36, width, height - 74);
    }

    public void scrollToBottom() {
        this.scrollPane.scrollToBottom();
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }

    public boolean isMouseOver(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }

    public boolean mouseClickedOverlay(double mx, double my) {
        // Floating "Jump to Newest" Pill Click
        if (!scrollPane.isAtBottom()) {
            int pillW = 100;
            int pillX = x + width / 2 - pillW / 2;
            int pillY = y + height - 52;
            if (mx >= pillX && mx <= pillX + pillW && my >= pillY && my <= pillY + 18) {
                scrollToBottom();
                return true;
            }
        }
        return false;
    }

    public boolean mouseClickedContent(double mx, double my, int button, String selectedFriend, String selectedGroupId) {
        // 1. Check Retry Hitboxes
        for (ChatBubbleWidget.RetryHitbox hit : retryHits) {
            if (hit.contains(mx, my)) {
                if (actionHandler != null) {
                    actionHandler.onRetryMessage(hit.recipient, hit.text);
                }
                return true;
            }
        }

        // 2. Check Header Action Buttons (Rename, Details, Leave)
        if (selectedGroupId != null && my >= y + 6 && my <= y + 26) {
            if (mx >= x + width - 65 && mx <= x + width - 10) {
                if (actionHandler != null) actionHandler.onLeaveGroup();
                return true;
            } else if (mx >= x + width - 120 && mx <= x + width - 70) {
                if (actionHandler != null) actionHandler.onRenameGroup();
                return true;
            }
        }

        // 3. Delegate to scrollPane
        return scrollPane.mouseClicked(mx, my, button);
    }

    public boolean mouseClicked(double mx, double my, int button, String selectedFriend, String selectedGroupId) {
        if (mouseClickedOverlay(mx, my)) return true;
        return mouseClickedContent(mx, my, button, selectedFriend, selectedGroupId);
    }

    public boolean mouseDragged(double mx, double my, int button, double deltaX, double deltaY) {
        return scrollPane.mouseDragged(mx, my, button, deltaX, deltaY);
    }

    public boolean mouseReleased(double mx, double my, int button) {
        return scrollPane.mouseReleased(mx, my, button);
    }

    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        return scrollPane.mouseScrolled(mx, my, horizontalAmount, verticalAmount);
    }

    /**
     * Renders background panel, header, and chat history bubbles (UNDER widgets).
     */
    public void renderContent(DrawContext context, TextRenderer tr, int mouseX, int mouseY, String selectedFriend, String selectedGroupId) {
        // Draw Main Glass Backdrop
        Theme.drawGlassPanel(context, x, y, width, height);

        if (selectedFriend == null && selectedGroupId == null) {
            renderEmptyState(context, tr);
            return;
        }

        // 1. Render Header Bar
        renderHeader(context, tr, selectedFriend, selectedGroupId);

        // 2. Render Messages in ScrollPane
        retryHits.clear();
        scrollPane.beginScissor(context);
        int totalContentHeight = 0;

        if (selectedFriend != null) {
            totalContentHeight = renderDmMessages(context, tr, selectedFriend);
        } else {
            totalContentHeight = renderGroupMessages(context, tr, selectedGroupId);
        }

        scrollPane.endScissor(context);
        scrollPane.setContentHeight(totalContentHeight);
        scrollPane.renderScrollbar(context);
    }

    /**
     * Renders overlays (jump-to-newest floating pill) on TOP of widgets.
     */
    public void renderOverlay(DrawContext context, TextRenderer tr) {
        if (!scrollPane.isAtBottom()) {
            renderJumpToNewestPill(context, tr);
        }
    }

    public void render(DrawContext context, TextRenderer tr, int mouseX, int mouseY, String selectedFriend, String selectedGroupId) {
        renderContent(context, tr, mouseX, mouseY, selectedFriend, selectedGroupId);
        renderOverlay(context, tr);
    }

    private void renderEmptyState(DrawContext context, TextRenderer tr) {
        context.drawCenteredTextWithShadow(tr, "Offline Friends v1.3.5", x + width / 2, y + height / 2 - 28, Theme.getAccentText());
        context.drawCenteredTextWithShadow(tr, "Select a conversation or friend to chat", x + width / 2, y + height / 2 - 12, Theme.TEXT_MUTED);
        context.drawCenteredTextWithShadow(tr, "100% Cracked & Offline Compatible", x + width / 2, y + height / 2 + 4, Theme.TEXT_DIM);
    }

    private void renderHeader(DrawContext context, TextRenderer tr, String selectedFriend, String selectedGroupId) {
        int headerH = 34;
        context.fill(x + 1, y + 1, x + width - 1, y + headerH, Theme.BG_CARD);
        context.fill(x + 1, y + headerH, x + width - 1, y + headerH + 1, Theme.BORDER_SUBTLE);

        if (selectedFriend != null) {
            // Friend Avatar (22x22)
            AvatarWidget.render(context, selectedFriend, x + 8, y + 6, 22);

            // Friend Name
            context.drawTextWithShadow(tr, selectedFriend, x + 36, y + 7, Theme.TEXT_TITLE);

            // Presence / Server Playing Status
            SocialWebSocketClient social = SocialWebSocketClient.getInstance();
            SocialWebSocketClient.FriendInfo friend = social.friends.get(selectedFriend.toLowerCase());
            boolean online = friend != null && friend.online();
            boolean isSp = online && (friend.server() == null || friend.server().isEmpty() || friend.server().equalsIgnoreCase("singleplayer"));

            BadgeWidget.renderStatusDot(context, online, isSp, x + 40 + tr.getWidth(selectedFriend) + 8, y + 11, 3);

            String statusText;
            if (online) {
                if (friend.server() != null && !friend.server().isEmpty()) {
                    statusText = "Playing on " + friend.server();
                } else {
                    statusText = "Online (Singleplayer / Local)";
                }
            } else {
                statusText = "Offline";
            }
            context.drawText(tr, statusText, x + 36, y + 20, Theme.TEXT_SECONDARY, false);

        } else if (selectedGroupId != null) {
            GroupManager.GroupInfo group = GroupManager.getInstance().getGroup(selectedGroupId);
            String groupName = group != null ? group.getName() : "Group Chat";

            context.fill(x + 8, y + 6, x + 30, y + 28, Theme.BG_CARD_HOVER);
            context.drawCenteredTextWithShadow(tr, "🛡", x + 19, y + 11, Theme.getAccentText());

            context.drawTextWithShadow(tr, groupName, x + 36, y + 7, Theme.TEXT_TITLE);
            String memberCount = (group != null ? (group.getMembers().size() + 1) : 1) + " members";
            context.drawText(tr, memberCount, x + 36, y + 20, Theme.TEXT_SECONDARY, false);

            // Rename button [x + width - 120 .. x + width - 70]
            int renX = x + width - 120;
            context.fill(renX, y + 8, renX + 48, y + 26, Theme.BG_CARD_HOVER);
            context.drawCenteredTextWithShadow(tr, "Rename", renX + 24, y + 12, Theme.TEXT_SECONDARY);

            // Leave button [x + width - 65 .. x + width - 10]
            int leaveX = x + width - 65;
            context.fill(leaveX, y + 8, leaveX + 55, y + 26, 0x33EF4444);
            context.drawCenteredTextWithShadow(tr, "Leave", leaveX + 27, y + 12, Theme.STATUS_ERROR);
        }
    }

    private int renderDmMessages(DrawContext context, TextRenderer tr, String friendName) {
        List<ChatHistoryManager.DirectMessage> messages = ChatHistoryManager.getInstance().getConversation(friendName);
        if (messages == null || messages.isEmpty()) {
            context.drawCenteredTextWithShadow(tr, "No messages yet. Send a message below!", x + width / 2, y + height / 2, Theme.TEXT_MUTED);
            return 0;
        }

        int maxBubbleW = Math.max(100, Math.min(260, width - 60));
        int totalH = 8;
        for (ChatHistoryManager.DirectMessage msg : messages) {
            totalH += ChatBubbleWidget.getDmBubbleHeight(tr, msg, maxBubbleW) + 6;
        }

        // Draw messages top-down calculated against bottom anchor
        int viewportH = height - 74;
        int renderY = (y + 36 + viewportH - totalH) + (int) scrollPane.getScrollOffset();

        for (ChatHistoryManager.DirectMessage msg : messages) {
            int bubbleH = ChatBubbleWidget.getDmBubbleHeight(tr, msg, maxBubbleW);
            // Viewport culling
            if (renderY + bubbleH >= (y + 36) && renderY <= (y + height - 38)) {
                ChatBubbleWidget.renderDmBubble(context, tr, msg, x, width, renderY, friendName, retryHits);
            }
            renderY += bubbleH + 6;
        }
        return totalH;
    }

    private int renderGroupMessages(DrawContext context, TextRenderer tr, String groupId) {
        List<GroupManager.GroupMessage> messages = GroupManager.getInstance().getMessages(groupId);
        if (messages == null || messages.isEmpty()) {
            context.drawCenteredTextWithShadow(tr, "No messages yet in this group. Say hi!", x + width / 2, y + height / 2, Theme.TEXT_MUTED);
            return 0;
        }

        int maxBubbleW = Math.max(100, Math.min(260, width - 60));
        int totalH = 8;
        for (GroupManager.GroupMessage msg : messages) {
            totalH += ChatBubbleWidget.getGroupBubbleHeight(tr, msg, maxBubbleW) + 6;
        }

        int viewportH = height - 74;
        int renderY = (y + 36 + viewportH - totalH) + (int) scrollPane.getScrollOffset();

        for (GroupManager.GroupMessage msg : messages) {
            int bubbleH = ChatBubbleWidget.getGroupBubbleHeight(tr, msg, maxBubbleW);
            if (renderY + bubbleH >= (y + 36) && renderY <= (y + height - 38)) {
                ChatBubbleWidget.renderGroupBubble(context, tr, msg, x, width, renderY, retryHits);
            }
            renderY += bubbleH + 6;
        }
        return totalH;
    }

    private void renderJumpToNewestPill(DrawContext context, TextRenderer tr) {
        int pillW = 100;
        int pillH = 16;
        int pillX = x + width / 2 - pillW / 2;
        int pillY = y + height - 52;

        context.fill(pillX, pillY, pillX + pillW, pillY + pillH, Theme.BG_DARK_GLASS);
        context.drawStrokedRectangle(pillX, pillY, pillW, pillH, Theme.getAccentPrimary());
        context.drawCenteredTextWithShadow(tr, "↓ Jump to newest", pillX + pillW / 2, pillY + 4, Theme.getAccentText());
    }
}
