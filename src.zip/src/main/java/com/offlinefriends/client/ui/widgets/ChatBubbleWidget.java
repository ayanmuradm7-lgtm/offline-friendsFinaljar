package com.offlinefriends.client.ui.widgets;

import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.social.ChatHistoryManager;
import com.offlinefriends.social.GroupManager;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * ChatBubbleWidget
 * 
 * Renders glass-styled message bubbles:
 * - Mine (outgoing): right-aligned, styled in accent color.
 * - Theirs (incoming): left-aligned, dark glass with sender avatar.
 * - Word wrapping, delivery badges, retry button, and grouped timestamps.
 */
public class ChatBubbleWidget {

    private static final SimpleDateFormat TIME_FMT = new SimpleDateFormat("HH:mm");
    private static final Date REUSABLE_DATE = new Date();

    private static synchronized String formatTime(long timestamp) {
        REUSABLE_DATE.setTime(timestamp);
        return TIME_FMT.format(REUSABLE_DATE);
    }

    public static class RetryHitbox {
        public int x1, y1, x2, y2;
        public String msgId;
        public String recipient;
        public String text;

        public RetryHitbox(int x1, int y1, int x2, int y2, String msgId, String recipient, String text) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.msgId = msgId;
            this.recipient = recipient;
            this.text = text;
        }

        public boolean contains(double mx, double my) {
            return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
        }
    }

    /**
     * Calculates height of a DM bubble.
     */
    public static int getDmBubbleHeight(TextRenderer tr, ChatHistoryManager.DirectMessage msg, int maxBubbleW) {
        List<OrderedText> lines = tr.wrapLines(Text.literal(msg.getText()), maxBubbleW);
        int textH = Math.max(1, lines.size()) * 10;
        return textH + 16; // 8px top/bottom padding + 8px status/time
    }

    /**
     * Calculates height of a Group bubble.
     */
    public static int getGroupBubbleHeight(TextRenderer tr, GroupManager.GroupMessage msg, int maxBubbleW) {
        List<OrderedText> lines = tr.wrapLines(Text.literal(msg.getText()), maxBubbleW);
        int textH = Math.max(1, lines.size()) * 10;
        String myName = com.offlinefriends.config.ModConfig.getInstance().getEffectiveUsername();
        boolean mine = msg.getSender() != null && msg.getSender().equalsIgnoreCase(myName);
        int headerH = mine ? 0 : 10;
        return textH + headerH + 16;
    }

    /**
     * Renders a DM message bubble.
     */
    public static void renderDmBubble(DrawContext context, TextRenderer tr, ChatHistoryManager.DirectMessage msg,
                                      int panelX, int panelW, int bubbleY, String friendName, List<RetryHitbox> retryHits) {
        String myName = com.offlinefriends.config.ModConfig.getInstance().getEffectiveUsername();
        boolean mine = msg.getFrom() != null && msg.getFrom().equalsIgnoreCase(myName);
        int maxBubbleW = Math.max(100, Math.min(260, panelW - 60));

        List<OrderedText> lines = tr.wrapLines(Text.literal(msg.getText()), maxBubbleW);
        int maxLineW = 0;
        for (OrderedText line : lines) {
            maxLineW = Math.max(maxLineW, tr.getWidth(line));
        }

        int bubbleW = Math.max(70, Math.min(maxBubbleW, maxLineW + 16));
        int textH = Math.max(1, lines.size()) * 10;
        int bubbleH = textH + 16;

        int bubbleX = mine ? (panelX + panelW - bubbleW - 14) : (panelX + 34);

        // Render Avatar for incoming message on left side
        if (!mine) {
            AvatarWidget.render(context, friendName, panelX + 12, bubbleY + 2, 18);
        }

        // Background styling
        if (mine) {
            int bg = Theme.getCurrentAccent().dark;
            int border = Theme.getAccentPrimary();
            Theme.drawRoundedRect(context, bubbleX, bubbleY, bubbleW, bubbleH, bg, border);
        } else {
            int bg = Theme.BG_CARD;
            int border = Theme.BORDER_CARD;
            Theme.drawRoundedRect(context, bubbleX, bubbleY, bubbleW, bubbleH, bg, border);
        }

        // Draw Message Text lines
        int lineY = bubbleY + 5;
        for (OrderedText line : lines) {
            context.drawText(tr, line, bubbleX + 8, lineY, Theme.TEXT_PRIMARY, false);
            lineY += 10;
        }

        // Draw Timestamp and Status at bottom
        String timeStr = formatTime(msg.getTimestamp());
        int metaY = bubbleY + bubbleH - 9;

        if (mine) {
            // Outgoing status ticks
            BadgeWidget.renderDeliveryStatus(context, tr, msg.getStatus(), bubbleX + 8, metaY);
            int timeW = tr.getWidth(timeStr);
            context.drawText(tr, timeStr, bubbleX + bubbleW - timeW - 6, metaY, Theme.TEXT_MUTED, false);

            if ("failed".equalsIgnoreCase(msg.getStatus()) && retryHits != null) {
                // Register retry hitbox over the status badge
                retryHits.add(new RetryHitbox(bubbleX + 8, metaY - 2, bubbleX + 70, metaY + 9, msg.getId(), friendName, msg.getText()));
            }
        } else {
            // Incoming time
            context.drawText(tr, timeStr, bubbleX + bubbleW - tr.getWidth(timeStr) - 6, metaY, Theme.TEXT_MUTED, false);
        }
    }

    /**
     * Renders a Group message bubble.
     */
    public static void renderGroupBubble(DrawContext context, TextRenderer tr, GroupManager.GroupMessage msg,
                                         int panelX, int panelW, int bubbleY, List<RetryHitbox> retryHits) {
        String myName = com.offlinefriends.config.ModConfig.getInstance().getEffectiveUsername();
        boolean mine = msg.getSender() != null && msg.getSender().equalsIgnoreCase(myName);
        int maxBubbleW = Math.max(100, Math.min(260, panelW - 60));

        List<OrderedText> lines = tr.wrapLines(Text.literal(msg.getText()), maxBubbleW);
        int maxLineW = 0;
        for (OrderedText line : lines) {
            maxLineW = Math.max(maxLineW, tr.getWidth(line));
        }

        int headerH = mine ? 0 : 10;
        int bubbleW = Math.max(80, Math.min(maxBubbleW, maxLineW + 16));
        int textH = Math.max(1, lines.size()) * 10;
        int bubbleH = textH + headerH + 16;

        int bubbleX = mine ? (panelX + panelW - bubbleW - 14) : (panelX + 34);

        // Avatar for incoming group message
        if (!mine) {
            AvatarWidget.render(context, msg.getSender(), panelX + 12, bubbleY + 2, 18);
        }

        // Background
        if (mine) {
            int bg = Theme.getCurrentAccent().dark;
            int border = Theme.getAccentPrimary();
            Theme.drawRoundedRect(context, bubbleX, bubbleY, bubbleW, bubbleH, bg, border);
        } else {
            int bg = Theme.BG_CARD;
            int border = Theme.BORDER_CARD;
            Theme.drawRoundedRect(context, bubbleX, bubbleY, bubbleW, bubbleH, bg, border);
        }

        int lineY = bubbleY + 5;
        // Sender name for incoming group messages
        if (!mine) {
            context.drawTextWithShadow(tr, msg.getSender(), bubbleX + 8, lineY, Theme.getAccentText());
            lineY += 10;
        }

        // Draw Message Text
        for (OrderedText line : lines) {
            context.drawText(tr, line, bubbleX + 8, lineY, Theme.TEXT_PRIMARY, false);
            lineY += 10;
        }

        // Bottom timestamp & delivery summary
        String timeStr = formatTime(msg.getTimestamp());
        int metaY = bubbleY + bubbleH - 9;

        if (mine) {
            int deliveredCount = 0;
            int total = msg.getRecipientStatuses() != null ? msg.getRecipientStatuses().size() : 0;
            if (msg.getRecipientStatuses() != null) {
                for (String st : msg.getRecipientStatuses().values()) {
                    if ("delivered".equalsIgnoreCase(st)) deliveredCount++;
                }
            }
            String status = total > 0 && deliveredCount >= total ? "✓✓ " + total + "/" + total : "○ " + deliveredCount + "/" + total;
            context.drawText(tr, status, bubbleX + 8, metaY, deliveredCount >= total ? Theme.getAccentText() : Theme.TEXT_MUTED, false);

            int timeW = tr.getWidth(timeStr);
            context.drawText(tr, timeStr, bubbleX + bubbleW - timeW - 6, metaY, Theme.TEXT_MUTED, false);
        } else {
            context.drawText(tr, timeStr, bubbleX + bubbleW - tr.getWidth(timeStr) - 6, metaY, Theme.TEXT_MUTED, false);
        }
    }
}
