package com.offlinefriends.client.ui;

import com.offlinefriends.config.ModConfig;

/**
 * Anim
 * 
 * Time-based animation helpers using System.nanoTime().
 * Never relies on frame counts.
 * Automatically disabled when "Reduce animations" is enabled in settings.
 */
public class Anim {

    /**
     * Normalized progress (0.0f to 1.0f) based on start time and duration in ms.
     */
    public static float progress(long startNano, long durationMs) {
        if (ModConfig.getInstance().isReduceAnimations()) {
            return 1.0f;
        }
        long elapsedNano = System.nanoTime() - startNano;
        float p = (float) elapsedNano / (durationMs * 1_000_000f);
        return Math.max(0.0f, Math.min(1.0f, p));
    }

    /**
     * Ease-Out Cubic: Fast start, smooth deceleration.
     */
    public static float easeOutCubic(float t) {
        if (ModConfig.getInstance().isReduceAnimations()) return 1.0f;
        t = Math.max(0.0f, Math.min(1.0f, t));
        float inv = 1.0f - t;
        return 1.0f - (inv * inv * inv);
    }

    /**
     * Ease-In-Out Quad: Smooth start and deceleration.
     */
    public static float easeInOutQuad(float t) {
        if (ModConfig.getInstance().isReduceAnimations()) return 1.0f;
        t = Math.max(0.0f, Math.min(1.0f, t));
        return t < 0.5f ? 2.0f * t * t : 1.0f - (float) Math.pow(-2.0f * t + 2.0f, 2) / 2.0f;
    }

    /**
     * Continuous sinusoidal pulse between 0.0f and 1.0f.
     * Speed in cycles per second.
     */
    public static float getPulse(float cyclesPerSecond) {
        if (ModConfig.getInstance().isReduceAnimations()) return 0.8f;
        double sec = (double) System.nanoTime() / 1_000_000_000.0;
        double sin = Math.sin(sec * Math.PI * 2.0 * cyclesPerSecond);
        return (float) ((sin + 1.0) / 2.0);
    }

    /**
     * Bouncing scale factor for unread badges and alerts.
     */
    public static float getBounce(float cyclesPerSecond, float minScale, float maxScale) {
        if (ModConfig.getInstance().isReduceAnimations()) return 1.0f;
        float pulse = getPulse(cyclesPerSecond);
        return minScale + (maxScale - minScale) * pulse;
    }

    /**
     * Interpolates ARGB colors smoothly.
     */
    public static int lerpColor(int colorA, int colorB, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int aA = (colorA >> 24) & 0xFF;
        int rA = (colorA >> 16) & 0xFF;
        int gA = (colorA >> 8) & 0xFF;
        int bA = colorA & 0xFF;

        int aB = (colorB >> 24) & 0xFF;
        int rB = (colorB >> 16) & 0xFF;
        int gB = (colorB >> 8) & 0xFF;
        int bB = colorB & 0xFF;

        int a = (int) (aA + (aB - aA) * t);
        int r = (int) (rA + (rB - rA) * t);
        int g = (int) (gA + (gB - gA) * t);
        int b = (int) (bA + (bB - bA) * t);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
