package com.offlinefriends.client.ui.tabs;

/**
 * LeftRailTab
 * 
 * Represents primary navigation tabs with clean, universal glyphs that
 * are 100% supported in Minecraft's default font on Android / Mobile.
 */
public enum LeftRailTab {
    FRIENDS("★", "Friends", "Friends & Requests"),
    CHATS("✉", "Chats", "Direct Messages"),
    GROUPS("◆", "Groups", "Group Management"),
    TRACKER("◎", "Track", "Player Compass Tracker"),
    HOSTING("⌂", "Host", "Local P2P Hosting"),
    SETTINGS("⚙", "Config", "Settings & Accent");

    public final String icon;
    public final String label;
    public final String title;

    LeftRailTab(String icon, String label, String title) {
        this.icon = icon;
        this.label = label;
        this.title = title;
    }
}
