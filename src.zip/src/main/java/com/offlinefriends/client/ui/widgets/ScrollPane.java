package com.offlinefriends.client.ui.widgets;

import com.offlinefriends.client.ui.Theme;
import net.minecraft.client.gui.DrawContext;

/**
 * ScrollPane
 * 
 * Touch-friendly scroll container supporting:
 * - Touch drag & swipe scrolling (optimized for mobile touchscreens).
 * - Mouse wheel scrolling.
 * - Viewport clipping via DrawContext.enableScissor().
 * - Touch drag velocity & smooth damping.
 * - Slim translucent scrollbar.
 */
public class ScrollPane {

    private int x, y, width, height;
    private int contentHeight = 0;
    private float scrollOffset = 0f; // 0 = top or bottom depending on invert
    private boolean inverted = false; // true = chat style (0 = newest at bottom)

    // Touch Dragging State
    private boolean isDragging = false;
    private double lastDragY = 0;
    private float velocity = 0f;
    private long lastDragTime = 0L;

    public ScrollPane(int x, int y, int width, int height, boolean inverted) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.inverted = inverted;
    }

    public void setBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setContentHeight(int contentHeight) {
        this.contentHeight = contentHeight;
        clampScroll();
    }

    public int getMaxScroll() {
        return Math.max(0, contentHeight - height);
    }

    public float getScrollOffset() {
        return scrollOffset;
    }

    public void setScrollOffset(float offset) {
        this.scrollOffset = offset;
        clampScroll();
    }

    public void scrollToBottom() {
        if (inverted) {
            this.scrollOffset = 0f;
        } else {
            this.scrollOffset = getMaxScroll();
        }
    }

    public boolean isAtBottom() {
        if (inverted) {
            return scrollOffset <= 5f;
        } else {
            return scrollOffset >= (getMaxScroll() - 5f);
        }
    }

    private void clampScroll() {
        int max = getMaxScroll();
        if (scrollOffset < 0f) scrollOffset = 0f;
        if (scrollOffset > max) scrollOffset = max;
    }

    public boolean isMouseOver(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }

    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        if (isMouseOver(mx, my)) {
            // Scroll step (24px per notch)
            float delta = (float) (verticalAmount * 24.0);
            if (inverted) {
                // Inverted: scrolling down (negative verticalAmount) moves towards bottom (0)
                scrollOffset += delta;
            } else {
                scrollOffset -= delta;
            }
            clampScroll();
            return true;
        }
        return false;
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (isMouseOver(mx, my)) {
            isDragging = true;
            lastDragY = my;
            lastDragTime = System.currentTimeMillis();
            velocity = 0f;
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double mx, double my, int button, double deltaX, double deltaY) {
        if (isDragging) {
            double dy = my - lastDragY;
            lastDragY = my;

            long now = System.currentTimeMillis();
            long dt = Math.max(1, now - lastDragTime);
            lastDragTime = now;

            velocity = (float) (dy / dt * 16.0);

            if (inverted) {
                scrollOffset += (float) dy;
            } else {
                scrollOffset -= (float) dy;
            }
            clampScroll();
            return true;
        }
        return false;
    }

    public boolean mouseReleased(double mx, double my, int button) {
        if (isDragging) {
            isDragging = false;
            return true;
        }
        return false;
    }

    /**
     * Call before rendering children to set clipping region.
     */
    public void beginScissor(DrawContext context) {
        context.enableScissor(x, y, x + width, y + height);
    }

    /**
     * Call after rendering children to restore clipping.
     */
    public void endScissor(DrawContext context) {
        context.disableScissor();
    }

    /**
     * Renders slim glass scrollbar if content exceeds viewport.
     */
    public void renderScrollbar(DrawContext context) {
        int max = getMaxScroll();
        if (max <= 0 || height <= 0) return;

        int barX = x + width - 4;
        int barTrackH = height - 4;

        float ratio = (float) height / (float) contentHeight;
        int thumbH = Math.max(16, (int) (barTrackH * ratio));

        float scrollRatio = scrollOffset / (float) max;
        if (inverted) {
            // If inverted, 0 offset is at bottom
            scrollRatio = 1.0f - scrollRatio;
        }

        int thumbY = y + 2 + (int) ((barTrackH - thumbH) * scrollRatio);

        // Track line
        context.fill(barX + 1, y + 2, barX + 3, y + 2 + barTrackH, 0x22FFFFFF);
        // Thumb pill
        context.fill(barX, thumbY, barX + 3, thumbY + thumbH, Theme.getAccentTranslucent());
        context.fill(barX + 1, thumbY + 1, barX + 2, thumbY + thumbH - 1, Theme.getAccentPrimary());
    }
}
