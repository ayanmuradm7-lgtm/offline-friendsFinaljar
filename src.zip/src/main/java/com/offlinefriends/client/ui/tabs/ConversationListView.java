package com.offlinefriends.client.ui.tabs;

import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.client.ui.widgets.BadgeWidget;
import com.offlinefriends.client.ui.widgets.ScrollPane;
import com.offlinefriends.config.ModConfig;
import com.offlinefriends.social.ChatHistoryManager;
import com.offlinefriends.social.GroupManager;
import com.offlinefriends.social.SocialWebSocketClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

/**
 * ConversationListView
 * 
 * Displays active conversations and group chats for the Chats tab:
 * - Avatar, name, last message preview, unread badges, presence dots.
 * - Touch-friendly: minimum 42px item height, swipe scrolling.
 * - Long-press for Mute, Block, Leave Group.
 * - Strictly under 300 lines.
 */
public class ConversationListView {

    private int x, y, width, height;
    private final ScrollPane scrollPane;

    public interface Listener {
        void onSelectFriend(String friendName);
        void onSelectGroup(String groupId);
        void onOpenCreateGroupModal();
        void onOpenAddFriend();
        void onTabChanged(LeftRailTab tab);
    }

    private final Listener listener;
    private long pressStartTime = 0L;
    private double pressX = 0, pressY = 0;
    private String longPressedTarget = null;
    private boolean isGroupTarget = false;
    private boolean showContextMenu = false;

    public ConversationListView(int x, int y, int width, int height, Listener listener) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.listener = listener;
        this.scrollPane = new ScrollPane(x, y + 36, width, height - 38, false);
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }

    public void setBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scrollPane.setBounds(x, y + 36, width, height - 38);
    }

    public boolean mouseClickedOverlay(double mx, double my) {
        if (showContextMenu) {
            handleContextMenuClick(mx, my);
            showContextMenu = false;
            return true;
        }
        return false;
    }

    public boolean mouseClickedContent(double mx, double my, int button, LeftRailTab activeTab, String selectedFriend, String selectedGroupId) {
        // Create Group button on Groups tab
        if (activeTab == LeftRailTab.GROUPS) {
            if (my >= y + 4 && my <= y + 32 && mx >= x + 4 && mx <= x + width - 4) {
                if (listener != null) listener.onOpenCreateGroupModal();
                return true;
            }
        }

        if (scrollPane.isMouseOver(mx, my)) {
            pressStartTime = System.currentTimeMillis();
            pressX = mx;
            pressY = my;
            int contentY = (int) (my - (y + 36) + scrollPane.getScrollOffset());
            handleItemClick(mx, contentY, activeTab);
            scrollPane.mouseClicked(mx, my, button);
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double mx, double my, int button, double deltaX, double deltaY) {
        if (Math.abs(mx - pressX) > 5 || Math.abs(my - pressY) > 5) pressStartTime = 0L;
        return scrollPane.mouseDragged(mx, my, button, deltaX, deltaY);
    }

    public boolean mouseReleased(double mx, double my, int button) {
        pressStartTime = 0L;
        return scrollPane.mouseReleased(mx, my, button);
    }

    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        return scrollPane.mouseScrolled(mx, my, horizontalAmount, verticalAmount);
    }

    private void handleItemClick(double mx, int contentY, LeftRailTab activeTab) {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int itemY = 0;

        if (activeTab == LeftRailTab.GROUPS) {
            for (GroupManager.GroupInfo g : GroupManager.getInstance().getGroups().values()) {
                if (contentY >= itemY && contentY <= itemY + 44) {
                    this.longPressedTarget = g.getId();
                    this.isGroupTarget = true;
                    if (listener != null) listener.onSelectGroup(g.getId());
                    return;
                }
                itemY += 46;
            }
        } else {
            // Chats tab: lists active friends + groups
            for (SocialWebSocketClient.FriendInfo f : new ArrayList<>(social.friends.values())) {
                if (contentY >= itemY && contentY <= itemY + 44) {
                    this.longPressedTarget = f.username();
                    this.isGroupTarget = false;
                    if (listener != null) listener.onSelectFriend(f.username());
                    return;
                }
                itemY += 46;
            }
            for (GroupManager.GroupInfo g : GroupManager.getInstance().getGroups().values()) {
                if (contentY >= itemY && contentY <= itemY + 44) {
                    this.longPressedTarget = g.getId();
                    this.isGroupTarget = true;
                    if (listener != null) listener.onSelectGroup(g.getId());
                    return;
                }
                itemY += 46;
            }
        }
    }

    private void handleContextMenuClick(double mx, double my) {
        if (longPressedTarget == null) return;
        ModConfig cfg = ModConfig.getInstance();
        SocialWebSocketClient soc = SocialWebSocketClient.getInstance();
        int menuX = x + 16, menuY = y + 40, menuW = 120;

        if (isGroupTarget) {
            if (mx >= menuX && mx <= menuX + menuW && my >= menuY && my <= menuY + 28) {
                GroupManager.getInstance().leaveGroup(longPressedTarget);
                if (listener != null) listener.onSelectGroup(null);
            }
        } else if (mx >= menuX && mx <= menuX + menuW) {
            if (my >= menuY && my <= menuY + 20) {
                if (cfg.isFriendMuted(longPressedTarget)) cfg.unmuteFriend(longPressedTarget); else cfg.muteFriend(longPressedTarget);
            } else if (my >= menuY + 20 && my <= menuY + 40) {
                if (cfg.isUserBlocked(longPressedTarget)) cfg.unblockUser(longPressedTarget); else cfg.blockUser(longPressedTarget);
            } else if (my >= menuY + 40 && my <= menuY + 64) {
                soc.sendFriendRemove(longPressedTarget);
                if (listener != null) listener.onSelectFriend(null);
            }
        }
    }

    public void renderContent(DrawContext context, TextRenderer tr, int mouseX, int mouseY, LeftRailTab activeTab,
                              String selectedFriend, String selectedGroupId) {
        Theme.drawGlassPanel(context, x, y, width, height);

        // Header for Conversations
        if (activeTab == LeftRailTab.GROUPS) {
            boolean hov = mouseX >= x + 6 && mouseX <= x + width - 6 && mouseY >= y + 4 && mouseY <= y + 30;
            Theme.drawRoundedRect(context, x + 6, y + 4, width - 12, 26, hov ? Theme.getCurrentAccent().text : Theme.getAccentPrimary(), Theme.BORDER_HIGHLIGHT);
            context.drawCenteredTextWithShadow(tr, "+ Create Group", x + width / 2, y + 13, 0xFFFFFFFF);
        } else {
            context.drawTextWithShadow(tr, "Conversations", x + 10, y + 12, Theme.TEXT_TITLE);
            int totalUnread = ChatHistoryManager.getInstance().getTotalUnreadCount();
            if (totalUnread > 0) {
                BadgeWidget.renderUnreadBadge(context, tr, totalUnread, x + width - 24, y + 8);
            }
        }

        if (pressStartTime > 0L && (System.currentTimeMillis() - pressStartTime) >= 500L) {
            showContextMenu = true;
            pressStartTime = 0L;
        }

        scrollPane.setBounds(x, y + 36, width, height - 38);
        scrollPane.beginScissor(context);
        int renderY = y + 36 - (int) scrollPane.getScrollOffset();
        int totalContentHeight = renderItems(context, tr, renderY, mouseX, mouseY, activeTab, selectedFriend, selectedGroupId);
        scrollPane.endScissor(context);

        scrollPane.setContentHeight(totalContentHeight);
        scrollPane.renderScrollbar(context);
    }

    public void renderOverlay(DrawContext context, TextRenderer tr) {
        if (showContextMenu && longPressedTarget != null) {
            int menuX = x + 16, menuY = y + 40, menuW = 120, menuH = isGroupTarget ? 28 : 64;
            Theme.drawRoundedRect(context, menuX, menuY, menuW, menuH, Theme.BG_DARK_GLASS, Theme.BORDER_HIGHLIGHT);
            if (isGroupTarget) {
                context.drawTextWithShadow(tr, "Leave Group", menuX + 8, menuY + 8, Theme.STATUS_ERROR);
            } else {
                ModConfig config = ModConfig.getInstance();
                context.drawTextWithShadow(tr, config.isFriendMuted(longPressedTarget) ? "Unmute" : "Mute Notifications", menuX + 8, menuY + 8, Theme.TEXT_PRIMARY);
                context.drawTextWithShadow(tr, config.isUserBlocked(longPressedTarget) ? "Unblock" : "Block User", menuX + 8, menuY + 26, Theme.STATUS_AWAY);
                context.drawTextWithShadow(tr, "Remove Friend", menuX + 8, menuY + 44, Theme.STATUS_ERROR);
            }
        }
    }

    private int renderItems(DrawContext context, TextRenderer tr, int startY, int mouseX, int mouseY,
                            LeftRailTab activeTab, String selectedFriend, String selectedGroupId) {
        SocialWebSocketClient social = SocialWebSocketClient.getInstance();
        int curY = startY;

        if (activeTab == LeftRailTab.GROUPS) {
            Map<String, GroupManager.GroupInfo> groups = GroupManager.getInstance().getGroups();
            if (groups.isEmpty()) {
                Theme.drawSolidCard(context, x + 6, curY, width - 12, 48, false);
                context.drawCenteredTextWithShadow(tr, "No groups yet", x + width / 2, curY + 12, Theme.TEXT_SECONDARY);
                context.drawCenteredTextWithShadow(tr, "Tap '+ Create Group' above", x + width / 2, curY + 28, Theme.getAccentText());
                curY += 54;
            } else {
                for (GroupManager.GroupInfo g : groups.values()) {
                    curY = renderGroupRow(context, tr, curY, mouseX, mouseY, g, selectedGroupId);
                }
            }
        } else {
            // Chats tab
            boolean hasAny = false;
            for (SocialWebSocketClient.FriendInfo f : new ArrayList<>(social.friends.values())) {
                curY = renderFriendRow(context, tr, curY, mouseX, mouseY, f, selectedFriend);
                hasAny = true;
            }
            for (GroupManager.GroupInfo g : GroupManager.getInstance().getGroups().values()) {
                curY = renderGroupRow(context, tr, curY, mouseX, mouseY, g, selectedGroupId);
                hasAny = true;
            }

            if (!hasAny) {
                Theme.drawSolidCard(context, x + 6, curY, width - 12, 54, false);
                context.drawCenteredTextWithShadow(tr, "No conversations yet", x + width / 2, curY + 14, Theme.TEXT_SECONDARY);
                context.drawCenteredTextWithShadow(tr, "Select Friends to start chatting", x + width / 2, curY + 30, Theme.getAccentText());
                curY += 60;
            }
        }

        return Math.max(0, curY - startY);
    }

    private int renderFriendRow(DrawContext context, TextRenderer tr, int curY, int mouseX, int mouseY,
                                SocialWebSocketClient.FriendInfo f, String selectedFriend) {
        boolean isSel = selectedFriend != null && selectedFriend.equalsIgnoreCase(f.username());
        boolean isHover = mouseX >= x + 6 && mouseX <= x + width - 6 && mouseY >= curY && mouseY <= curY + 42;

        if (isSel) Theme.drawRoundedRect(context, x + 6, curY, width - 12, 42, Theme.getCurrentAccent().translucent, Theme.getAccentPrimary());
        else Theme.drawSolidCard(context, x + 6, curY, width - 12, 42, isHover);

        AvatarWidget.render(context, f.username(), x + 12, curY + 9, 24);
        boolean isSp = f.online() && (f.server() == null || f.server().isEmpty() || f.server().equalsIgnoreCase("singleplayer"));
        BadgeWidget.renderStatusDot(context, f.online(), isSp, x + 34, curY + 31, 3);
        context.drawTextWithShadow(tr, f.username(), x + 42, curY + 8, isSel ? Theme.getAccentText() : Theme.TEXT_PRIMARY);

        String subText = f.online() ? (f.server() != null && !f.server().isEmpty() ? "Playing on " + f.server() : "Online") : "Offline";
        List<ChatHistoryManager.DirectMessage> conv = ChatHistoryManager.getInstance().getConversation(f.username());
        ChatHistoryManager.DirectMessage lastMsg = (conv != null && !conv.isEmpty()) ? conv.get(conv.size() - 1) : null;
        if (lastMsg != null) {
            boolean mine = lastMsg.getFrom() != null && lastMsg.getFrom().equalsIgnoreCase(ModConfig.getInstance().getEffectiveUsername());
            subText = (mine ? "You: " : "") + lastMsg.getText();
        }
        if (subText.length() > 18) subText = subText.substring(0, 16) + "..";
        context.drawText(tr, subText, x + 42, curY + 22, Theme.TEXT_MUTED, false);

        int unread = ChatHistoryManager.getInstance().getUnreadCount(f.username());
        if (unread > 0) BadgeWidget.renderUnreadBadge(context, tr, unread, x + width - 28, curY + 14);
        return curY + 46;
    }

    private int renderGroupRow(DrawContext context, TextRenderer tr, int curY, int mouseX, int mouseY,
                               GroupManager.GroupInfo g, String selectedGroupId) {
        boolean isSel = selectedGroupId != null && selectedGroupId.equals(g.getId());
        boolean isHover = mouseX >= x + 6 && mouseX <= x + width - 6 && mouseY >= curY && mouseY <= curY + 42;

        if (isSel) Theme.drawRoundedRect(context, x + 6, curY, width - 12, 42, Theme.getCurrentAccent().translucent, Theme.getAccentPrimary());
        else Theme.drawSolidCard(context, x + 6, curY, width - 12, 42, isHover);

        context.fill(x + 12, curY + 9, x + 36, curY + 33, Theme.BG_CARD_HOVER);
        context.drawCenteredTextWithShadow(tr, "#", x + 24, curY + 16, Theme.getAccentText());
        context.drawTextWithShadow(tr, g.getName(), x + 42, curY + 8, isSel ? Theme.getAccentText() : Theme.TEXT_TITLE);
        context.drawText(tr, (g.getMembers().size() + 1) + " members", x + 42, curY + 22, Theme.TEXT_SECONDARY, false);

        int unread = GroupManager.getInstance().getUnreadCount(g.getId());
        if (unread > 0) BadgeWidget.renderUnreadBadge(context, tr, unread, x + width - 28, curY + 14);
        return curY + 46;
    }
}
