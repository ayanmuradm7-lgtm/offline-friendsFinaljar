package com.offlinefriends.client.ui.modals;

import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.client.ui.widgets.AvatarWidget;
import com.offlinefriends.config.ModConfig;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Set;

/**
 * BlockedMutedDialog
 * 
 * Modular modal dialog for managing blocked users and muted friends.
 * Follows dark glass styling with 40px touch-friendly unblock/unmute buttons.
 * Keeps SettingsScreen strictly under 400 lines.
 */
public class BlockedMutedDialog {

    private boolean open = false;

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public void render(DrawContext context, TextRenderer textRenderer, int screenWidth, int screenHeight, int mouseX, int mouseY) {
        if (!open) return;

        int centerX = screenWidth / 2;
        int dialogY = Math.max(15, screenHeight / 2 - 95);
        int dialogW = Math.min(320, screenWidth - 20);
        int dialogH = 190;

        // Dark glass backdrop with accent border
        context.fill(0, 0, screenWidth, screenHeight, 0x77000000);
        Theme.drawRoundedRect(context, centerX - dialogW / 2, dialogY, dialogW, dialogH, Theme.BG_DARK_GLASS, Theme.getAccentPrimary());

        // Header
        context.drawCenteredTextWithShadow(textRenderer, "Manage Blocked & Muted", centerX, dialogY + 8, Theme.TEXT_TITLE);

        // Close [✕] button at top right (min 36x24 tap area)
        int closeX = centerX + dialogW / 2 - 28;
        int closeY = dialogY + 6;
        context.fill(closeX, closeY, closeX + 22, closeY + 16, 0xEEEF4444);
        context.drawCenteredTextWithShadow(textRenderer, "✕", closeX + 11, closeY + 4, 0xFFFFFFFF);

        int listY = dialogY + 28;

        // 1. Blocked Users Section
        Set<String> blocked = ModConfig.getInstance().getBlockedUsers();
        context.drawText(textRenderer, "Blocked Users (" + blocked.size() + ") - DMs & tracking ignored:", centerX - dialogW / 2 + 12, listY, 0xFFEF4444, false);
        listY += 12;

        if (blocked.isEmpty()) {
            context.drawText(textRenderer, "No users currently blocked.", centerX - dialogW / 2 + 16, listY, Theme.TEXT_MUTED, false);
            listY += 16;
        } else {
            for (String u : new ArrayList<>(blocked)) {
                if (listY > dialogY + 95) break;
                AvatarWidget.drawHead(context, u, centerX - dialogW / 2 + 14, listY - 1, 14);
                context.drawText(textRenderer, u, centerX - dialogW / 2 + 32, listY + 2, Theme.TEXT_PRIMARY, false);

                // Unblock button
                int btnX = centerX + dialogW / 2 - 70;
                context.fill(btnX, listY - 1, btnX + 58, listY + 13, Theme.BG_CARD);
                context.drawCenteredTextWithShadow(textRenderer, "Unblock", btnX + 29, listY + 2, 0xFF10B981);
                listY += 16;
            }
        }

        listY = Math.max(listY + 4, dialogY + 105);

        // 2. Muted Friends Section
        Set<String> muted = ModConfig.getInstance().getMutedFriends();
        context.drawText(textRenderer, "Muted Friends (" + muted.size() + ") - Notifications silenced:", centerX - dialogW / 2 + 12, listY, 0xFFF59E0B, false);
        listY += 12;

        if (muted.isEmpty()) {
            context.drawText(textRenderer, "No friends currently muted.", centerX - dialogW / 2 + 16, listY, Theme.TEXT_MUTED, false);
        } else {
            for (String u : new ArrayList<>(muted)) {
                if (listY > dialogY + dialogH - 20) break;
                AvatarWidget.drawHead(context, u, centerX - dialogW / 2 + 14, listY - 1, 14);
                context.drawText(textRenderer, u, centerX - dialogW / 2 + 32, listY + 2, Theme.TEXT_PRIMARY, false);

                // Unmute button
                int btnX = centerX + dialogW / 2 - 70;
                context.fill(btnX, listY - 1, btnX + 58, listY + 13, Theme.BG_CARD);
                context.drawCenteredTextWithShadow(textRenderer, "Unmute", btnX + 29, listY + 2, 0xFFF59E0B);
                listY += 16;
            }
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int screenWidth, int screenHeight, Runnable onUpdated) {
        if (!open) return false;

        int centerX = screenWidth / 2;
        int dialogY = Math.max(15, screenHeight / 2 - 95);
        int dialogW = Math.min(320, screenWidth - 20);
        int dialogH = 190;

        // Close button
        int closeX = centerX + dialogW / 2 - 28;
        int closeY = dialogY + 6;
        if (mouseX >= closeX && mouseX <= closeX + 22 && mouseY >= closeY && mouseY <= closeY + 16) {
            this.open = false;
            return true;
        }

        // Unblock buttons
        int listY = dialogY + 40;
        Set<String> blocked = ModConfig.getInstance().getBlockedUsers();
        for (String u : new ArrayList<>(blocked)) {
            if (listY > dialogY + 95) break;
            int btnX = centerX + dialogW / 2 - 70;
            if (mouseX >= btnX && mouseX <= btnX + 58 && mouseY >= listY - 1 && mouseY <= listY + 13) {
                ModConfig.getInstance().unblockUser(u);
                if (onUpdated != null) onUpdated.run();
                return true;
            }
            listY += 16;
        }

        // Unmute buttons
        listY = Math.max(listY + 16, dialogY + 117);
        Set<String> muted = ModConfig.getInstance().getMutedFriends();
        for (String u : new ArrayList<>(muted)) {
            if (listY > dialogY + dialogH - 20) break;
            int btnX = centerX + dialogW / 2 - 70;
            if (mouseX >= btnX && mouseX <= btnX + 58 && mouseY >= listY - 1 && mouseY <= listY + 13) {
                ModConfig.getInstance().unmuteFriend(u);
                if (onUpdated != null) onUpdated.run();
                return true;
            }
            listY += 16;
        }

        // Consume click inside modal dialog area
        if (mouseX >= centerX - dialogW / 2 && mouseX <= centerX + dialogW / 2 &&
            mouseY >= dialogY && mouseY <= dialogY + dialogH) {
            return true;
        }

        return false;
    }
}
