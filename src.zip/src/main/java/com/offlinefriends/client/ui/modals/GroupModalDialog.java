package com.offlinefriends.client.ui.modals;

import com.offlinefriends.client.ui.Theme;
import com.offlinefriends.social.GroupManager;
import com.offlinefriends.social.SocialWebSocketClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

import java.util.*;
import java.util.function.Consumer;

/**
 * GroupModalDialog
 * 
 * Handles modal dialogs for creating and renaming groups in SocialScreen.
 * Keeps SocialScreen strictly below 400 lines.
 */
public class GroupModalDialog {

    private boolean showCreate = false;
    private boolean showRename = false;
    private String renameGroupId = null;

    private TextFieldWidget createNameField;
    private TextFieldWidget renameNameField;
    private final Set<String> selectedFriends = new HashSet<>();

    public void init(int screenWidth, int screenHeight, TextRenderer textRenderer, Consumer<TextFieldWidget> registrar) {
        int cx = screenWidth / 2;
        int cy = screenHeight / 2;

        this.createNameField = new TextFieldWidget(textRenderer, cx - 90, cy - 45, 180, 20, Text.literal("Group Name"));
        this.createNameField.setMaxLength(24);
        this.createNameField.visible = false;
        registrar.accept(this.createNameField);

        this.renameNameField = new TextFieldWidget(textRenderer, cx - 90, cy - 15, 180, 20, Text.literal("Rename"));
        this.renameNameField.setMaxLength(24);
        this.renameNameField.visible = false;
        registrar.accept(this.renameNameField);
    }

    public boolean isOpen() {
        return showCreate || showRename;
    }

    public void openCreate() {
        this.showCreate = true;
        this.showRename = false;
        this.selectedFriends.clear();
        if (createNameField != null) {
            createNameField.visible = true;
            createNameField.setText("");
            createNameField.setFocused(true);
        }
        if (renameNameField != null) renameNameField.visible = false;
    }

    public void openRename(String groupId, String currentName) {
        this.renameGroupId = groupId;
        this.showRename = true;
        this.showCreate = false;
        if (renameNameField != null) {
            renameNameField.visible = true;
            renameNameField.setText(currentName != null ? currentName : "");
            renameNameField.setFocused(true);
        }
        if (createNameField != null) createNameField.visible = false;
    }

    public void close() {
        this.showCreate = false;
        this.showRename = false;
        if (createNameField != null) {
            createNameField.visible = false;
            createNameField.setFocused(false);
        }
        if (renameNameField != null) {
            renameNameField.visible = false;
            renameNameField.setFocused(false);
        }
    }

    public void render(DrawContext context, TextRenderer textRenderer, int screenWidth, int screenHeight) {
        if (!isOpen()) return;

        int cx = screenWidth / 2;
        int cy = screenHeight / 2;

        // Modal backdrop overlay
        context.fill(0, 0, screenWidth, screenHeight, 0x66000000);

        if (showCreate) {
            Theme.drawRoundedRect(context, cx - 110, cy - 80, 220, 160, Theme.BG_DARK_GLASS, Theme.getAccentPrimary());
            context.drawCenteredTextWithShadow(textRenderer, "Create Group Chat", cx, cy - 70, Theme.TEXT_TITLE);
            context.drawText(textRenderer, "Group Name:", cx - 90, cy - 56, Theme.TEXT_SECONDARY, false);

            int fy = cy - 20;
            context.drawText(textRenderer, "Select Friends (max 8):", cx - 90, fy, Theme.TEXT_MUTED, false);
            fy += 12;
            for (String f : SocialWebSocketClient.getInstance().friends.keySet()) {
                if (fy > cy + 35) break;
                boolean checked = selectedFriends.contains(f);
                context.fill(cx - 90, fy, cx - 78, fy + 12, checked ? Theme.getAccentPrimary() : Theme.BG_CARD);
                context.drawText(textRenderer, f, cx - 72, fy + 2, Theme.TEXT_PRIMARY, false);
                fy += 14;
            }

            // Buttons
            context.fill(cx - 90, cy + 50, cx - 10, cy + 70, Theme.getAccentPrimary());
            context.drawCenteredTextWithShadow(textRenderer, "Create", cx - 50, cy + 56, 0xFFFFFFFF);

            context.fill(cx + 10, cy + 50, cx + 90, cy + 70, Theme.BG_CARD);
            context.drawCenteredTextWithShadow(textRenderer, "Cancel", cx + 50, cy + 56, Theme.TEXT_SECONDARY);
        } else if (showRename) {
            Theme.drawRoundedRect(context, cx - 110, cy - 50, 220, 100, Theme.BG_DARK_GLASS, Theme.getAccentPrimary());
            context.drawCenteredTextWithShadow(textRenderer, "Rename Group", cx, cy - 40, Theme.TEXT_TITLE);

            context.fill(cx - 90, cy + 18, cx - 10, cy + 38, Theme.getAccentPrimary());
            context.drawCenteredTextWithShadow(textRenderer, "Save", cx - 50, cy + 24, 0xFFFFFFFF);

            context.fill(cx + 10, cy + 18, cx + 90, cy + 38, Theme.BG_CARD);
            context.drawCenteredTextWithShadow(textRenderer, "Cancel", cx + 50, cy + 24, Theme.TEXT_SECONDARY);
        }
    }

    public boolean mouseClicked(double mx, double my, int button, int screenWidth, int screenHeight,
                                Consumer<GroupManager.GroupInfo> onGroupCreated,
                                Consumer<String> onGroupRenamed) {
        if (!isOpen()) return false;

        int cx = screenWidth / 2;
        int cy = screenHeight / 2;

        if (showCreate) {
            // Create Button
            if (mx >= cx - 90 && mx <= cx - 10 && my >= cy + 50 && my <= cy + 70) {
                String name = createNameField != null ? createNameField.getText().trim() : "";
                if (!name.isEmpty()) {
                    GroupManager.GroupInfo g = GroupManager.getInstance().createGroup(name, new ArrayList<>(selectedFriends));
                    if (onGroupCreated != null) onGroupCreated.accept(g);
                }
                close();
                return true;
            }
            // Cancel Button
            if (mx >= cx + 10 && mx <= cx + 90 && my >= cy + 50 && my <= cy + 70) {
                close();
                return true;
            }
            // Friend checklist toggle
            int fy = cy - 8;
            for (String f : SocialWebSocketClient.getInstance().friends.keySet()) {
                if (mx >= cx - 90 && mx <= cx + 80 && my >= fy && my <= fy + 12) {
                    if (selectedFriends.contains(f)) selectedFriends.remove(f);
                    else if (selectedFriends.size() < 8) selectedFriends.add(f);
                    return true;
                }
                fy += 14;
            }
            return true;
        }

        if (showRename) {
            if (mx >= cx - 90 && mx <= cx - 10 && my >= cy + 18 && my <= cy + 38) {
                String name = renameNameField != null ? renameNameField.getText().trim() : "";
                if (!name.isEmpty() && renameGroupId != null) {
                    GroupManager.getInstance().renameGroup(renameGroupId, name);
                    if (onGroupRenamed != null) onGroupRenamed.accept(name);
                }
                close();
                return true;
            }
            if (mx >= cx + 10 && mx <= cx + 90 && my >= cy + 18 && my <= cy + 38) {
                close();
                return true;
            }
            return true;
        }

        return false;
    }

    public boolean charTyped(CharInput input) {
        if (showCreate && createNameField != null && createNameField.isFocused()) return createNameField.charTyped(input);
        if (showRename && renameNameField != null && renameNameField.isFocused()) return renameNameField.charTyped(input);
        return false;
    }

    public boolean keyPressed(KeyInput input) {
        if (input != null && input.key() == 256) { // Escape
            close();
            return true;
        }
        return false;
    }
}
