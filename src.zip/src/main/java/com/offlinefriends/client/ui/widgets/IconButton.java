package com.offlinefriends.client.ui.widgets;

import com.offlinefriends.client.ui.Anim;
import com.offlinefriends.client.ui.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * IconButton
 * 
 * Touch-friendly button designed for navigation rails and header actions.
 * Guarantees visible text labels for touch devices without hover support.
 */
public class IconButton {

    private int x, y, width, height;
    private final String icon;
    private final String label;
    private final String tooltip;
    private final Runnable onClick;

    private boolean isHovered = false;
    private boolean isPressed = false;
    private boolean isActive = false;
    private int badgeCount = 0;
    private long hoverStartNano = 0L;

    public IconButton(int x, int y, int width, int height, String icon, String tooltip, Runnable onClick) {
        this(x, y, width, height, icon, null, tooltip, onClick);
    }

    public IconButton(int x, int y, int width, int height, String icon, String label, String tooltip, Runnable onClick) {
        this.x = x;
        this.y = y;
        this.width = Math.max(36, width);
        this.height = Math.max(22, height);
        this.icon = icon;
        this.label = label;
        this.tooltip = tooltip;
        this.onClick = onClick;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void setDimensions(int w, int h) {
        this.width = Math.max(36, w);
        this.height = Math.max(22, h);
    }

    public void setActive(boolean active) {
        this.isActive = active;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setBadgeCount(int badgeCount) {
        this.badgeCount = badgeCount;
    }

    public boolean isMouseOver(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (isMouseOver(mx, my)) {
            isPressed = true;
            if (onClick != null) {
                onClick.run();
            }
            return true;
        }
        return false;
    }

    public boolean mouseReleased(double mx, double my, int button) {
        if (isPressed) {
            isPressed = false;
            return true;
        }
        return false;
    }

    public void render(DrawContext context, TextRenderer tr, int mouseX, int mouseY) {
        boolean currentlyHovered = isMouseOver(mouseX, mouseY);
        if (currentlyHovered && !isHovered) {
            hoverStartNano = System.nanoTime();
        }
        isHovered = currentlyHovered;

        // Background styling
        if (isActive) {
            context.fill(x, y, x + width, y + height, Theme.getCurrentAccent().translucent);
            context.fill(x, y + 2, x + 3, y + height - 2, Theme.getAccentPrimary());
        } else if (isHovered) {
            float progress = Anim.progress(hoverStartNano, 120);
            float ease = Anim.easeOutCubic(progress);
            int hoverColor = Anim.lerpColor(0x00FFFFFF, Theme.BG_CARD_HOVER, ease);
            context.fill(x, y, x + width, y + height, hoverColor);
        }

        int iconColor = isActive ? 0xFFFFFFFF : (isHovered ? Theme.TEXT_TITLE : Theme.TEXT_PRIMARY);

        // If label is present, render icon + label or label centered
        if (label != null && !label.isEmpty()) {
            if (height >= 34) {
                context.drawCenteredTextWithShadow(tr, icon, x + width / 2, y + height / 2 - 8, iconColor);
                context.drawCenteredTextWithShadow(tr, label, x + width / 2, y + height / 2 + 2, isActive ? 0xFFFFFFFF : Theme.TEXT_PRIMARY);
            } else {
                context.drawCenteredTextWithShadow(tr, label, x + width / 2, y + height / 2 - 4, isActive ? 0xFFFFFFFF : Theme.TEXT_PRIMARY);
            }
        } else {
            context.drawCenteredTextWithShadow(tr, icon, x + width / 2, y + height / 2 - 4, iconColor);
        }

        // Render badge count if > 0
        if (badgeCount > 0) {
            BadgeWidget.renderUnreadBadge(context, tr, badgeCount, x + width - 12, y + 2);
        }

        // Tooltip on hover for mouse users
        if (isHovered && tooltip != null && !tooltip.isEmpty()) {
            int tipW = tr.getWidth(tooltip) + 10;
            int tipX = x + width + 8;
            int tipY = y + height / 2 - 8;
            context.fill(tipX, tipY, tipX + tipW, tipY + 16, Theme.BG_DARK_GLASS);
            context.drawStrokedRectangle(tipX, tipY, tipW, 16, Theme.BORDER_CARD);
            context.drawTextWithShadow(tr, tooltip, tipX + 5, tipY + 4, Theme.TEXT_TITLE);
        }
    }
}
