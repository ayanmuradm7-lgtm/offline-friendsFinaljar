package com.offlinefriends.client.ui;

import com.offlinefriends.config.ModConfig;
import net.minecraft.client.gui.DrawContext;

/**
 * Theme
 * 
 * Dark glass-style theme with customizable accent color.
 * Designed for low-end mobile Adreno GPUs (Zalith / MobileGlues):
 * - ZERO custom shaders, ZERO blur passes.
 * - Only DrawContext fills, gradients, text and textures.
 * - Rounded corners rendered via stepped DrawContext.fill for zero GPU overhead.
 */
public class Theme {

    // Base Glass Palette
    public static final int BG_DARK_GLASS = 0xD90B0F19;     // Main translucent window background
    public static final int BG_PANEL_GLASS = 0xE6111827;    // Internal section glass panel
    public static final int BG_CARD = 0xF01E293B;           // Card & conversation item background
    public static final int BG_CARD_HOVER = 0xF0334155;     // Card hover/active state
    public static final int BG_INPUT = 0xEE0F172A;          // Text input field background

    // Borders
    public static final int BORDER_SUBTLE = 0x33475569;     // 1px subtle divider
    public static final int BORDER_CARD = 0x4464748B;       // Card border
    public static final int BORDER_HIGHLIGHT = 0x7794A3B8;  // Hover/focus border

    // Typography
    public static final int TEXT_TITLE = 0xFFF8FAFC;        // Bright white
    public static final int TEXT_PRIMARY = 0xFFE2E8F0;      // Slate 200
    public static final int TEXT_SECONDARY = 0xFF94A3B8;    // Slate 400
    public static final int TEXT_MUTED = 0xFF64748B;        // Slate 500
    public static final int TEXT_DIM = 0xFF475569;          // Slate 600

    // Status Colors
    public static final int STATUS_ONLINE = 0xFF22C55E;     // Emerald online dot
    public static final int STATUS_AWAY = 0xFFF59E0B;       // Amber away/singleplayer
    public static final int STATUS_OFFLINE = 0xFF64748B;    // Gray offline
    public static final int STATUS_ERROR = 0xFFEF4444;      // Red error/failed

    public enum AccentColor {
        CYAN("Cyan", 0xFF06B6D4, 0xFF22D3EE, 0x4006B6D4, 0xFF083344),
        EMERALD("Emerald", 0xFF10B981, 0xFF34D399, 0x4010B981, 0xFF064E3B),
        AMBER("Amber", 0xFFF59E0B, 0xFFFBBF24, 0x40F59E0B, 0xFF78350F),
        ROSE("Rose", 0xFFF43F5E, 0xFFFB7185, 0x40F43F5E, 0xFF881337),
        PURPLE("Purple", 0xFFA855F7, 0xFFC084FC, 0x40A855F7, 0xFF581C87),
        BLUE("Blue", 0xFF3B82F6, 0xFF60A5FA, 0x403B82F6, 0xFF1E3A8A);

        public final String displayName;
        public final int primary;      // Solid primary (buttons, badges)
        public final int text;         // Bright text highlight
        public final int translucent;  // 25% alpha glass tint
        public final int dark;         // Deep backdrop tint

        AccentColor(String name, int primary, int text, int translucent, int dark) {
            this.displayName = name;
            this.primary = primary;
            this.text = text;
            this.translucent = translucent;
            this.dark = dark;
        }

        public static AccentColor fromName(String name) {
            if (name == null) return CYAN;
            for (AccentColor c : values()) {
                if (c.name().equalsIgnoreCase(name) || c.displayName.equalsIgnoreCase(name)) {
                    return c;
                }
            }
            return CYAN;
        }
    }

    private static AccentColor activeAccent = null;

    public static void setAccent(AccentColor accent) {
        activeAccent = accent;
    }

    public static AccentColor getCurrentAccent() {
        if (activeAccent != null) return activeAccent;
        return AccentColor.fromName(ModConfig.getInstance().getAccentColor());
    }

    public static int getAccentPrimary() {
        return getCurrentAccent().primary;
    }

    public static int getAccentText() {
        return getCurrentAccent().text;
    }

    public static int getAccentTranslucent() {
        return getCurrentAccent().translucent;
    }

    /**
     * Draws a glass-style container panel with subtle 1px border.
     */
    public static void drawGlassPanel(DrawContext context, int x, int y, int width, int height) {
        drawRoundedRect(context, x, y, width, height, BG_PANEL_GLASS, BORDER_SUBTLE);
    }

    public static final int BG_SOLID_CARD = 0xFF1E293B;           // 100% solid opaque card background
    public static final int BG_SOLID_CARD_HOVER = 0xFF334155;     // 100% solid card hover state

    /**
     * Draws an interactive card with custom background and border.
     */
    public static void drawCard(DrawContext context, int x, int y, int width, int height, boolean isHovered) {
        int bg = isHovered ? BG_CARD_HOVER : BG_CARD;
        int border = isHovered ? getCurrentAccent().primary : BORDER_CARD;
        drawRoundedRect(context, x, y, width, height, bg, border);
    }

    /**
     * Draws a 100% solid, fully-opaque card with zero background bleed-through.
     */
    public static void drawSolidCard(DrawContext context, int x, int y, int width, int height, boolean isHovered) {
        int bg = isHovered ? BG_SOLID_CARD_HOVER : BG_SOLID_CARD;
        int border = isHovered ? getCurrentAccent().primary : BORDER_CARD;
        drawRoundedRect(context, x, y, width, height, bg, border);
    }

    /**
     * Pure DrawContext fill-based rounded rectangle with stepped 2px corner cutout.
     * ZERO custom shaders, zero blur, zero runtime allocations.
     */
    public static void drawRoundedRect(DrawContext context, int x, int y, int w, int h, int bgColor, int borderColor) {
        if (w < 4 || h < 4) {
            context.fill(x, y, x + w, y + h, bgColor);
            return;
        }

        // Stepped rounded corner background
        // Top and bottom 1px inset by 2px
        context.fill(x + 2, y, x + w - 2, y + 1, bgColor);
        context.fill(x + 1, y + 1, x + w - 1, y + 2, bgColor);
        // Middle full body
        context.fill(x, y + 2, x + w, y + h - 2, bgColor);
        // Bottom insets
        context.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, bgColor);
        context.fill(x + 2, y + h - 1, x + w - 2, y + h, bgColor);

        // Border if specified
        if ((borderColor & 0xFF000000) != 0) {
            // Horizontal border lines
            context.fill(x + 2, y, x + w - 2, y + 1, borderColor);
            context.fill(x + 2, y + h - 1, x + w - 2, y + h, borderColor);
            // Vertical border lines
            context.fill(x, y + 2, x + 1, y + h - 2, borderColor);
            context.fill(x + w - 1, y + 2, x + w, y + h - 2, borderColor);
            // Corner dots
            context.fill(x + 1, y + 1, x + 2, y + 2, borderColor);
            context.fill(x + w - 2, y + 1, x + w - 1, y + 2, borderColor);
            context.fill(x + 1, y + h - 2, x + 2, y + h - 1, borderColor);
            context.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, borderColor);
        }
    }
}
